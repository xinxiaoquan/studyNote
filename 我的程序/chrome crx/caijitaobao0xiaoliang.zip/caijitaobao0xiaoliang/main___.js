//#list-container .list-item 店铺列表
//.none-desc 没有描述
//.seller-rank-2 N颗心
//&search=y&orderType=hotsell_desc

const saveUrl = "https://www.tb-yhq.vip/save";
const KwUrl = "https://www.tb-yhq.vip/getkw";
const fg = new formatGET;

(function() {
    if (location.host == "shopsearch.taobao.com") {
        cardingShopList();
        return;
    }

    if (location.host.match(/shop\d+/)) {
        if (location.href.indexOf("&search=y&orderType=hotsell_desc") == -1) {
            if (location.href.indexOf("?") != -1)
                location.href += "&search=y&orderType=hotsell_desc";
            else location.href += "?search=y&orderType=hotsell_desc";
            return;
        }
        cardingShopInfo();
    }
})();

//发送数据到数据库
function pushToDB(json, callback) {
    $.ajax({
        type: "post",
        data: "data=" + json,
        url: saveUrl,
        success(res) {
            if (callback) callback(res);
        }
    });
}

//在店铺搜索列表搞事情
function cardingShopList() {
    var isShop = false;
    var linkList = [];
    var searchArr = fg.getArr();
    var identifier = "quan";

    setTimeout(() => {
        document.documentElement.scrollTop = 0;
        let timer = setInterval(() => {
            let value = document.documentElement.scrollTop;
            document.documentElement.scrollTop += 200;
            if (document.documentElement.scrollTop == value) {
                if (!searchArr[identifier]) {
                    changeKw();
                    return;
                }
                clearInterval(timer);
                main();
                openShop();
            }
        }, 200);
    }, 1500);

    function main() {
        let list = document.querySelectorAll("#list-container .list-item");
        for (var i = 0; i < list.length; i++) {
            if (list[i].querySelector(".none-desc")) {
                pushToDB(getFieldJson(list[i]));
                continue;
            }
            let item = list[i].querySelector("[class*='seller-rank-']");
            if (!item) continue;
            let xing = item.className.match(/seller-rank-(\d+)/)[1];
            if (parseInt(xing) > 1) {
                isShop = true;
                continue;
            }
            linkList.push(getLink(list[i]));

            //  console.log(`第${i}个有${xing}颗心！`);
            //  console.log(`shopName:${getShopName(list[i])} link:${getLink(list[i])} wang:${getWang(list[i])}`);
        }
    }

    function changeKw() {
        if (searchArr[identifier]) {
            delete searchArr[identifier];
            location.href = fg.getHost() + "?" + fg.toQuery(searchArr);
            return;
        }
        let active = document.querySelector(".wraper .active .num").textContent;
        let total = document.querySelector(".wraper .total").textContent.match(/\d+/)[0];
        if (active == total) {
            $.ajax({
                type: "get",
                url: KwUrl,
                success: function(kw) {
                    searchArr[identifier] = true;
                    searchArr["q"] = kw;
                    location.href = fg.getHost() + "?" + fg.toQuery(searchArr);
                }
            });
            return;
        }
        let pageInput = document.querySelector(".wraper .J_Input");
        pageInput.value = total;
        let submit = document.querySelector(".wraper .J_Submit");
        submit.click();
        setTimeout(() => {
            location.href = location.href;
        }, 1000);
        return;
    }

    function openShop() {
        if (isShop) {
            changeKw();
            return;
        }
        if (linkList.length == 0) {
            let arr = fg.getArr();
            if (!arr["s"] || parseInt(arr["s"]) <= 0) return;
            arr["s"] -= 20;
            location.href = fg.getHost() + "?" + fg.toQuery(arr);
            return;
        }
        var link = linkList.shift();
        if (link.indexOf("?") != -1)
            link += "&search=y&orderType=hotsell_desc";
        else link += "?search=y&orderType=hotsell_desc";
        window.open(link);
        setTimeout(() => {
            openShop();
        }, 1000);
    }

    function getFieldJson(dom) {
        return JSON.stringify({
            shop_name: getShopName(dom),
            link: getLink(dom),
            wang: getWang(dom)
        });
    }

    function getLink(dom) {
        let child = dom.querySelector(".shop-name");
        if (!child) return -1;
        return child.href;
    }

    function getShopName(dom) {
        let child = dom.querySelector(".shop-name");
        if (!child) return -1;
        return child.textContent.replace(/\s*/img, "");
    }

    function getWang(dom) {
        let child = dom.querySelector(".shop-info-list a");
        if (!child) return -1;
        return child.textContent.replace(/\s*/img, "");
    }
}

//在店铺中搞事情
function cardingShopInfo() {
    let index = 1;
    let timer = setInterval(() => {
        if (index++ == 300) {
            clearInterval(timer);
            window.close();
        }
        let dom = document.querySelector(".sale-num");
        if (dom) {
            clearInterval(timer);
            let num = dom.textContent;
            if (num == 0)
                pushToDB(getFieldJson(), function() {
                    window.close();
                });
            else window.close();
        }
    }, 1000);

    function getFieldJson() {
        return JSON.stringify({
            shop_name: getShopName(),
            link: getLink(),
            wang: getWang()
        });
    }

    function getLink() {
        return fg.getHost();
    }

    function getShopName() {
        let child = document.querySelector(".J_TGoldlog");
        if (!child) return -1;
        return child.textContent.replace(/\s*/img, "");
    }

    function getWang() {
        let child = document.querySelector(".seller-name");
        if (!child) return -1;
        return child.textContent.replace(/\s+|掌柜：/img, "");
    }

}