//#list-container .list-item 店铺列表
//.none-desc 没有描述
//.seller-rank-2 N颗心
//&search=y&orderType=hotsell_desc
//{"sgr":"100.00%","ind":"","mas":"0.00","mg":"0.00%","sas":"0.00","sg":"0.00%","cas":"0.00","cg":"0.00%","encryptedUserId":"UvGHYMmcLvGcuMWTT"}

const saveUrl = "https://www.tb-yhq.vip/save";
const KwUrl = "https://www.tb-yhq.vip/getkw";
const fg = new formatGET;

(function() {
    if (location.host == "shopsearch.taobao.com") {
        cardingShopList();
        return;
    }
})();

//发送数据到数据库
function pushToDB(json, callback) {
    $.ajax({
        type: "post",
        data: "data=" + json,
        url: saveUrl,
        success(res) {
            if (callback) callback(res);
        }
    });
}

//在店铺搜索列表搞事情
function cardingShopList() {
    var searchArr = fg.getArr();

    setTimeout(() => {
        document.documentElement.scrollTop = 0;
        if (!searchArr["pass"]) {
            if(!pageInit())
				return;
            let newSearchArr = fg.getArr();
            for (let key in newSearchArr)
                searchArr[key] = newSearchArr[key];
            refresh();
            return;
        }
        let timer = setInterval(() => {
            let value = document.documentElement.scrollTop;
            document.documentElement.scrollTop += 200;
            if (document.documentElement.scrollTop == value) {
                clearInterval(timer);
                if (!main()) {
                    changeKw();
                    return;
                }
                goLastPage();
            }
        }, 200);
    }, 500);

    function main() {
        let list = document.querySelectorAll("#list-container .list-item");
        let isPass = true;
        if (list.length == 0) {
            return false;
        }
        for (var i = 0; i < list.length; i++) {
            if (list[i].querySelector(".none-desc")) {
                pushToDB(getFieldJson(list[i]));
                continue;
            }
            let item = list[i].querySelector("[class*='seller-rank-']");
            if (!item) continue;
            let xing = item.className.match(/seller-rank-(\d+)/)[1];
            if (parseInt(xing) > 1) {
                isPass = false;
                continue;
            }
            if (isThreeZeros(list[i]))
                pushToDB(getFieldJson(list[i]));
        }
        return isPass;
    }

    function changeKw() {
        $.ajax({
            type: "get",
            url: KwUrl,
            success: function(kw) {
                let input = document.querySelector("#q");
                q.value = kw;
                let submit = document.querySelector(".submit");
                submit.click();
            }
        });
        return;
    }

    function pageInit() {
        if (!searchArr["sort"]) {
            searchArr["sort"] = "credit-desc";
            searchArr["goodrate"] = "10000%2C10010";
            searchArr["shop_type"] = "";
            searchArr["ratesum"] = "xin";
            searchArr["isb"] = 0;
            return true;
        }
        let pageTotal = document.querySelector(".wraper .total")
		if(!pageTotal) {
			changeKw();
			return false;
		}
		let num=pageTotal.textContent.match(/\d+/)[0];
        searchArr["s"] = (num - 1) * 20;
        searchArr["pass"] = true;
		return true;
    }

    function refresh() {
        let url = fg.getHost() + "?" + fg.toQuery(searchArr);
        //console.log(url);
        location.href = url;
    }

    function goLastPage() {
        let active = document.querySelector(".wraper .active .num")
        if (!active) {
            changeKw();
			return;
        }
		let num=active.textContent;
        searchArr["s"] = 20 * (num - 2);
        refresh();
    }

    function getFieldJson(dom) {
        return JSON.stringify({
            shop_name: getShopName(dom),
            link: getLink(dom),
            wang: getWang(dom)
        });
    }

    function getLink(dom) {
        let child = dom.querySelector(".shop-name");
        if (!child) return -1;
        return child.href;
    }

    function getShopName(dom) {
        let child = dom.querySelector(".shop-name");
        if (!child) return -1;
        return child.textContent.replace(/\s*/img, "");
    }

    function getWang(dom) {
        let child = dom.querySelector(".shop-info-list a");
        if (!child) return -1;
        return child.textContent.replace(/\s*/img, "");
    }

    function isThreeZeros(dom) {
        if (!dom.querySelector(".icon-wrapper"))
            return false;
        let data = dom.querySelector(".J_descr").getAttribute("data-dsr");
        data = JSON.parse(data);
        if (data.sgr !== "100.00%")
            return false;
        if (data.mas == 0 &&
            data.sas == 0 &&
            data.cas == 0)
            return true;
    }

}