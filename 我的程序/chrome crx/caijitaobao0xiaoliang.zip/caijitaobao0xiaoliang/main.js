//#list-container .list-item 店铺列表
//.none-desc 没有描述
//.seller-rank-2 N颗心
//&search=y&orderType=hotsell_desc
//{"sgr":"100.00%","ind":"","mas":"0.00","mg":"0.00%","sas":"0.00","sg":"0.00%","cas":"0.00","cg":"0.00%","encryptedUserId":"UvGHYMmcLvGcuMWTT"}

const saveUrl = "https://www.tb-yhq.vip/save";
const KwUrl = "https://www.tb-yhq.vip/getkw";
const fg = new formatGET;

(function() {
    if (location.host == "shopsearch.taobao.com") {
        cardingShopList();
        return;
    }
})();

//发送数据到数据库
function pushToDB(json, callback) {
    $.ajax({
        type: "post",
        data: "data=" + json,
        url: saveUrl,
        success(res) {
            if (callback) callback(res);
        }
    });
}

//在店铺搜索列表搞事情
function cardingShopList() {
    var searchArr = fg.getArr();

    setTimeout(() => {
        document.documentElement.scrollTop = 0;
        if (!searchArr["pass"]) {
            pageInit();
            let newSearchArr = fg.getArr();
            for (let key in newSearchArr)
                searchArr[key] = newSearchArr[key];
            refresh();
            return;
        }
        let timer = setInterval(() => {
            let value = document.documentElement.scrollTop;
            document.documentElement.scrollTop += 200;
            if (document.documentElement.scrollTop == value) {
                clearInterval(timer);
                if (!main()) {
                    changeKw();
                    return;
                }
                if (!goLastPage())
                    changeKw();
            }
        }, 200);
    }, 500);

    function main() {
        let list = document.querySelectorAll("#list-container .list-item");
        let isPass = true;
        if (list.length == 0) {
            return false;
        }
        for (var i = 0; i < list.length; i++) {
            if (list[i].querySelector(".none-desc")) {
                pushToDB(getFieldJson(list[i]));
                continue;
            }
            let item = list[i].querySelector("[class*='seller-rank-']");
            if (!item) continue;
            let xing = item.className.match(/seller-rank-(\d+)/)[1];
            if (parseInt(xing) > 1) {
                isPass = false;
                continue;
            }
            if (isThreeZeros(list[i]))
                pushToDB(getFieldJson(list[i]));
        }
        return isPass;
    }

    function changeKw() {
        $.ajax({
            type: "get",
            url: KwUrl,
            success: function(kw) {
                let input = document.querySelector("#q");
                q.value = kw;
                let submit = document.querySelector(".submit");
                submit.click();
            }
        });
        return;
    }

    function pageInit() {
        if (!searchArr["sort"]) {
            searchArr["sort"] = "credit-desc";
            searchArr["goodrate"] = "10000%2C10010";
            searchArr["shop_type"] = "";
            searchArr["ratesum"] = "xin";
            searchArr["isb"] = 0;
            return;
        }
        let pageTotal = document.querySelector(".wraper .total").textContent.match(/\d+/)[0];
        searchArr["s"] = (pageTotal - 1) * 20;
        searchArr["pass"] = true;
    }

    function pageInit__old() {
        let xinyong = document.querySelector("#J_relative .sorts .sort:nth-child(3) a");
        if (xinyong.className.indexOf("active") == -1) {
            xinyong.click();
            return false;
        }
        let tabs = document.querySelectorAll("#J_relative .dp-default");
        let shopType = tabs[0];
        if (shopType.textContent.indexOf("心级店") == -1) {
            let xinji = document.querySelector("#J_relative .sub-layer-panel:nth-of-type(4) a");
            xinji.click();
            return false;
        }
        let pinfen = tabs[2];
        if (pinfen.textContent.indexOf("100%") == -1) {
            let haoping = document.querySelector("#J_relative .dp-row .col:nth-of-type(4) a");
            haoping.click();
            return false;
        }
        let pageActiveDom = document.querySelector(".wraper .active .num");
        if (!pageActiveDom)
            return true;
        let pageActive = pageActiveDom.textContent;
        let pageTotal = document.querySelector(".wraper .total").textContent.match(/\d+/)[0];
        if (pageActive != pageTotal) {
            // let pageInput = document.querySelector(".wraper .J_Input");
            // pageInput.value = pageTotal;
            // let pageSubmit = document.querySelector(".wraper .J_Submit");
            // pageSubmit.click();
            searchArr["s"] = (pageTotal - 1) * 20;
            return false;
        }
        searchArr["pass"] = true;
        return true;
    }

    function refresh() {
        let url = fg.getHost() + "?" + fg.toQuery(searchArr);
        //console.log(url);
        location.href = url;
    }

    function youHuaKuai() {
        var iframe = document.querySelector("iframe:not([id])");
        if (!iframe) return false;
        var doc = iframe.contentDocument;
        if (!doc) return false;
        var huakuai = doc.querySelector("#nc_1_n1z");
        if (!huakuai) return false;
        return huakuai;
    }

    function guoHuaKuai(huakuai) {
        var event = document.createEvent('MouseEvents');
        event.initEvent('mousedown', true, false);
        huakuai.dispatchEvent(event);
        event = document.createEvent('MouseEvents');
        event.initEvent('mousemove', true, false);
        Object.defineProperty(event, 'clientX', {get() { return 260; } })
        huakuai.dispatchEvent(event);
        return true;
    }

    function goLastPage() {
        let active = document.querySelector(".wraper .active .num").textContent;
        if (!active) {
            return false;
        }
        searchArr["s"] = 20 * (active - 2);
        refresh();
    }

    function getFieldJson(dom) {
        return JSON.stringify({
            shop_name: getShopName(dom),
            link: getLink(dom),
            wang: getWang(dom)
        });
    }

    function getLink(dom) {
        let child = dom.querySelector(".shop-name");
        if (!child) return -1;
        return child.href;
    }

    function getShopName(dom) {
        let child = dom.querySelector(".shop-name");
        if (!child) return -1;
        return child.textContent.replace(/\s*/img, "");
    }

    function getWang(dom) {
        let child = dom.querySelector(".shop-info-list a");
        if (!child) return -1;
        return child.textContent.replace(/\s*/img, "");
    }

    function isThreeZeros(dom) {
        if (!dom.querySelector(".icon-wrapper"))
            return false;
        let data = dom.querySelector(".J_descr").getAttribute("data-dsr");
        data = JSON.parse(data);
        if (data.sgr !== "100.00%")
            return false;
        if (data.mas == 0 &&
            data.sas == 0 &&
            data.cas == 0)
            return true;
    }

}