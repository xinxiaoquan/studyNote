//后台路径
window.ADMINPATH="/15964158721";

//封装异步请求
function ajax(url, fun, isAsync=true) {
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if (fun) fun(this.responseText);
		}
	}
	xhr.open("get", url, isAsync);
	xhr.send(null);
}

//复制函数
function copyText(text, mess) {
	let box=document.createElement("textarea");
	box.value=text;
	box.style.marginLeft="-10000px";
	document.body.appendChild(box);
	box.select();
	document.execCommand("copy");
	document.body.removeChild(box);
	if(mess) alert(mess);
}

//改造发送form为ajax的方式
function sendFormAjax(form, fn) {
	if(!form) return;
	form.onsubmit=function() {
		let url=form.getAttribute("action");
		let doms=form.querySelectorAll("[name]");
		let query="";
		for(let i=0; i<doms.length; i++) {
			let key=doms[i]["name"];
			let value=doms[i].value;
			query+=`${key}=${value}&`;
		}
		query=query.substring(0, query.length-1);
		ajax(`${url}?${query}`, fn);
		return false;
	}
}