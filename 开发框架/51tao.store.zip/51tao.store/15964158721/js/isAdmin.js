
ajax(`${ADMINPATH}/php/isAdmin.php`,(data)=>{
	if(!data) location.href=`${ADMINPATH}/html/sign.html`;
}, false);




























