
__showData();
setInterval(()=>{
	__showData();
}, 60000);

//显示所有数据函数
function __showData() {
	
	//全部会员数
	(function() {
		let dom=document.querySelector(".main .userNum span");
		ajax(`${ADMINPATH}/php/userNum.php`,(num)=>{
			dom.innerText=formatNum(num);
		});
	})();
	
	//今日注册会员数
	(function() {
		let dom=document.querySelector(".main .todayUserNum span");
		ajax(`${ADMINPATH}/php/todayUserNum.php`,(num)=>{
			dom.innerText=formatNum(num);
		});
	})();
	
	//订单总数
	(function() {
		let dom=document.querySelector(".main .orderNum span");
		ajax(`${ADMINPATH}/php/orderNum.php`,(num)=>{
			dom.innerText=formatNum(num);
		});
	})();
	
	//今日订单数
	(function() {
		let dom=document.querySelector(".main .todayOrderNum span");
		ajax(`${ADMINPATH}/php/todayOrderNum.php`,(num)=>{
			dom.innerText=formatNum(num);
		});
	})();
	
	//总盈利
	(function() {
		let dom=document.querySelector(".main .moneyNum span");
		ajax(`${ADMINPATH}/php/moneyNum.php`,(num)=>{
			if(!num) num=0;
			num=Number(num).toFixed(2);
			dom.innerText=formatNum(num);
		});
	})();
	
	//今日盈利
	(function() {
		let dom=document.querySelector(".main .todayMoneyNum span");
		ajax(`${ADMINPATH}/php/todayMoneyNum.php`,(num)=>{
			if(!num) num=0;
			num=Number(num).toFixed(2);
			dom.innerText=formatNum(num);
		});
	})();

}

//弹出层的事件
(function() {
	let fixedBox=document.querySelector(".fixedBox");
	fixedBox.onclick=function(e) {
		if(e.target==this)
			this.parentElement.removeChild(this);
	}
})();

//退出账户
(function() {
	let button=document.querySelector(".main .exit input");
	button.onclick=function() {
		ajax("php/exit.php",()=>{
			location.href=location.href;
		})
	}
})();

//展示商品数据
(function() {
	let selectShop=document.querySelector(".selectShop");
	let showAll=selectShop.querySelector(".showAll");
	let showOff=selectShop.querySelector(".showOff");
	let selectClass=selectShop.querySelector(".funs select");
	let searchByIdInput=selectShop.querySelector(".searchById input");
	let goTuChuang=selectShop.querySelector(".goTuChuang");
	let goHupi=selectShop.querySelector(".goHupi");
	//获取所有商品按钮事件
	showAll.onclick=function() {
	//	selectClass.firstElementChild.selected=true;
		selectShop.setAttribute("isOff", false);
		selectClass.onchange();
	}
	//获取下架商品按钮事件
	showOff.onclick=function() {
		let classId=selectClass.value;
		selectShop.setAttribute("isOff", true);
		createTable(OTQ({
			pageNo:1,
			classId:classId
		}), true);
	}
	//分类的选取事件
	selectClass.onchange=function() {
		let classId=this.value;
		let isOff=false;
		if(selectShop.hasAttribute("isOff"))
			if(selectShop.getAttribute("isOff")=="true")
				isOff=true;
		createTable(OTQ({
			pageNo:1,
			classId:classId
		}), isOff);
	}
	//通过id查询数据
	searchByIdInput.onkeydown=function(e) {
		if(e.keyCode!=13) return;
		if(!this.value) return;
		createTable(OTQ({
			id:this.value
		}), false, true);
	}
	//去图床
	goTuChuang.onclick=function() {
		copyText("4S638tEH8");
		window.open("http://v019.a.viptoyou.cn/tinyfilemanager.php?p=", "_blank");
	}
	//去虎皮椒
	goHupi.onclick=function() {
		window.open("https://admin.xunhupay.com/","_blank");
	}
	//获得下架商品总数
	ajax("php/getOffShopSum.php",(data)=>{
		if(!data) data=0;
		showOff.innerHTML+=`(${data})`;
	});
	
	//对象转querystring
	function OTQ(obj) {
		let querystring="";
		for(let key in obj)
			querystring+=`${key}=${obj[key]}&`;
		querystring=
			querystring.substring(0, querystring.length-1);
		return querystring;
	}
	//请求数据创建表格
	function createTable(querystring, isOff, byId) {
		let table=document.querySelector(".selectShop .table");
		let lis=table.querySelectorAll(".tr:not(.head)");
		for(let i=0; i<lis.length; i++)
			lis[i].parentElement.removeChild(lis[i]);
		let url="php/getShopData.php";
		if(isOff) url="php/getOffShopData.php";
		if(byId) url="php/getShopDataById.php";
		url+="?"+querystring;
		ajax(url, (data)=>{
			data=JSON.parse(data);
			for(let i=0; i<data.length; i++) {
				let tr=document.createElement("div");
				tr.className="tr";
				let row=data[i];
				for(let key in row) {
					if(key=="id")
						tr.setAttribute("sid", row[key]);
					let td=createTd("td", row[key]);
					if(key=="classId") {
						td.setAttribute("classId", td.innerText);
						td.innerText="";
						(function(td) {
							setTimeout(function() {
								let classId=td.getAttribute("classId");
								let select=document.querySelector(".classSelect.know");
								let option=select.querySelector(`[value="${classId}"]`);
								td.innerText=option.innerText.replace(/\(.*\)/,"");
								td.onclick=function() {
									option.selected=true;
									select.onchange();
								}
							}, 1000);
						})(td);
					}
					if(key=="title") {
						let imgPath=GOODSIMGPATH+"/"+tr.getAttribute("sid")+"/main_pic/1.jpg";
						__mousemove(td, imgPath, row[key]);
						td.onclick=function() {
							let id=this.parentElement.getAttribute("sid");
							window.open("/detail.html?id="+id, "_blank");
						}
					}
					tr.appendChild(td);
				}
				tr.appendChild(createTd("td del", "删除", {
					click:function() {
						if(!confirm("确认删除")) return;
						let id=this.parentElement.getAttribute("sid");
						ajax("php/delShop.php?id="+id,
						(data)=>{
							if(data=="1") {
								alert("删除成功！");
								location.href=location.href;
								return;
							}
							alert("删除失败！");
						});
					}
				}));
				let ifOff=false;
				if(selectShop.hasAttribute("isOff")) {
					isOff=selectShop.getAttribute("isOff");
					if(isOff==="false") isOff=false;
					if(isOff==="true") isOff=true;
				}
				if(!isOff)
				tr.appendChild(createTd("td off", "下架", {
					click:function() {
						let id=this.parentElement.getAttribute("sid");
						ajax("php/offShop.php?id="+id,
						(data)=>{
							if(data=="1") {
								alert("下架成功！");
								location.href=location.href;
								return;
							}
							alert("下架失败！");
						});
					}
				}));
				if(isOff)
				tr.appendChild(createTd("td on", "上架", {
					click:function() {
						let id=this.parentElement.getAttribute("sid");
						ajax("php/onShop.php?id="+id,
						(data)=>{
							if(data=="1") {
								alert("上架成功！");
								location.href=location.href;
								return;
							}
							alert("上架失败！");
						});
					}
				}));
				tr.appendChild(createTd("td modify", "修改", {
					click:function() {
						let id=this.parentElement.getAttribute("sid");
						__updateShop(id);
					}
				}));
				table.appendChild(tr);
			}
			
			let pageBar=document.querySelector(".selectShop .page_bar");
			if(!pageBar) {
				return;
			}
			pageBar.innerHTML="";
			let bar=data.bar;
			if(!bar) {
				pageBar.style.display="none";
				return;
			}
			pageBar.appendChild(createPage("first", 1));
			for(let i=0; i<bar.front.length; i++)
				pageBar.appendChild(createPage("", bar.front[i]));
			pageBar.appendChild(createPage("active", bar.active));
			for(let i=0; i<bar.end.length; i++)
				pageBar.appendChild(createPage("", bar.end[i]));
			pageBar.appendChild(createPage("last", bar.pageCount));
			pageBar.appendChild(createPage("page_count", bar.pageCount));	
		});
	}
	//创建td单元格
	function createTd(className, innerHTML, eventObj) {
		let td=document.createElement("div");
		td.className=className;
		td.innerHTML=innerHTML;
		if(eventObj)
			for(let key in eventObj)
				td.addEventListener(key, eventObj[key]);
		return td;
	}
	//创建分页条
	function createPage(special, pageNo) {
		let page=document.createElement("div");
		page.className="page_no";
		page.innerText=pageNo;
		page.setAttribute("pageNo", pageNo);
		page.onclick=function() {
			let classId=selectClass.value;
			let pageNo=this.getAttribute("pageNo");
			let isOff=false;
			if(selectShop.hasAttribute("isOff"))
				if(selectShop.getAttribute("isOff")=="true")
					isOff=true;
			createTable(OTQ({
				pageNo:pageNo,
				classId:classId
			}), isOff);
		}
		if(special=="first") {
			page.className+=" first";
			page.innerText="首页";
		}
		if(special=="last") {
			page.className+=" last";
			page.innerText="尾页";
		}
		if(special=="active") {
			page.className+=" active";
			page.onclick=null;
		}
		if(special=="page_count") {
			page.className="page_count";
			page.onclick=null;
		}
		return page;
	}
})();

//获取所有分类
(function() {	
	let selectDoms=document.querySelectorAll(".classSelect");
	ajax("php/getClass.php",(data)=>{
		data=JSON.parse(data);
		for(let i=0; i<data.length; i++) {
			let option=document.createElement("option");
			option.innerText=data[i].name;
			option.value=data[i].id;
			for(let j=0; j<selectDoms.length; j++)
				selectDoms[j].appendChild(option.cloneNode(true));

			createClassItem(data[i].id, data[i].name);
		}
		for(let j=0; j<selectDoms.length; j++) {
			let dom=selectDoms[j];
			if(dom.className.indexOf("know")!=-1) {
				dom.onchange();
				let children=dom.children;
				for(let k=0; k<children.length; k++) {
					(function(option) {
						let url="php/getShopSumByClassId.php?id="+option.value;
						if(option.value==-1) 
							url="php/getShopSum.php";
						ajax(url,
						(data)=>{
							option.innerText+=`(${data})`;	
						});
					})(children[k]);
				}
			}
			if(dom.className.indexOf("edit")!=-1)
				dom.onchange();
		}
	});
})();

//编辑分类部分
(function() {
	//添加按钮
	let add=document.querySelector(".editClass .add");
	add.onclick=function() {
		createClassItem();
	}
	//提交按钮
	let submit=document.querySelector(".editClass form button");
	submit.onclick=function() {
		let form=this.parentElement;
		let items=form.querySelectorAll(".item");
		let update={};
		let insert=[];
		for(let i=0; i<items.length; i++) {
			let item=items[i];
			let value=item.querySelector("input").value;
			if(item.hasAttribute("classId")) {
				let classId=item.getAttribute("classId");
				update[classId]=value;
			} else insert.push(value);
		}
		update=encodeURIComponent(JSON.stringify(update));
		insert=encodeURIComponent(JSON.stringify(insert));
		ajax(`php/saveClass.php?update=${update}&insert=${insert}`,
		(data)=>{
			if(data=="1") {
				alert("保存成功！");
				location.href=location.href;
				return;
			}
			alert("保存失败！");
		});
		
		return false;
	}
	
})();
//创建分类框
function createClassItem(id, value) {
	let parent=document.querySelector(".editClass form");
	let add=document.querySelector(".editClass form .add");
	let item=document.createElement("div");
	item.className="item";
	if(id) item.setAttribute("classId", id);
	let input=document.createElement("input");
	if(value) input.value=value;
	item.appendChild(input);
	let close=document.createElement("i");
	close.innerText="X";
	close.className="close";
	close.onclick=closeEvent;
	item.appendChild(close);
	parent.insertBefore(item, add);

	//删除分类事件
	function closeEvent() {
		let myId=this.parentElement.getAttribute("classId");
		let items=document.querySelectorAll(".editClass form .item");
		let data=[];
		for(let i=0; i<items.length; i++) {
			let id=items[i].getAttribute("classId");
			if(id!=myId) {
				let name=items[i].querySelector("input").value;
				data.push({id:id, name:name});
			}
		}
		
		let fixedBox=document.querySelector(".fixedBox");
		fixedBox.style.display="block";
		let content=fixedBox.querySelector(".content");
		content.innerHTML=`<h5>选择迁移的分类</h5>`;
		let select=document.createElement("select");
		for(let i=0; i<data.length; i++) {
			let option=document.createElement("option");
			option.setAttribute("value", data[i].id);
			option.innerText=data[i].name;
			select.appendChild(option);
		}
		content.appendChild(select);
		let button=document.createElement("button");
		button.innerText="确定";
		button.onclick=function() {
			let newId=select.value;
			ajax(`php/delClass.php?id=${myId}&newId=${newId}`,
			(data)=>{
				if(data=="1") {
					alert("删除分类成功！");
					location.href=location.href;
					return;
				}
				alert("删除分类失败！");
			});
		}
		content.appendChild(button);
	}
}

//编辑关键字部分
(function() {
	let select=document.querySelector(".editTags .classSelect");
	select.onchange=function() {
		let id=this.value;
		ajax("php/getTagsByClassId.php?id="+id,
		(data)=>{
			data=JSON.parse(data);
			let show=document.querySelector(".editTags .show");
			show.innerHTML="";
			for(let i=0; i<data.length; i++) {
				let item=document.createElement("span");
				item.innerText=data[i];
				item.onclick=clickEvent;
				show.appendChild(item);
			}
		});
	}
	
	//关键字上移按钮
	let up=document.querySelector(".editTags .funs .up");
	up.onclick=function() {
		let active=document.querySelector(".editTags .show .active");
		if(active.previousElementSibling) {
			let dom=active.previousElementSibling;
			dom.parentElement.insertBefore(active, dom);
			return;
		}
		alert("移不动！");
	}
	//关键字下移按钮
	let down=document.querySelector(".editTags .funs .down");
	down.onclick=function() {
		let active=document.querySelector(".editTags .show .active");
		if(active.nextElementSibling) {
			let dom=active.nextElementSibling;
			dom.parentElement.insertBefore(dom, active);
			return;
		}
		alert("移不动！");
	}
	//关键字删除按钮
	let del=document.querySelector(".editTags .funs .del");
	del.onclick=function() {
		let active=document.querySelector(".editTags .show span.active");
		if(!active) return;
		active.parentElement.removeChild(active);
	}
	//关键字保存按钮
	let save=document.querySelector(".editTags .funs .save");
	save.onclick=function() {
		let select=document.querySelector(".editTags .classSelect");
		let id=select.value;
		let doms=document.querySelectorAll(".editTags .show span:not(.input)");
		let arr=[];
		for(let i=0; i<doms.length; i++) {
			arr.push(doms[i].innerText);
		}
		let json=JSON.stringify(arr);
		json=encodeURIComponent(json);
		ajax(`php/saveTagsByClassId.php?id=${id}&json=${json}`,
		(data)=>{
			if(data=="1") {
				alert("保存成功！");
				return;
			}
			alert("保存失败！");
		});
	}
	//添加关键字按钮
	let add=document.querySelector(".editTags .funs .add");
	add.onclick=function() {
		let hasInput=document.querySelector(".editTags .show .input");
		if(hasInput) return;
		
		let show=document.querySelector(".editTags .show");
		let item=document.createElement("span");
		item.className="input";
		let close=document.createElement("i");
		close.innerText="X";
		close.className="close";
		close.onclick=function() {
			let dom=this.parentElement;
			dom.parentElement.removeChild(dom);
		}
		item.appendChild(close);
		let input=document.createElement("input");
		input.placeholder="输入关键字，回车确定";
		input.onkeydown=function(e) {
			if(e.keyCode!=13) return;
			let dom=this.parentElement;
			let item=document.createElement("span");
			item.onclick=clickEvent;
			item.innerText=this.value;
			this.value="";
			dom.parentElement.insertBefore(item, dom);
		}
		item.appendChild(input);
		show.appendChild(item);
	}
	
	//关键字选项点击效果事件
	function clickEvent() {
		let parent=this.parentElement;
		let doms=parent.querySelectorAll("span:not(.input)");
		for(let i=0; i<doms.length; i++)
			doms[i].className="";
		this.className="active";
	}
})();

//插入商品数据
(function() {
	let insertShop=document.querySelector(".insertShop");
	let form=document.querySelector(".insertShop form");
	sendFormAjax(form, (data)=>{
		let Smess="添加商品成功！";
		let Emess="添加商品失败！";
		let idElem=insertShop.querySelector("[name=id]");
		if(idElem) {
			Smess="修改商品成功！";
			Emess="修改商品失败！";
		}
		if(data=="1") {
			alert(Smess);
			location.href=location.href;
			return;
		}
		alert(Emess);
	});
	
	//添加框按钮
	let addBtns=document.querySelectorAll(".insertShop .addBtn");
	for(let i=0; i<addBtns.length; i++) {
		addBtns[i].onclick=function() {
			let dom=this.previousElementSibling;
			let newDom=dom.cloneNode(true);
			let input=newDom.querySelector("input");
			input.value="";
			let closeBtn=newDom.querySelector(".close");
			if(closeBtn) closeBtn.onclick=closeEvent;
			this.parentElement.insertBefore(newDom, this);
		}
	}
	
	//关闭按钮 
	let closeBtns=document.querySelectorAll("form .group .close");
	for(let i=0; i<closeBtns.length; i++) {
		closeBtns[i].onclick=closeEvent;
	}
	//关闭按钮事件函数
	function closeEvent() {
		let dom=this.parentElement;
		dom.parentElement.removeChild(dom);
	}
	
	//时间
	let time=document.querySelector("form [name=time]");
	time.value=new Date().getTime();

})();

//改密钥
(function() {
	let form=document.querySelector(".changePWD form");
	sendFormAjax(form, (data)=>{
		if(data=="1") {
			alert("修改成功！");
			return;
		}
		alert("修改失败！");
	});
})();


//处理显示数据
function formatNum(num) {
	if(num>=10000)
		return (num/10000).toFixed(2)+"W";
	if(num>=1000)
		return (num/1000).toFixed(2)+"K";
	return num;
}
//鼠标放上显示图片函数
function __mousemove(dom, imgPath, text) {
	let album=document.querySelector(".album");
	dom.setAttribute("imgPath", imgPath);
	dom.setAttribute("text", text);
	dom.onmouseover=function() {
		let imgPath=this.getAttribute("imgPath");
		let text=this.getAttribute("text");
		album.innerHTML=`
			<img src="${imgPath}" />
			<span>${text}</span>
		`;
		album.style.display="block";
	}
	dom.onmousemove=function(e) {
		let x=e.clientX;
		let y=e.clientY;
		album.style.top=y-150+"px";
		album.style.left=x+30+"px";
	}
	dom.onmouseout=function() {
		album.style.display="none";
	}
	//console.log(dom, imgPath, text);
}
//修改商品函数
function __updateShop(shopId) {
	ajax("php/getShopInfoById.php?id="+shopId,
	(data)=>{
		data=JSON.parse(data);
	//	console.log(data);
		
		let insertShop=document.querySelector(".insertShop");
		insertShop.scrollIntoView(true);
		let form=insertShop.querySelector("form");
		let title=insertShop.querySelector(".title");
		title.innerHTML="修改商品";
		let idElem=document.createElement("input");
		idElem.type="hidden";
		idElem.name="id";
		idElem.value=shopId;
		form.insertBefore(idElem, form.firstChild);
		let insertElem=document.createElement("input");
		insertElem.type="button";
		insertElem.value="返回插入模式";
		insertElem.onclick=function() {
			this.parentElement.removeChild(this);
			__insertShop();
		}
		form.insertBefore(insertElem, form.firstChild);
		form.action="php/updateShop.php";
		
		let isShowTarget=insertShop.querySelector(`[name=isShow] [value='${data.isShow}']`);
		if(isShowTarget) isShowTarget.setAttribute("selected", true);
		let classIdTarget=insertShop.querySelector(`.classSelect [value='${data.classId}']`);
		if(classIdTarget) classIdTarget.setAttribute("selected", true);
		insertShop.querySelector("[name=title]").value=data.title;
		pushTags(JSON.parse(data.tags));
		insertShop.querySelector("[name=price]").value=data.price;
		insertShop.querySelector("[name=type]").value=data.type;
		insertShop.querySelector("[name=size]").value=data.size;
		let tryLink=JSON.parse(data.tryLink);
		let tryLinkElems=insertShop.querySelectorAll("[name='tryLink[]']");
		tryLinkElems[0].value=tryLink[0];
		tryLinkElems[1].value=tryLink[1];
		let panLink=JSON.parse(data.panLink);
		let panLinkElems=insertShop.querySelectorAll("[name='panLink[]']");
		panLinkElems[0].value=panLink[0];
		panLinkElems[1].value=panLink[1];
		
	});
	
	//插入关键字到框
	function pushTags(data) {
		if(!data) return;
		let insertShop=document.querySelector(".insertShop");
		let doms=insertShop.querySelectorAll("[name='tags[]']");
		let add=insertShop.querySelector(".addTags");
		for(let i=1; i<doms.length; i++) {
			let dom=doms[i].parentElement;
			dom.parentElement.removeChild(dom);
		}
		doms[0].value=data[0];
		for(let i=1; i<data.length; i++) {
			add.click();
			let dom=insertShop.querySelector(".tagsBox:last-of-type");
			let input=dom.querySelector("input");
			input.value=data[i];
		}
	}
}
//插入商品函数
function __insertShop() {
	let insertShop=document.querySelector(".insertShop");
	let form=insertShop.querySelector("form");
	let title=insertShop.querySelector(".title");
	title.innerHTML="插入商品";
	let idElem=insertShop.querySelector("[name=id]");
	idElem.parentElement.removeChild(idElem);
	form.action="php/insertShop.php";
	
	let inputs=insertShop.querySelectorAll("input");
	for(let i=0; i<inputs.length; i++)
		inputs[i].value="";
	
	clearTagsInputs();
	
	//清除tags框
	function clearTagsInputs() {
		let doms=insertShop.querySelectorAll(".tagsBox");
		for(let i=1; i<doms.length; i++)
			doms[i].parentElement.removeChild(doms[i]);
	}
	
}





















