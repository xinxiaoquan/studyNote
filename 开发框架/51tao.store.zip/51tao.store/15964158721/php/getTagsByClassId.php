<?php
require_once("base.php");
require_once("Mysql.class.php");
$mysql=new Mysql;

$id=@$_GET["id"];
$id||exit;

$res=$mysql->query("select json from `tags` where classId='{$id}'");
if(!$res) die("[]");
echo $res[0]["json"];