<?php
//require_once("base.php");
require_once("Mysql.class.php");
$mysql=new Mysql;

$todayTime=strtotime(date("Y-m-d", time()));
$todayTime*=1000;

$res=$mysql->query("select sum(shopPrice) as s from `order` where isOk=1 and time>={$todayTime}");
die($res[0]["s"]);
























