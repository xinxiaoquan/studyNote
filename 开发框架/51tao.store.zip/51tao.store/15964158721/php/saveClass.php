<?php
require_once("base.php");
require_once("Mysql.class.php");
$mysql=new Mysql;

$update=@$_GET["update"];
$update||exit;
$update=urldecode($update);
$update=json_decode($update);
$update=(array)$update;
$insert=@$_GET["insert"];
$insert||exit;
$insert=urldecode($insert);
$insert=json_decode($insert);

$classBox=$mysql->query("select id,name from `class`");
if(!$classBox) exit;
for($i=0; $i<count($classBox); $i++) {
	$id=$classBox[$i]["id"];
	$name=$classBox[$i]["name"];
	if(isset($update[$id]) 
		&& $update[$id]!=$name)
		$mysql->query("update `class` set name='{$update[$id]}' where id='{$id}'");
}
for($i=0; $i<count($insert); $i++) {
	$mysql->query("insert into `class` values(null, '{$insert[$i]}')");
	$insertId=$mysql->getPDO()->lastInsertId();
	$mysql->query("insert into `tags` values(null, '{$insertId}', '[]')");
}
die("1");























