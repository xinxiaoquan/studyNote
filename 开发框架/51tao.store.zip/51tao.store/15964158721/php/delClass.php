<?php
require_once("base.php");
require_once("Mysql.class.php");
$mysql=new Mysql;

$id=@$_GET["id"];
$id||exit;
$newId=@$_GET["newId"];
$newId||exit;

$mysql->query("delete from `class` where id='{$id}'");
$mysql->query("update shop set classId='{$newId}' where classId='{$id}'");

$res=$mysql->query("select json from tags where classId='{$id}'");
if(!$res) die("1");
$myIdJson=$res[0]["json"];
$myIdArr=json_decode($myIdJson);
$res=$mysql->query("select json from tags where classId='{$newId}'");
if(!$res) die("1");
$newIdJson=$res[0]["json"];
$newIdArr=json_decode($newIdJson);

$mysql->query("delete from tags where classId='{$id}'");

$mergeArr=array_merge($newIdArr, $myIdArr);
$mergeJson=json_encode($mergeArr, JSON_UNESCAPED_UNICODE);

$mysql->query("update tags set json='{$mergeJson}' where classId='{$newId}'");
die("1");























