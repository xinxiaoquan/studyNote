<?php
require_once("base.php");
require_once("Mysql.class.php");
$mysql=new Mysql;

$id=@$_GET["id"];
$id||exit;

$mysql->query("update shop set isShow=0 where id='{$id}'");
die("1");





























