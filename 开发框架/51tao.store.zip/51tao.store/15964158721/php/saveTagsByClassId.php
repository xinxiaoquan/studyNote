<?php
require_once("base.php");
require_once("Mysql.class.php");
$mysql=new Mysql;

$id=@$_GET["id"];
$id||exit;
$json=@$_GET["json"];
$json||exit;
$json=urldecode($json);

$mysql->query("update tags set json='{$json}' where classId={$id}");
die("1");




