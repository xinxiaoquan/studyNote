<?php
require_once("base.php");
require_once("Mysql.class.php");
$mysql=new Mysql;

$isShow=@$_GET["isShow"];
$isShow||exit;
$classId=@$_GET["classId"];
$classId||exit;
$title=@$_GET["title"];
$title||exit;
$tags=@$_GET["tags"];
if(!$tags) $tags=array();
for($i=0; $i<count($tags); $i++)
	if(!$tags[$i]) unset($tags[$i]);
$tags=json_encode($tags, JSON_UNESCAPED_UNICODE);
$click=0;
$price=@$_GET["price"];
$price||exit;
$type=@$_GET["type"];
$type||exit;
$size=@$_GET["size"];
$size||exit;
$tryLink=@$_GET["tryLink"];
$tryLink=json_encode($tryLink, JSON_UNESCAPED_UNICODE);
if(!$tryLink[0]) $tryLink="";
$panLink=@$_GET["panLink"];
$panLink||exit;
$panLink=json_encode($panLink, JSON_UNESCAPED_UNICODE);
$time=@$_GET["time"];
$time||exit;

$sql="insert into shop values(null, '{$isShow}', '{$classId}', '{$title}', '{$tags}', '{$click}', '{$price}', '{$type}', '{$size}', '{$tryLink}', '{$panLink}', '{$time}')";
$mysql->query($sql);

$sql="select json from tags where classId='{$classId}'";
$res=$mysql->query($sql);
$json=$res[0]["json"];
$array=json_decode($json);
$tagsArr=json_decode($tags);
for($i=0; $i<count($tagsArr); $i++) {
	for($j=0; $j<count($array); $j++)
		if($array[$j]==$tagsArr[$i]) break;
	if($j==count($array))
		$array[]=$tagsArr[$i];
}
$json=json_encode($array, JSON_UNESCAPED_UNICODE);
$mysql->query("update tags set json='{$json}' where classId='{$classId}'");

die("1");


























