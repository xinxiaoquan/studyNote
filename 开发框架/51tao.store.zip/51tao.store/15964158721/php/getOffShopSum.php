<?php
require_once("base.php");
require_once("Mysql.class.php");
$mysql=new Mysql;

$res=$mysql->query("select count(*) as c from shop where isShow=0");
echo $res[0]["c"];



























