<?php
require_once("base.php");
require_once("Mysql.class.php");
$mysql=new Mysql;

$id=@$_GET["id"];
$id||exit;

$res=$mysql->query("select count(*) as c from shop where classId='{$id}'");
if(!$res) die("0");
die($res[0]["c"]);



























