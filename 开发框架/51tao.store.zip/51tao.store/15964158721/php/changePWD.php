<?php
require_once("base.php");

$pwd=@$_GET["pwd"];
$pwd||exit;

$data="<?php exit;?> {\"pwd\":\"{$pwd}\"}";
file_put_contents("pwd.php", $data);
die("1");





