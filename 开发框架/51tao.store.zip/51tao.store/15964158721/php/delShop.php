<?php
require_once("base.php");
require_once("Mysql.class.php");
$mysql=new Mysql;

$id=@$_GET["id"];
$id||exit;

$mysql->query("delete from shop where id='{$id}'");
die("1");





























