<?php
require_once("base.php");
require_once("Mysql.class.php");
$mysql=new Mysql;

$id=@$_GET["id"];
$id||exit;
$isShow=@$_GET["isShow"];
$isShow||exit;
$classId=@$_GET["classId"];
$classId||exit;
$title=@$_GET["title"];
$title||exit;
$tags=@$_GET["tags"];
$tags||exit;
$tags=json_encode($tags, JSON_UNESCAPED_UNICODE);
$price=@$_GET["price"];
$price||exit;
$type=@$_GET["type"];
$type||exit;
$size=@$_GET["size"];
$size||exit;
$tryLink=@$_GET["tryLink"];
if($tryLink)
$tryLink=json_encode($tryLink, JSON_UNESCAPED_UNICODE);
else $tryLink="";
if(!$tryLink[0]) $tryLink="";
$panLink=@$_GET["panLink"];
$panLink||exit;
$panLink=json_encode($panLink, JSON_UNESCAPED_UNICODE);

$sql="update shop set isShow='{$isShow}',classId='{$classId}',title='{$title}',tags='{$tags}',price='{$price}',type='{$type}',size='{$size}',tryLink='{$tryLink}',panLink='{$panLink}' where id='{$id}'";
$mysql->query($sql);

$sql="select json from tags where classId='{$classId}'";
$res=$mysql->query($sql);
$json=$res[0]["json"];
$array=json_decode($json);
$tagsArr=json_decode($tags);
for($i=0; $i<count($tagsArr); $i++) {
	for($j=0; $j<count($array); $j++)
		if($array[$j]==$tagsArr[$i]) break;
	if($j==count($array))
		$array[]=$tagsArr[$i];
}
$json=json_encode($array, JSON_UNESCAPED_UNICODE);
$mysql->query("update tags set json='{$json}' where classId='{$classId}'");

die("1");


























