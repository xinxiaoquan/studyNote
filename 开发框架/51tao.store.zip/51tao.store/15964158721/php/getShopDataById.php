<?php
require_once("base.php");
require_once("Mysql.class.php");
$mysql=new Mysql;

$id=@$_GET["id"];
$id||die("[]");

$res=$mysql->query("select id,title,price,type,size from shop where id='{$id}'");
if(!$res) die("[]");
echo json_encode($res);




