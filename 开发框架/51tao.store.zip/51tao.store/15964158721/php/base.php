<?php
session_start();
if(!isset($_SESSION["admin"]))
	exit;
	
foreach($_REQUEST as $key=>$val)
	$_REQUEST[$key]=str_replace("'","\\'",$val);







