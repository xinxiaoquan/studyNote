<?php
require_once("base.php");
require_once("Mysql.class.php");
$mysql=new Mysql;

$classId=@$_GET["classId"];
$pageNo=@$_GET["pageNo"];
if(!$pageNo) $pageNo=1;

$sql="";
if($classId && $classId!=-1)
	$sql=" where classId='{$classId}' ";

$pageNum=30;
$start=($pageNo-1)*$pageNum;

$data=$mysql->query("select id,title,price,classId,size from shop {$sql} order by id desc limit {$start},{$pageNum}");

$res=$mysql->query("select count(*) as c from shop {$sql}");
$count=$res[0]["c"];

require_once("Page.class.php");
$p=new Page($pageNo,$pageNum, $count);
$data["length"]=count($data);
$data["bar"]=$p->getBar();
if($data["bar"]->pageCount==0)
	unset($data["bar"]);

die(json_encode($data));
























