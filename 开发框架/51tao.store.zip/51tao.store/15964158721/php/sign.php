<?php

$pwd=@$_GET["pwd"];
$pwd||exit;

$data=file_get_contents("pwd.php");
$data=str_replace("<?php exit;?>", "", $data);
$data=json_decode($data);

if($data->pwd==$pwd) {
	session_start();
	$_SESSION["admin"]=true;
	die("1");
}