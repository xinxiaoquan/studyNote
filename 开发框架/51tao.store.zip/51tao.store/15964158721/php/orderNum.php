<?php
//require_once("base.php");
require_once("Mysql.class.php");
$mysql=new Mysql;

$res=$mysql->query("select count(*) as c from `order` where isOk=1");
die($res[0]["c"]);
























