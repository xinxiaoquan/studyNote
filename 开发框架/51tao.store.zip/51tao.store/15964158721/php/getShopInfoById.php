<?php
require_once("base.php");
require_once("Mysql.class.php");
$mysql=new Mysql;

$id=@$_GET["id"];
$id||exit;

$res=$mysql->query("select * from shop where id='{$id}'");
if(!$res) die("{}");
echo json_encode($res[0]);























