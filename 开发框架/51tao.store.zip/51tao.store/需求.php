<?php exit?>

详情页需要有
	素材类型：
	素材大小：
	
	试看链接（按钮 复制提取码并打开云盘链接）
	
商品推荐逻辑
	拆分当前商品的tag，去匹配当前分类下的收费的产品，按照点击降序

百度联想词接口
	http://unionsug.baidu.com/su?wd=%E9%BA%BB%E8%BE%A3%E7%83%AB&cb=jsdfkjds
	
	
	
	









