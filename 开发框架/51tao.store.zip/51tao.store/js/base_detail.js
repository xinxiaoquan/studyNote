//获取分类
(function() {
	let classDom=document.querySelector(".info .class");
	ajax("/php/getClassByShopId.php?id="+GET.id,
	(data)=>{
		classDom.innerText=data;
	});
})();

//添加购物车
(function() {
	let shopCar=document.querySelector(".info .shopCar a");
	shopCar.onclick=function() {
		alert("正在检测资源是否有效……");
		ajax("/php/checkPanLink.php?id="+GET.id,
		(data)=>{
			if(data=="1") {
				ajax("/php/addShopCar.php?id="+GET.id,(data)=>{
					if(data=="1") {
						alert("添加购物车成功！");
						return;
					}
					if(data=="-1") {
						alert("您已经添加过购物车！");
						return;
					}
					alert("添加购物车失败！");
				});
				return;
			}
			alert("资源无效，已经下架！");
		});
		return false;
	}
})();

//立即购买
(function() {
	let buy=document.querySelector(".info .buy");
	buy.onclick=function() {
		alert("正在检测资源是否有效……");
		ajax(`/php/checkPanLink.php?id=${GET.id}`,
		(data)=>{
			if(data=="1") {
				ajax(`/php/buyThings.php?sid[]=${GET.id}&time=${new Date().getTime()}`,
				(orderKey)=>{
					if(!orderKey) alert("订单生成失败！");
					if(orderKey=="-1") {
						alert("您有的购买过，请到资源盒子中查看！");
						return;
					}
					let shopTitle=document.querySelector(".info .title").innerText;
					if(!shopTitle) shopTitle="";
					location.href=`/getMoney/?orderKey=${orderKey}&shopTitle=${shopTitle}`;
				});	
				return;
			}
			alert("资源无效，已经下架！");
		});
	}
})();
























