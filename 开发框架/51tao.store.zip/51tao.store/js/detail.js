//跳转不同设备
if(whatTer()=="phone") {
	location.href="/m_detail.html"+location.search;
}

//如果没有id属性
if(!GET.id) {
	location.href="/";
}

//获取详情数据信息
(function() {
	ajax("/php/getShopInfo.php?id="+GET.id,(data)=>{
		if(!data) {
			alert("资源已下架或删除！", ()=>{
				location.href="/";
			});
		}
		data=JSON.parse(data);
		document.title=data.title+"-51tao";
		let titleElem=document.querySelector(".info .title");
		titleElem.innerText=data.title;
		let tagsElem=document.querySelector(".info .tags");
		data.tags=JSON.parse(data.tags);
		for(let i=0; i<data.tags.length; i++) {
			if(!data.tags[i]) continue;
			let li=document.createElement("li");
			li.innerText=data.tags[i];
			li.onclick=function() {
				window.open("/?keyword="+this.innerText, "_blank");
			}
			tagsElem.appendChild(li);
		}
		console.log("click "+data.click);
		let priceElem=document.querySelector(".info .price");
		priceElem.innerText=data.price;
		let typeElem=document.querySelector(".info .type");
		typeElem.innerText=data.type;
		let sizeElem=document.querySelector(".info .size");
		sizeElem.innerText=data.size;
		let dateElem=document.querySelector(".info .date");
		dateElem.innerText=(function() {
			let date=new Date(Number(data.time));
			let year=date.getFullYear();
			let month=date.getMonth()+1;
			let day=date.getDate();
			
			return `${year}-${month}-${day}`;
		})();
		
		setDes(data.tryLink);
	});
})();

//设置主图
(function() {
	var picBox=document.querySelector(".main_pic .pic_box");
	var picSelect=document.querySelector(".main_pic .pic_select .box");
	getImages(`${GOODSIMGPATH}/${GET.id}/main_pic`, picSelect, {
		"mouseover":function() {
			var imgs=picBox.querySelectorAll("img");
			if(imgs.length>0)
			for(var i=0; i<imgs.length; i++)
				picBox.removeChild(imgs[i]);
			picBox.appendChild(this.cloneNode());
		}
	});
	setTimeout(function() {
		picBox.appendChild(picSelect.firstElementChild.cloneNode());	
	}, 3000);
})();

//设置详情
function setDes(tryLink) {
	var mainDes=document.querySelector(".main_des");
	if(tryLink) {
		tryLink=JSON.parse(tryLink);
		if(tryLink[0]) { 
			var tryElem=document.createElement("div");
			tryElem.className="try";
			tryElem.setAttribute("link", tryLink[0]);
			tryElem.setAttribute("code", tryLink[1]);
			tryElem.onclick=function() {
				copyText(this.getAttribute("code"),"提取码复制成功！");
				setTimeout(()=>{
					window.open(this.getAttribute("link"), "_blank");
				}, 888);
			}
			mainDes.appendChild(tryElem);
		}
	}
	var path=`${GOODSIMGPATH}/${GET.id}/detail`;
	getImages(path, mainDes);
}

//获取推荐商品
(function() {
	let list=document.querySelector(".recommend");
	ajax("/php/getRecommendShop.php?id="+GET.id, (data)=>{
		data=JSON.parse(data);
		writeRecommend(data, list);
	});
})();

//写入推荐商品函数
function writeRecommend(data, list) {
	for(var i=0; i<data.length; i++) {
		var li=document.createElement("li");
		let id=data[i].id;
		let img=document.createElement("img");
		img.src=`${IMGPATH}/goods/${id}/main_pic/1.jpg`;
		li.setAttribute("sid", id);
		var title=document.createElement("div");
		title.className="title";
		title.innerText=data[i].title;
		var price=document.createElement("div");
		price.className="price";
		price.innerText=data[i].price;
		li.appendChild(img);
		li.appendChild(title);
		li.appendChild(price);
		li.onclick=function(e) {
			let id=this.getAttribute("sid");
			ajax("php/addClick.php?id="+id);
			window.open("detail.html?id="+id,"_blank");
		}
		list.appendChild(li);
	}
}

//鼠标在主图上移动
(function() {
	var picBox=document.querySelector(".main_pic .pic_box");
	var maskElem=picBox.querySelector(".mask");
	var picShow=document.querySelector(".main_pic .pic_show");
	picBox.onmousemove=function(e) {
		let x=e.offsetX;
		let y=e.offsetY;
		if(y<112.5) y=112.5;
		if(y>337.5) y=337.5;
		if(x<112.5) x=112.5;
		if(x>337.5) x=337.5;
		x-=112.5;
		y-=112.5;
		maskElem.style.display="block";
		maskElem.style.left=x+"px";
		maskElem.style.top=y+"px";
		
		var imgPath=this.querySelector("img").src;
		picShow.style.display="block";
		picShow.style.backgroundImage=`url(${imgPath})`;
		picShow.style.backgroundPosition=`-${(x/450)*800}px -${(y/450)*800}px`;
	}
	picBox.onmouseout=function() {
		maskElem.style.display="none";
		picShow.style.display="none";
	}
})();

//推荐按钮
(function() {
	var leftBtn=document.querySelector(".recommend .left");
	leftBtn.onclick=function() {
		var parent=this.parentElement;
		if(!parent.hasAttribute("index"))
			parent.setAttribute("index", 0);
		var index=parent.getAttribute("index");
		var items=parent.querySelectorAll("li");
		index=parseInt(index)+1;
		if(index>=items.length) index=items.length-1;
		parent.setAttribute("index", index);
		for(var i=0; i<items.length; i++)
			items[i].style.transform=`translateX(-${index*200+index*18}px)`;
	}
	
	var rightBtn=document.querySelector(".recommend .right");
	rightBtn.onclick=function() {
		var parent=this.parentElement;
		if(!parent.hasAttribute("index"))
			parent.setAttribute("index", 0);
		var index=parent.getAttribute("index");
		index=parseInt(index)-1;
		if(index<0) index=0;
		parent.setAttribute("index", index);
		var items=parent.querySelectorAll("li");
		for(var i=0; i<items.length; i++)
			items[i].style.transform=`translateX(-${index*200+index*18}px)`;
	}
})();
















