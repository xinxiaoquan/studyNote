//跳转不同设备
if(whatTer()=="phone") {
	location.href="/m_index.html"+location.search;
}

//展开关键词（tag）列表
(function() {
	var elem=document.querySelector(".goods .tags .open");
	elem.onclick=function() {
		var group=elem.parentElement.querySelector(".group");
		if(elem.innerText=="展开") {
			elem.innerText="收起";
			group.style.height="auto";
			group.style.marginBottom="-5px";
			group.style.overflow="auto";
			return;
		}
		if(elem.innerText=="收起") {
			elem.innerText="展开";
			group.scrollTop=0;
			group.style.height="25px";
			group.style.marginBottom=0;
			group.style.overflow="hidden";
			return;
		}
	}
})();

//设置橱窗 show
(function() {
	var elem=document.querySelector(".goods .show");
	var img=document.createElement("img");
	img.src=IMGPATH+"/index_show/1.jpg";
	elem.appendChild(img);
})();

//侧边栏选中效果
(function() {
	let timer=setInterval(()=>{
		var elems=document.querySelectorAll(".nav>li[classid]");
		if(elems) clearInterval(timer);
		else return;
		for(var i=0; i<elems.length; i++) {
			elems[i].addEventListener("click", function() {
				navActive(this);
			});
		}
	}, 1000);
})();
//侧边栏选中函数
function navActive(dom) {
	var elems=document.querySelectorAll(".nav>li");
	for(var i=0; i<elems.length; i++)
		elems[i].className=elems[i].className.replace(/ ?active ?/, "");
	dom.className+=" active";
}


















