//跳转不同设备
if(whatTer()=="pc") {
	location.href="/index.html"+location.search;
}

//调出菜单
(function() {
	let menu=document.querySelector(".funs .menu");
	menu.onclick=function() {
		let menuBox=document.querySelector(".menu_box");
		menuBox.style.display="block";
		document.body.style.overflow="hidden";
	}
	
	if(GET && GET["menu"]=="true")
		menu.click();
})();
//退出菜单事件
(function() {
	let menuBox=document.querySelector(".menu_box");
	menuBox.onclick=function(e) {
		if(e.target.className=="menu_box") {
			this.style.display="none";
			document.body.style.overflow="";
		}
	}
})();

//展开关键字
(function() {
	var open=document.querySelector(".funs .tags .open");
	open.onclick=function() {
		let tagsBox=document.querySelector(".funs .tags");
		if(this.innerText=="展开") {
			tagsBox.style.height="auto";
			this.innerText="折叠";
			return false;
		}
		if(this.innerText=="折叠") {
			tagsBox.style.height="";
			this.innerText="展开";
		}
	}
})();

//加载更多
(function() {
	let addMore=document.querySelector(".addMore");
	addMore.onclick=function() {
		let list=document.querySelector(".goods");
		let pageNo=GET["pageNo"];
		if(!pageNo) GET.pageNo=2;
		else GET.pageNo++;
		ajax("php/search.php?"+ObjToQuery(GET),
		function(data) {
			data=JSON.parse(data);
			if(data.length==0) {
				addMore.style.display="none";
				delete GET.pageNo;
				return;
			}
			paintShoptoPage(data, list);
		});
	}
})();



















