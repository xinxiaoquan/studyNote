//获取购物车数据
//全局变量SHOPCAR存储购物车数据
window.SHOPCAR={};
function getShopCar() {
	ajax("php/getShopCar.php",
	function(data) {
		if(!data) return;
		SHOPCAR=JSON.parse(data);
	}, false);
}
getShopCar();

//获取我的资源
//全局变量BOX存储资源数据
window.BOX=[];
function getBox() {
	ajax("php/getBox.php",
	function(data) {
		if(!data) return;
		BOX=JSON.parse(data);
	}, false);
}
getBox();

//填充tag关键词
(function() {
	var elem=document.querySelector(".goods .tags .group");
	if(!elem)
		elem=document.querySelector(".tags .group");
	if(!elem) return;
	let classId=-1;
	if(GET.classId) classId=GET.classId;
	ajax("php/getTagsByClassId.php?classId="+classId, 
	function(data) {
		data=JSON.parse(data);
		let keywords={};
		for(let i=0; i<data.length; i++)
			keywords[data[i]]=true;
		for(let keyword in keywords) {
			if(!keyword) continue;
			var iElem=document.createElement("i");
			iElem.className="item";
			iElem.innerText=keyword;
			if(GET["keyword"] && 
				decodeURIComponent(GET["keyword"])==keyword)
				iElem.className+=" active";
			else
			iElem.onclick=function() {
				GET.keyword=this.innerText;
				location.href=clearURIQuery()+"?"+ObjToQuery(GET);
			}
			elem.appendChild(iElem);
		}	
	})
})();

//获取分类
(function() {
	let box=document.querySelector(".main .nav");
	if(!box)
		box=document.querySelector(".menu_box .list");
	if(!box) return;
	let li=document.createElement("li");
	li.setAttribute("classId", -1);
	li.innerText="全部分类";
	li.onclick=function() {
		GET.classId=-1;
		location.href="?"+ObjToQuery(GET);
	}
	box.appendChild(li);
	ajax("php/getClass.php", function(data) {
		data=JSON.parse(data);
		for(let i=0; i<data.length; i++) {
			let li=document.createElement("li");
			li.setAttribute("classId", data[i]["id"]);
			li.innerText=data[i]["name"];
			if(GET["classId"] && GET["classId"]==data[i]["id"]) {
				li.className+=" active";
				document.title=`[${data[i]["name"]}]分类-${document.title}`;
				let crumbs=document.querySelector(".crumbs");
				crumbs.style.display="block";
				let item=document.createElement("span");
				item.innerHTML=data[i]["name"]+"(分类)";
				let close=document.createElement("b");
				close.onclick=function() {
					delete GET.classId;
					let url=clearURIQuery();
					if(Object.keys(GET)!=0)
						url=url+"?"+ObjToQuery(GET);
					location.href=url;
				}
				item.appendChild(close);
				let firstChild=crumbs.firstChild;
				if(firstChild)
					crumbs.insertBefore(item, firstChild);
				else crumbs.appendChild(item);
			}
			li.onclick=function() {
				let classId=this.getAttribute("classId");
				GET.classId=classId;
				location.href="?"+ObjToQuery(GET);
			}
			box.appendChild(li);
		}
	});
})();

//用户注册
(function() {
	let menuBox=document.querySelector(".menu_box");
	var regBtn=document.querySelector(".user .reg");
	if(!regBtn) return false;
	regBtn.onclick=function() {
		if(menuBox) menuBox.click();
		alert(`
			<form action="php/reg.php" >
				<input type="text" autocomplete="off" name="user" placeholder="输入用户名" />
				<input type="text" autocomplete="off" name="ask" placeholder="输入验证问题" />
				<input type="text" autocomplete="off" name="answer" placeholder="输入答案" />
				<input type="hidden" name="time" />
				<input type="submit" />
			</form>
		`);
		
		let form=document.querySelector(".alert form");
		let time=document.querySelector(".alert [name=time]");
		time.value=new Date().getTime();
		let user=document.querySelector(".alert [name=user]");
		user.onblur=function() {
			let data=this.value;
			ajax("php/getAsk.php?user="+data,(info)=>{
				if(info) {
					alert("用户名已经存在！请更换用户名！",
					function() {
						regBtn.click();
					});
					return;
				}
			})
		}
		sendFormAjax(form, function(data) {
			if(data=="1") {
				alert("注册成功！赶快登录吧！");
				return;
			}
			alert("注册失败！", function() {
				regBtn.click();
			});
		});
	}
	
	if(GET && GET["reg"]=="true")
		regBtn.click();
})();

//用户登录
(function() {
	let menuBox=document.querySelector(".menu_box");
	var signBtn=document.querySelector(".user .sign");
	if(!signBtn) return false;
	signBtn.onclick=function() {
		if(menuBox) menuBox.click();
		alert(`
			<form action="php/sign.php" >
				<input type="text" autocomplete="off" name="user" placeholder="输入用户名" />
				<input type="text" autocomplete="off" disabled="true" name="ask" placeholder="问题" />
				<input type="text" autocomplete="off" disabled="true" name="answer" placeholder="输入答案" />
				<input type="submit" />
			</form>
		`);
		
		let form=document.querySelector(".alert form");
		let user=document.querySelector(".alert [name=user]");
		let ask=document.querySelector(".alert [name=ask]");
		let answer=document.querySelector(".alert [name=answer]");
		user.onblur=function() {
			let data=this.value;
			if(!data) {
				alert("请输入用户名",()=>{
					signBtn.click();
				});
				return false;
			}
			ajax("php/getAsk.php?user="+data,
			function(info) {
				if(!info) {
					alert("用户名有误！",()=>{
						signBtn.click();
					});
					return false;
				}
				ask.value=info;
				answer.disabled=false;
			});
		}
		sendFormAjax(form, function(data) {
			if(!data) {
				alert("登录失败！",()=>{
					signBtn.click();
				});
				return;
			}
			alert("登录成功！");
			location.href=location.href;
		});
	}

	if(GET && GET["sign"]=="true")
		signBtn.click();
})();

//我的资源
(function() {
	var myBox=document.querySelector(".user .my_box");
	if(!myBox) return false;
	let menuBox=document.querySelector(".menu_box");
	myBox.onclick=function() {
		if(menuBox) menuBox.click();
		getBox();
		drawBox(BOX);
	}
	
	function drawBox(data) {
		let result=document.createElement("ul");
		result.className="result";
		if(data.length==0)
			result="资源盒子为空！";
		else {
			let download=document.createElement("div");
			download.className="download";
			download.innerText="保存为文本信息";
			download.onclick=function() {
				let doms=this.parentElement.querySelectorAll("li");
				ajaxDownload("/php/downloadBox.php", "我的资源.txt");
			}
			result.appendChild(download);
			for(let i=0; i<data.length; i++) {
				let li=document.createElement("li");
				li.setAttribute("panLink", data[i].shopPanLink);
				let key=document.createElement("div");
				key.className="key";
				key.innerText=data[i].orderKey;
				li.appendChild(key);
				let title=document.createElement("div");
				title.className="title";
				let a=document.createElement("a");
				a.innerText=data[i].shopTitle;
				a.href="/detail.html?id="+data[i].shopId;
				a.target="_blank";
				title.appendChild(a);
				li.appendChild(title);
				let copy=document.createElement("div");
				copy.className="copy";
				copy.innerText="复制云盘链接及提取码";
				copy.onclick=function() {
					let tmp=this.parentElement.getAttribute("panLink");
					tmp=JSON.parse(tmp);
					let link=tmp[0];
					let code=tmp[1];
					copyText(`链接：${link} 提取码：${code}`);
					if(this.innerText.indexOf("复制成功")==-1)
						this.innerText+="(复制成功)";
				}
				let open=document.createElement("div");
				open.className="open";
				open.innerText="复制提取码并打开云盘链接";
				open.onclick=function() {
					let tmp=this.parentElement.getAttribute("panLink");
					tmp=JSON.parse(tmp);
					let link=tmp[0];
					let code=tmp[1];
					copyText(code);
					if(this.innerText.indexOf("复制成功")==-1)
						this.innerText+="(复制成功)";
					setTimeout(function() {
						window.open(link, "_blank");
					}, 888);
				}
				li.appendChild(copy);
				li.appendChild(open);
				result.appendChild(li);
			}
		}
		alert(result);
	}
	
	if(GET && GET["my_box"]=="true")
		myBox.click();
})();

//购物车
(function() {
	let shopCarBtn=document.querySelector(".user .shop_car");
	if(!shopCarBtn) return false;
	
	let menuBox=document.querySelector(".menu_box");
	shopCarBtn.onclick=function() {
		if(menuBox) menuBox.click();
		getShopCar();
		if(Object.keys(SHOPCAR).length==0) {
			alert("购物车为空！");
			return false;
		}
		
		let result=document.createElement("ul");
		result.className="result";
		result.innerHTML="<h3>购物车</h3>";
		let all=document.createElement("div");
		all.className="all";
		all.innerText="全选";
		all.onclick=function() {
			let checkboxes=document.querySelectorAll(".alert .result input[type=checkbox]");
			for(let i=0; i<checkboxes.length; i++)
				checkboxes[i].click();
		}
		result.appendChild(all);
		let del=document.createElement("div");
		del.className="del";
		del.innerText="删除";
		del.onclick=function() {
			let doms=document.querySelectorAll(".alert li.active");
			let sids=[];
			for(let i=0; i<doms.length; i++) {
				let div=doms[i].querySelector("div[sid]");
				sids.push(div.getAttribute("sid"));
			}
			let ids=JSON.stringify(sids);
			ajax(`/php/delShopCars.php?ids=${ids}`,callback);
			
			function callback(data) {
				if(data) {
					let lis=document.querySelectorAll(".alert li.active");
					for(let i=0; i<lis.length; i++) {
						let checkbox=lis[i].querySelector("input[type=checkbox]");
						checkbox.click();
						lis[i].parentElement.removeChild(lis[i]);
					}
					return;
				}
				alert("删除失败！");
			}
		}
		result.appendChild(del);
		let pay=document.createElement("div");
		pay.className="pay";
		pay.innerText="结算";
		pay.onclick=function() {
			let doms=document.querySelectorAll(".alert .result li.active div[sid]");
			if(!doms.length) return;
			let str="";
			for(let i=doms.length-1; i>=0; i--) {
				sid=doms[i].getAttribute("sid");
				str+=`sid[]=${sid}&`;
			}
			let del=this.parentElement.querySelector(".del");
			del.click();
			ajax(`/php/buyThings.php?${str}time=${new Date().getTime()}`,
			(orderKey)=>{
				if(!orderKey) alert("订单生成失败！");
				if(orderKey=="-1") {
					alert("您有的购买过，请到资源盒子中查看！");
					return;
				}
				location.href=`/getMoney/?orderKey=${orderKey}`;
			});
		}
		result.appendChild(pay);
		let total=document.createElement("div");
		total.className="total";
		total.innerText=0;
		result.appendChild(total);
		for(let key in SHOPCAR) {
			let li=document.createElement("li");
			let checkbox=document.createElement("input");
			checkbox.type="checkbox";
			li.appendChild(checkbox);
			checkbox.onclick=function() {
				let parent=this.parentElement;
				let price=parent.querySelector(".price");
				let total=parent.parentElement.querySelector(".total");
				if(this.checked) {
					let num=Number(total.innerText)+Number(price.innerText);
					total.innerText=num.toFixed(2);
					this.parentElement.className="active";
				} else {
					let num=Number(total.innerText)-Number(price.innerText);
					total.innerText=num.toFixed(2);
					this.parentElement.className="";
				}
			}
			let title=document.createElement("div");
			title.setAttribute("sid", key);
			let a=document.createElement("a");
			a.innerText=SHOPCAR[key].title;
			a.href="/detail.html?id="+key;
			a.target="_blank";
			let price=document.createElement("span");
			price.className="price";
			price.innerText=SHOPCAR[key].price;
			title.appendChild(a)
			title.appendChild(price)
			li.appendChild(title);
			result.appendChild(li);
		}
		
		alert(result);
	}
	
	if(GET && GET["shop_car"]=="true")
		shopCarBtn.click();
})();

//筛选数据
(function() {
	let order=GET["order"];
	if(!order)
		order="time";
	let sort=GET["sort"];
	if(!sort)
		sort="desc";
	let timeElem=document.querySelector(".filter [order=time]");
	let clickElem=document.querySelector(".filter [order=click]");
	if(order=="time")
		timeElem.className+=" active";
	if(order=="click")
		clickElem.className+=" active";
	let orderElem=document.querySelector(".filter .active");
	if(sort=="desc")
		orderElem.setAttribute("sort", "desc");
	if(sort=="asc")
		orderElem.setAttribute("sort", "asc");
		
	timeElem.onclick=function() {
		let sort=this.getAttribute("sort");
		if(sort=="desc")
			sort="asc";
		else sort="desc";
		target("time", sort);
	}
	clickElem.onclick=function() {
		let sort=this.getAttribute("sort");
		if(sort=="desc")
			sort="asc";
		else sort="desc";
		target("click", sort);
	}
	
	function target(order, sort) {
		GET.sort=sort;
		GET.order=order;
		let url=clearURIQuery()+"?"+ObjToQuery(GET);
		location.href=url;
	}
})();

//获取商品数据
(function() {
	let list=document.querySelector(".goods .list");
	if(!list)
		list=document.querySelector(".goods");
	if(!list) return;
	if(GET.classId) {
		let num=0;
		let timer=setInterval(function(){
			let elem=document.querySelector(`[classId="${GET.classId}"]`);
			if(elem) {
				elem.className+=" active";
				clearInterval(timer);
			}
			if(num++>=20) clearInterval(timer);
		},1000);
	}
	if(GET.keyword) {
		GET.keyword=decodeURIComponent(GET.keyword);
		let input=document.querySelector(".head .search input");
		input.value=GET.keyword;
		document.title=`[${GET.keyword}]搜索结果-51tao`;
		let crumbs=document.querySelector(".crumbs");
		crumbs.style.display="block";
		let item=document.createElement("span");
		item.innerHTML=GET.keyword+"(关键字)";
		let close=document.createElement("b");
		close.onclick=function() {
			delete GET.keyword;
			let url=clearURIQuery();
			if(Object.keys(GET)!=0)
				url=url+"?"+ObjToQuery(GET);
			location.href=url;
		}
		item.appendChild(close);
		crumbs.appendChild(item);
	}
	if(!GET.classId) delete GET.classId;
	ajax(`php/search.php?${ObjToQuery(GET)}`,
	function(data) {
		data=JSON.parse(data);
		if(data.length==0) {
			let pageBar=document.querySelector(".page_bar");
			if(pageBar) pageBar.style.display="none";
			return;
		}
		paintShoptoPage(data, list);
	});
	
})();

//渲染商品数据到网页
function paintShoptoPage(data, list) {
	for(var i=0; i<data.length; i++) {
		var li=document.createElement("li");
		let id=data[i].id;
		let img=document.createElement("img");
		img.src=`${IMGPATH}/goods/${id}/main_pic/1.jpg`;
		li.setAttribute("sid", id);
		var title=document.createElement("div");
		title.className="title";
		title.innerText=data[i].title;
		var price=document.createElement("div");
		price.className="price";
		price.innerText=data[i].price;
		li.appendChild(img);
		li.appendChild(title);
		li.appendChild(price);
		li.onclick=function(e) {
			let id=this.getAttribute("sid");
			ajax("php/addClick.php?id="+id);
			window.open("detail.html?id="+id,"_blank");
		}
		list.appendChild(li);
	}
	
	let bar=data.bar;
	let pageBar=document.querySelector(".page_bar");
	if(!pageBar) return false;
	pageBar.appendChild(createPage("first", 1));
	for(let i=0; i<bar.front.length; i++)
		pageBar.appendChild(createPage("", bar.front[i]));
	pageBar.appendChild(createPage("active", bar.active));
//	debugger;
	for(let i=0; i<bar.end.length; i++)
		pageBar.appendChild(createPage("", bar.end[i]));
	pageBar.appendChild(createPage("last", bar.pageCount));
	pageBar.appendChild(createPage("page_count", bar.pageCount));
		
	function createPage(special, pageNo) {
		let page=document.createElement("div");
		page.className="page_no";
		page.innerText=pageNo;
		page.setAttribute("pageNo", pageNo);
		page.onclick=function() {
			let pageNo=this.getAttribute("pageNo");
			GET.pageNo=pageNo;
			location.href=clearURIQuery()+"?"+ObjToQuery(GET);
		}
		if(special=="first") {
			page.className+=" first";
			page.innerText="首页";
		}
		if(special=="last") {
			page.className+=" last";
			page.innerText="尾页";
		}
		if(special=="active") {
			page.className+=" active";
			page.onclick=null;
		}
		if(special=="page_count") {
			page.className="page_count";
			page.onclick=null;
		}
		return page;
	}
}