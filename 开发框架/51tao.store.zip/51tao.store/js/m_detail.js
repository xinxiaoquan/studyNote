//跳转不同设备
if(whatTer()=="pc") {
	location.href="/detail.html"+location.search;
}

//设置主图
(function() {
	let show=document.querySelector(".main_pic .show");
	let select=document.querySelector(".main_pic .select");
	getImages(`${GOODSIMGPATH}/${GET.id}/main_pic/`, select, 
	{
		click:function() {
			show.innerHTML="";
			show.appendChild(this.cloneNode());
		}
	});
	let timer=setInterval(()=>{
		let fristImg=document.querySelector(".main_pic .select img");
		if(fristImg) {
			fristImg.click();
			clearInterval(timer);
		}
	}, 1000);
})();

//获取详情数据信息
(function() {
	ajax("/php/getShopInfo.php?id="+GET.id,(data)=>{
		if(!data) {
			alert("资源已下架或删除！", ()=>{
				location.href="/";
			});
		}
		data=JSON.parse(data);
		document.title=data.title+"-51tao";
		let titleElem=document.querySelector(".info .title");
		titleElem.innerText=data.title;
		let tagsElem=document.querySelector(".info .tags");
		data.tags=JSON.parse(data.tags);
		for(let i=0; i<data.tags.length; i++) {
			if(!data.tags[i]) continue;
			let li=document.createElement("li");
			li.innerText=data.tags[i];
			li.onclick=function() {
				window.open("/?keyword="+this.innerText, "_blank");
			}
			tagsElem.appendChild(li);
		}
		let priceElem=document.querySelector(".info .price");
		priceElem.innerText=data.price;
		let typeElem=document.querySelector(".info .type");
		typeElem.innerText=data.type;
		let sizeElem=document.querySelector(".info .size");
		sizeElem.innerText=data.size;
		let dateElem=document.querySelector(".info .date");
		dateElem.innerText=(function() {
			let date=new Date(Number(data.time));
			let year=date.getFullYear();
			let month=date.getMonth()+1;
			let day=date.getDate();
			
			return `${year}-${month}-${day}`;
		})();
		
		setDes(data.tryLink);
	});
})();

//设置详情函数
function setDes(tryLink) {
	var mainDes=document.querySelector(".main_des");
	if(tryLink) {
		tryLink=JSON.parse(tryLink);
		if(tryLink[0]) {
			var tryElem=document.createElement("div");
			tryElem.className="try";
			tryElem.setAttribute("link", tryLink[0]);
			tryElem.setAttribute("code", tryLink[1]);
			tryElem.onclick=function() {
				copyText(this.getAttribute("code"),"提取码复制成功！");
				setTimeout(()=>{
					window.open(this.getAttribute("link"), "_blank");
				}, 888);
			}
			mainDes.appendChild(tryElem);
		}
	}
	var path=`${GOODSIMGPATH}/${GET.id}/detail`;
	getImages(path, mainDes);
}

//加载全部详情
(function() {
	let more=document.querySelector(".main_des_more");
	more.onclick=function() {
		let des=document.querySelector(".main_des");
		des.style.height="auto";
		des.style.opacity=1;
		this.style.display="none";
	}
})();

//获取推荐商品
(function() {
	let list=document.querySelector(".recommend");
	ajax("/php/getRecommendShop.php?id="+GET.id, (data)=>{
		data=JSON.parse(data);
		writeRecommend(data, list);
	});
})();

//写入推荐商品函数
function writeRecommend(data, list) {
	for(var i=0; i<data.length; i++) {
		var li=document.createElement("li");
		let id=data[i].id;
		let img=document.createElement("img");
		img.src=`${IMGPATH}/goods/${id}/main_pic/1.jpg`;
		li.setAttribute("sid", id);
		var title=document.createElement("div");
		title.className="title";
		title.innerText=data[i].title;
		var price=document.createElement("div");
		price.className="price";
		price.innerText=data[i].price;
		li.appendChild(img);
		li.appendChild(title);
		li.appendChild(price);
		li.onclick=function(e) {
			let id=this.getAttribute("sid");
			ajax("php/addClick.php?id="+id);
			window.open("detail.html?id="+id,"_blank");
		}
		list.appendChild(li);
	}
}




