//获取get数据
//全局变量GET存储get数据
window.GET={};
(function() {
	let data=location.search;
	data=data.replace(/^\?/, "");
	if(data=="") return;
	data=data.split("&");
	for(let i=0; i<data.length; i++) {
		let tmp=data[i].split("=");
		window.GET[tmp[0]]=tmp[1];
	}
})();

//判断有没有登录
//全局变量USER存储用户数据
window.USER=false;
(function() {
	ajax("php/isSign.php", function(info) {
		if(!info) return;
		info=JSON.parse(info);
		let reg=document.querySelector(".reg");
		if(reg) reg.style.display="none";
		let sign=document.querySelector(".sign");
		if(sign) sign.style.display="none";
		let userName=document.querySelector(".user .name");
		if(userName)
			userName.innerText=info.user;
		window.USER=info;
	}, false);
})();

//跳转不同设备函数
function whatTer() {
	var sUserAgent = navigator.userAgent.toLowerCase();
	var bIsIpad = sUserAgent.match(/ipad/i) == 'ipad';
	var bIsIphone = sUserAgent.match(/iphone os/i) == 'iphone os';
	var bIsMidp = sUserAgent.match(/midp/i) == 'midp';
	var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == 'rv:1.2.3.4';
	var bIsUc = sUserAgent.match(/ucweb/i) == 'web';
	var bIsCE = sUserAgent.match(/windows ce/i) == 'windows ce';
	var bIsWM = sUserAgent.match(/windows mobile/i) == 'windows mobile';
	var bIsAndroid = sUserAgent.match(/android/i) == 'android';
	if(bIsIpad || bIsIphone || bIsMidp || bIsUc7 || bIsUc || bIsCE || bIsWM || bIsAndroid )
		return "phone";
	else return "pc";
}

//重写alert
function alert(mess, callback) {
	var alertElem=document.querySelector(".alert");
	if(!alertElem) return false;
	alertElem.callback=callback;
	var messElem=alertElem.querySelector(".mess");
	messElem.innerText="";
	if(mess instanceof Object)
		messElem.appendChild(mess);
	else messElem.innerHTML=mess;
	alertElem.style.display="block";
	document.body.style.overflow="hidden";
}
//注册alert事件
(function() {
	var alertElem=document.querySelector(".alert");
	if(!alertElem) return false;
	alertElem.onclick=function(e) {
		if(e.target.className.indexOf("alert")!=-1) {
			this.style.display="none";
			document.body.style.overflow="auto";
			if(this.callback) this.callback();
		}
	}
})();

//设置logo
(function() {
	var elem=document.querySelector(".head .logo");
	if(!elem) return;
	elem.style.backgroundImage=`url(${IMGPATH}/logo.png)`;
	elem.onclick=function() {
		location.href="/";
	}
})();

//搜索按钮
(function() {
	let input=document.querySelector(".head .search input");
	let btn=document.querySelector(".head .search button");
	btn.onclick=fn;
	input.onkeydown=function(e) {
		if(e.keyCode==13)
			fn();
	}
	function fn() {
		if(input.value=="") return;
		location.href="/?"+ObjToQuery({keyword:input.value});
	}
})();

//复制函数
function copyText(text, mess) {
	let box=document.createElement("textarea");
	box.value=text;
	box.style.marginLeft="-10000px";
	document.body.appendChild(box);
	box.select();
	document.execCommand("copy");
	document.body.removeChild(box);
	if(mess) alert(mess);
}

//加载效果
function loading(status) {
	return;
	let loadingElem=document.querySelector(".loading");
	if(status) {
		if(loadingElem)
			loadingElem.style.display="none";
		return false;
	}
	if(loadingElem)
		loadingElem.style.display="block";
	else {
		loadingElem=document.createElement("div");
		loadingElem.className="loading";
		document.body.appendChild(loadingElem);
	}
}

//封装异步请求
function ajax(url, fun, isAsync=true) {
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if (fun) fun(this.responseText);
		}
	}
	xhr.open("get", url, isAsync);
	xhr.send(null);
}

//改造发送form为ajax的方式
function sendFormAjax(form, fn) {
	if(!form) return;
	form.onsubmit=function() {
		let url=form.getAttribute("action");
		let doms=form.querySelectorAll("[name]");
		let query="";
		for(let i=0; i<doms.length; i++) {
			let key=doms[i]["name"];
			let value=doms[i].value;
			query+=`${key}=${value}&`;
		}
		query=query.substring(0, query.length-1);
		ajax(`${url}?${query}`, fn);
		return false;
	}
}

//加载图片函数
function getImages(path, parent, eventObj, index=1) {
	var img=document.createElement("img");
	img.src=`${path}/${index}.jpg`;
	img.onload=function() {
		parent.appendChild(this);
		if(eventObj)
		for(var key in eventObj) {
			this.addEventListener(key, eventObj[key]);
		}
		getImages(path, parent, eventObj, ++index);
	}
}

//对象格式化url的query数据
function ObjToQuery(data) {
	let res="";
	for(let key in data)
		res+=`${key}=${data[key]}&`;
	res=res.substring(0, res.length-1);
	return res;
}

//清除url参数
function clearURIQuery() {
	let search=location.search;
	return location.href.replace(search, "");
}

//异步下载文件
function ajaxDownload(url, fileName) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);    // 也可以使用POST方式，根据接口
    //xhr.responseType = "blob";
    xhr.onload = function () {
        if (this.status === 200) {
            var content = this.response;
            var aTag = document.createElement('a');
            var blob = new Blob([content]);
            aTag.download = fileName;
            aTag.href = URL.createObjectURL(blob);
            aTag.click();
            URL.revokeObjectURL(blob);
        }
    };
    xhr.send()
}









