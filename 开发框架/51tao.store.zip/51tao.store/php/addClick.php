<?php
require_once("base.php");
require_once("tools/Mysql.class.php");
$mysql=new Mysql;

$id=@$_GET["id"];
$id||exit;

$mysql->exec("update shop set click=click+1 where id={$id}");




