<?php
require_once("base.php");
require_once("tools/Mysql.class.php");
$mysql=new Mysql;

$user=@$_GET["user"];
$user||exit;

$res=$mysql->query("select ask from account where user='{$user}'");
echo $res[0]["ask"];



























