<?php
session_start();
if(!isset($_SESSION["user"]))
	exit;
echo json_encode($_SESSION);


