<?php
foreach($_REQUEST as $key=>$val)
	$_REQUEST[$key]=str_replace("'","\\'",$val);

function alert($mess) {
	echo "<script>alert('{$mess}')</script>";
}

function closeWindow() {
	echo "<script>window.close()</script>";
}