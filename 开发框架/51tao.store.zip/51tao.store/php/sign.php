<?php
require_once("base.php");
require_once("tools/Mysql.class.php");
$mysql=new Mysql;

$user=@$_REQUEST["user"];
$user||exit;
$answer=@$_REQUEST["answer"];
$answer||exit;

$res=$mysql->query("select id from account where user='{$user}' and answer='{$answer}'");
if($res) {
	session_start();
	$id=$res[0]["id"];
	$_SESSION["user"]=$user;
	$_SESSION["userId"]=$id;
	die("1");
}



