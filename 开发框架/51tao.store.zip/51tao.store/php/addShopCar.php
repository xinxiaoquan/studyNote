<?php
require_once("base.php");
session_start();

$id=@$_REQUEST["id"];
$id||exit;
$userId=$_SESSION["userId"];

require_once("tools/Mysql.class.php");
$mysql=new Mysql;
$res=$mysql->query("select title,price from shop where id='{$id}'");
if(!$res) exit;
$shopTitle=$res[0]["title"];
$shopPrice=$res[0]["price"];

if($userId) {
	$res=$mysql->query("select count(*) as c from shopCar where userId='{$userId}' and shopId='{$id}'");
	if($res[0]["c"]>0) die("1");
	$mysql->query("insert into shopCar values(null, '{$userId}', '{$id}', '{$shopTitle}', '{$shopPrice}')");
	die("1");
}

if(!isset($_SESSION["tmpShopCar"]))
	$_SESSION["tmpShopCar"]=array();
if(isset($_SESSION["tmpShopCar"][$id]))
	die("-1");
$_SESSION["tmpShopCar"][$id]=array(
	"title"=>$shopTitle,
	"price"=>$shopPrice
);
die("1");



















