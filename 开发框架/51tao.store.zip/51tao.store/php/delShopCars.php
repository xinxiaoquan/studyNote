<?php
require_once("base.php");
session_start();

$ids=@$_GET["ids"];
$ids||exit;
$ids=json_decode($ids);
$userId=@$_SESSION["userId"];

require_once("tools/Mysql.class.php");
$mysql=new Mysql;

if($userId) {
	$sql=implode(",", $ids);
	$sql="delete from shopCar where shopId in({$sql})";
	$mysql->query($sql);
	die("1");
}

if(!isset($_SESSION["tmpShopCar"]))
	exit;
for($i=0; $i<count($ids); $i++)
	unset($_SESSION["tmpShopCar"][$ids[$i]]);
die("1");
























