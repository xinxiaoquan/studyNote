<?php
session_start();

require_once("tools/Mysql.class.php");
$mysql=new Mysql;
$userId=$_SESSION["userId"];

if($userId) {
	$res=$mysql->query("select orderKey,shopId,shopPanLink,shopTitle from box where userId='{$userId}' order by id desc");
	if(!$res) exit;
	die(json_encode($res, JSON_UNESCAPED_UNICODE));
}

if(isset($_SESSION["tmpBox"])) {
	$tmpData=[];
	$tmpBox=$_SESSION["tmpBox"];
	for($i=0; $i<count($tmpBox); $i++) {
		$orderKey=$tmpBox[$i];
		$res=$mysql->query("select shopId from `order` where orderKey='{$orderKey}' and isOk=1");
		if(!$res) continue;
		for($j=0; $j<count($res); $j++) {
			$shopId=$res[$j]["shopId"];
			$data=$mysql->query("select title,price,panLink from shop where id='{$shopId}'");
			$tmpData[]=array(
				"orderKey"=>$orderKey,
				"shopTitle"=>$data[0]["title"],
				"shopPrice"=>$data[0]["price"],
				"shopPanLink"=>$data[0]["panLink"]
			);
		}
	}
	die(json_encode($tmpData, JSON_UNESCAPED_UNICODE));
}





















