<?php
require_once("base.php");

$keyword=@$_GET["keyword"];
if($keyword)
	$keyword=urldecode($keyword);
$keyword=strtolower($keyword);
$pageNo=@$_GET["pageNo"];
if(!$pageNo) $pageNo=1;
$pageNum=@$_GET["pageNum"];
if(!$pageNum) $pageNum=20;
$order=@$_GET["order"];
if(!$order) $order="time";
$sort=@$_GET["sort"];
if(!$sort) $sort="desc";
$classId=@$_GET["classId"];

require_once("tools/Mysql.class.php");
$mysql=new Mysql;
$start=($pageNo-1)*$pageNum;
if($classId && $classId!=-1) 
	$classIdSql=" classId='{$classId}' ";
else $classIdSql="";
$orderSql=" order by `{$order}` {$sort} ";
if($keyword)
	$keywordSql=" (title like '%{$keyword}%' or tags like '%{$keyword}%') ";
else $keywordSql="";
if($classIdSql)
	$and1=" and ";
else $and1="";
if($keywordSql)
	$and2=" and ";
else $and2="";
$where=" where isShow=1 ";
$sql="select id,title,price from shop {$where} {$and1} {$classIdSql} {$and2} {$keywordSql} {$orderSql} limit {$start},{$pageNum}";
//die($sql);
$res=$mysql->query($sql);

require_once("tools/Page.class.php");
$count=$mysql->query("select count(*) as c from `shop` {$where} {$and1} {$classIdSql} {$and2} {$keywordSql}");
$count=$count[0]["c"];

$p=new Page($pageNo,$pageNum,$count);

$res["length"]=count($res);
$res["bar"]=$p->getBar();
echo json_encode($res);


























