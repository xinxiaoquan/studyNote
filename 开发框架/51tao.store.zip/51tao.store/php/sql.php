/*<?php exit?>*/

/*关键字（tag标签）*/
create table tags(
	id int unsigned primary key auto_increment,
	classId text,
	json text
);

/*分类*/
create table class(
	id int unsigned primary key auto_increment,
	name text
);

/*账户*/
create table account(
	id int unsigned primary key auto_increment,
	user text,
	ask text,
	answer text,
	time text
);

/*购物车*/
create table shopCar(
	id int unsigned primary key auto_increment,
	userId text,
	shopId text,
	shopTitle text,
	shopPrice text
);

/*资源盒子（订单）*/
create table box(
	id int unsigned primary key auto_increment,
	orderKey text,
	userId text,
	shopId text,
	shopTitle text,
	shopPanLink text,
	shopPrice text,
	time text
);

/*商品*/
create table shop(
	id int unsigned primary key auto_increment,
	isShow tinyint,
	classId text,
	title text,
	tags text,
	click int unsigned,
	price text,
	type text,
	size text,
	tryLink text,
	panLink text,
	time text
);

//订单表
create table `order`(
	id int unsigned primary key auto_increment,
	orderKey text,
	userId text,
	shopId text,
	shopPrice text,
	isOk tinyint,
	time text
);


























