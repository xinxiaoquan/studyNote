<?php
require_once("base.php");
require_once("tools/Mysql.class.php");
$mysql=new Mysql;

$classId=@$_GET["classId"];
$classId||exit;

if($classId==-1) {
	$res=$mysql->query("select json from tags");
	$json=array();
	for($i=0; $i<count($res); $i++) {
		$tmp=$res[$i]["json"];
		$tmp=json_decode($tmp);
		$json=array_merge($json, $tmp);
	}
	$json=json_encode($json, JSON_UNESCAPED_UNICODE);
} else {
	$json=$mysql->query("select json from tags where classId='{$classId}'");
	if($json) $json=$json[0]["json"];
	else $json="[]";
}

echo $json;