<?php
require_once("base.php");
require_once("tools/Mysql.class.php");
$mysql=new Mysql;

$user=@$_REQUEST["user"];
$user||exit;
$time=@$_REQUEST["time"];
$time||exit;
$hasUser=$mysql->query("select count(*) as c from account where user='{$user}'");
if($hasUser[0]["c"]!="0") {
	die("-1");
}
$ask=@$_REQUEST["ask"];
$ask||exit;
$ask=str_replace(" ", "", $ask);
$answer=@$_REQUEST["answer"];
$answer||exit;
$answer=str_replace(" ", "", $answer);

$mysql->exec("insert into account values(null, '{$user}', '{$ask}', '{$answer}', '{$time}')");
die("1");


























