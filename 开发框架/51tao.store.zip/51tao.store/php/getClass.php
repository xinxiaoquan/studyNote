<?php
require_once("tools/Mysql.class.php");
$mysql=new Mysql;

$res=$mysql->query("select id,name from `class`");
echo json_encode($res);