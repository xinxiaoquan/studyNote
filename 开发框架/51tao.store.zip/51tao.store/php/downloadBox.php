<?php
session_start();

require_once("tools/Mysql.class.php");
$mysql=new Mysql;
$userId=@$_SESSION["userId"];

$data=array();
$info="";
$info.="本资料由51TAO提供整理下载\r\n";
$info.="http://{$_SERVER['HTTP_HOST']}\r\n\r\n";

if($userId) {
	$res=$mysql->query("select shopPanLink,shopTitle from box where userId='{$userId}' order by id desc");
	if(!$res) exit;
	$data=$res;
} else if(isset($_SESSION["tmpBox"])) {
	$tmpBox=$_SESSION["tmpBox"];
	for($i=0; $i<count($tmpBox); $i++) {
		$orderKey=$tmpBox[$i];
		$res=$mysql->query("select shopPanLink,shopTitle from box where orderKey='{$orderKey}'");
		for($j=0; $j<count($res); $j++) {
			$data[]=array(
				"orderKey"=>$orderKey,
				"shopTitle"=>$res[$j]["shopTitle"],	
				"shopPanLink"=>$res[$j]["shopPanLink"],	
			);
		}
	}
}

for($i=0; $i<count($data); $i++) {
	$title=$data[$i]["shopTitle"];
	$panLink=$data[$i]["shopPanLink"];
	$panLink=json_decode($panLink);
	$link=$panLink[0];
	$code=$panLink[1];
	
	$info.="{$title}\r\n";
	$info.="链接：{$link} 提取码：{$code}\r\n\r\n";
}

die($info);


















