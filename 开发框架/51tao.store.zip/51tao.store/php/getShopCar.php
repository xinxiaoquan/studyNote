<?php
session_start();

require_once("tools/Mysql.class.php");
$mysql=new Mysql;
$userId=$_SESSION["userId"];
if($userId) {
	$res=$mysql->query("select shopId,shopTitle,shopPrice from shopCar where userId='{$userId}' order by id desc");
	if(!$res) die("{}");
	$arr=array();
	for($i=0; $i<count($res); $i++)
		$arr[$res[$i]["shopId"]]=array(
			"title"=>$res[$i]["shopTitle"],
			"price"=>$res[$i]["shopPrice"]
		);
	die(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
if(!isset($_SESSION["tmpShopCar"]))
	die("{}");
die(json_encode($_SESSION["tmpShopCar"]));


























