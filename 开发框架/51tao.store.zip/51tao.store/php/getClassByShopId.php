<?php
require_once("base.php");
require_once("tools/Mysql.class.php");
$mysql=new Mysql;

$id=@$_GET["id"];
$id||exit;

$res=$mysql->query("select classId from shop where id='{$id}' ");
if(!$res) exit;
$classId=$res[0]["classId"];

$res=$mysql->query("select name from `class` where id='{$classId}'");
if(!$res) die("[]");
echo $res[0]["name"];