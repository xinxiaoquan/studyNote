<?php
class Page {
	public function __construct($pageNo=1, $pageNum=30, $dataCount=30) {
		$this->pageNo=$pageNo;
		$this->pageNum=$pageNum;
		$this->pageCount=ceil($dataCount/$pageNum);
	}
	//获取分页条
	public function getBar() {
		$pageNo=$this->pageNo;
		$front=array();
		for($i=1; $i<=5; $i++) {
			$no=$pageNo-$i;
			if($no>=1) $front[]=$no;
		}
		$front=array_reverse($front);
		$end=array();
		for($i=1; $i<=5; $i++) {
			$no=$pageNo+$i;
			if($no<=$this->pageCount)
				$end[]=$no;
		}
		return array(
			"front"=>$front,
			"active"=>$pageNo,
			"end"=>$end,
			"pageCount"=>$this->pageCount
		);
	}
}



































