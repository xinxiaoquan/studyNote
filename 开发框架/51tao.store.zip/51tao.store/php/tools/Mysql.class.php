<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/sqlConfig.php");

class Mysql {
	private $pdo=null;
	public function __construct() {
		if($this->pdo) return;
		$mConfig=$GLOBALS["mConfig"];
		$this->pdo=new PDO("mysql:host={$mConfig['host']};dbname={$mConfig['dbname']};port={$mConfig['port']};charset={$mConfig['charset']}", $mConfig['username'], $mConfig['pwd']);
		$this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
	}
	public function query($str) {
		$obj=$this->pdo->query($str);
		if($obj)
			return $obj->fetchAll();
		return $obj;
	}
	public function exec($str) {
		return $this->pdo->exec($str);
	}
	public function getPDO() {
		return $this->pdo;
	}
}






















