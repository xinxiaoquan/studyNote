<?php
require_once("base.php");

$shopId=@$_REQUEST["shopId"];
$shopId||exit;

require_once("tools/Mysql.class.php");
$mysql=new Mysql;

$res=$mysql->query("select title from shop where id='{$shopId}'");
if($res)
echo $res[0]["title"];




























