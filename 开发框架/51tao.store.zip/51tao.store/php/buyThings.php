<?php
require_once("base.php");
session_start();

$shopIds=@$_GET["sid"];
$shopIds||exit;
$time=@$_GET["time"];
$time||exit;
$userId=@$_SESSION["userId"];

$orderKey=mt_rand(999,99999).md5(date("YmdHis"));

for($i=0; $i<count($shopIds); $i++)
	doIt($shopIds[$i],$time,$userId,$orderKey);

function doIt($shopId,$time,$userId,$orderKey) {
	require_once("tools/Mysql.class.php");
	$mysql=new Mysql;
	
	$res=$mysql->query("select price from shop where id='{$shopId}'");
	$shopPrice=$res[0]["price"];
	
	if($userId) {
		$res=$mysql->query("select count(*) as c from box where shopId='{$shopId}' and userId='{$userId}'");
		if($res[0]["c"]>0) die("-1");
		$mysql->query("insert into `order` values(null, '{$orderKey}', '{$userId}', '{$shopId}', '{$shopPrice}', 0, '{$time}')");
		return;
	}
	
	if(!isset($_SESSION["tmpBox"]))
		$_SESSION["tmpBox"]=array();
	$mysql->query("insert into `order` values(null, '{$orderKey}', '-1', '{$shopId}', '{$shopPrice}', 0, '{$time}')");
}
if(isset($_SESSION["tmpBox"]))
	array_unshift($_SESSION["tmpBox"], $orderKey);
die($orderKey);




















