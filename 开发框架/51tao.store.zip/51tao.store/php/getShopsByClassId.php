<?php
require_once("base.php");
//获取所有的商品
require_once("tools/Mysql.class.php");
$mysql=new Mysql;

$classId=@$_GET["classId"];
if(!$classId) exit;
$pageNo=@$_GET["pageNo"];
if(!$pageNo) $pageNo=1;
$pageNum=@$_GET["pageNum"];
if(!$pageNum) $pageNum=20;


$start=($pageNo-1)*$pageNum;

$res=$mysql->query("select id,title,price,size,type from shop where classId='{$classId}' limit {$start},{$pageNum}");
echo json_encode($res);





















