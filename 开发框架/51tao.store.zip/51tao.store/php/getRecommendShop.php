<?php
require_once("base.php");

$id=@$_REQUEST["id"];
$id||exit;

require_once("tools/Mysql.class.php");
$mysql=new Mysql;

$sql="select classId from shop where id='{$id}'";

$res=$mysql->query($sql);
if(!$res) exit;
$classId=$res[0]["classId"];

$sql="select id,title,price from shop where classId='{$classId}' order by click desc limit 0,10";
$res=$mysql->query($sql);
echo json_encode($res);








































