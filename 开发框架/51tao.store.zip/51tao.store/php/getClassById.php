<?php
require_once("base.php");
require_once("tools/Mysql.class.php");
$mysql=new Mysql;

$id=@$_GET["id"];
$id||exit;

$res=$mysql->query("select name from `class` where id='{$id}'");
if(!$res) die("[]");
echo json_encode($res[0]);