<?php
require_once("base.php");

$id=@$_REQUEST["id"];
$id||exit;

require_once("tools/Mysql.class.php");
$mysql=new Mysql;

$res=$mysql->query("select title,tags,click,price,type,size,tryLink,time from shop where isShow=1 and id='{$id}'");
if(count($res)==0) exit;
echo json_encode($res[0]);

























