<?php
require_once("base.php");

$shopId=@$_GET["id"];
$shopId||exit;

require_once("tools/Mysql.class.php");
$mysql=new Mysql;

$res=$mysql->query("select panLink from shop where id='{$shopId}'");
if(!$res) die("-1");
$panLink=$res[0]["panLink"];
$panLink=json_decode($panLink)[0];
$res=@file_get_contents($panLink);
if(strpos($res, "share_nofound_des")
	===false) die("1");

$mysql->query("update shop set isShow=0 where id='{$shopId}'");





















