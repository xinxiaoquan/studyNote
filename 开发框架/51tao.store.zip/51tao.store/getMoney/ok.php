<?php
//支付成功回调页面
$data=@$_POST;
if(count($data)==0 || !$data["trade_order_id"]) {
	header('HTTP/1.1 404 Not Found');
	header("status: 404 Not Found");
	http_response_code(404);
	exit;
}

$orderKey=$data["trade_order_id"];

require_once("Mysql.class.php");
$mysql=new Mysql;

$mysql->query("update `order` set isOk=1 where orderKey='{$orderKey}'");

$res=$mysql->query("select userId,shopId,shopPrice,time from `order` where orderKey='{$orderKey}'");
if(!$res) exit;
for($i=0; $i<count($res); $i++) {
	$userId=$res[$i]["userId"];
	if($userId=="-1") continue;
	$shopId=$res[$i]["shopId"];
	$shopPrice=$res[$i]["shopPrice"];
	$time=$res[$i]["time"];
	$data=$mysql->query("select title,panLink from shop where id='{$shopId}'");
	$shopTitle=$data[0]["title"];
	$shopPanLink=$data[0]["panLink"];
	
	$mysql->query("insert into box values(null, '{$orderKey}', '{$userId}', '{$shopId}', '{$shopTitle}', '{$shopPanLink}', '{$shopPrice}', '{$time}')");
}
die("success");




















