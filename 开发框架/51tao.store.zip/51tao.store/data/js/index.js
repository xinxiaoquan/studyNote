//后台路径
window.ADMINPATH="/15964158721";

//封装异步请求
function ajax(url, fun, isAsync=true) {
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if (fun) fun(this.responseText);
		}
	}
	xhr.open("get", url, isAsync);
	xhr.send(null);
}

__showData();
setInterval(()=>{
	__showData();
}, 60000);

//显示所有数据函数
function __showData() {
	
	//全部会员数
	(function() {
		let dom=document.querySelector(".main .userNum span");
		ajax(`${ADMINPATH}/php/userNum.php`,(num)=>{
			dom.innerText=formatNum(num);
		});
	})();
	
	//今日注册会员数
	(function() {
		let dom=document.querySelector(".main .todayUserNum span");
		ajax(`${ADMINPATH}/php/todayUserNum.php`,(num)=>{
			dom.innerText=formatNum(num);
		});
	})();
	
	//订单总数
	(function() {
		let dom=document.querySelector(".main .orderNum span");
		ajax(`${ADMINPATH}/php/orderNum.php`,(num)=>{
			dom.innerText=formatNum(num);
		});
	})();
	
	//今日订单数
	(function() {
		let dom=document.querySelector(".main .todayOrderNum span");
		ajax(`${ADMINPATH}/php/todayOrderNum.php`,(num)=>{
			dom.innerText=formatNum(num);
		});
	})();
	
	//总盈利
	(function() {
		let dom=document.querySelector(".main .moneyNum span");
		ajax(`${ADMINPATH}/php/moneyNum.php`,(num)=>{
			if(!num) num=0;
			num=Number(num).toFixed(2);
			dom.innerText=formatNum(num);
		});
	})();
	
	//今日盈利
	(function() {
		let dom=document.querySelector(".main .todayMoneyNum span");
		ajax(`${ADMINPATH}/php/todayMoneyNum.php`,(num)=>{
			if(!num) num=0;
			num=Number(num).toFixed(2);
			dom.innerText=formatNum(num);
		});
	})();

}

//处理显示数据
function formatNum(num) {
	if(num>=10000)
		return (num/10000).toFixed(2)+"W";
	if(num>=1000)
		return (num/1000).toFixed(2)+"K";
	return num;
}