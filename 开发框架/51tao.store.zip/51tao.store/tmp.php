<?php
require_once("php/tools/Page.class.php");
$p=new Page("shop", "*", "classId=3", "click desc", 1);

echo $p->getData(3);
echo $p->getBar(5);
































