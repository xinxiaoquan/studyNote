window.IMGPATH="http://v019.b.viptoyou.cn/img/51tao";
window.GOODSIMGPATH=IMGPATH+"/goods";
















