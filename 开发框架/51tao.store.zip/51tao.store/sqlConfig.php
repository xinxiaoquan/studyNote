<?php
global $mConfig;

$mConfig=array(
	"host"=>"127.0.0.1",
	"dbname"=>"sql_51tao_store",
	"username"=>"sql_51tao_store",
	"pwd"=>"yddpP6RcYjm3hxMs",
	"charset"=>"utf8",
	"port"=>3306
);





















