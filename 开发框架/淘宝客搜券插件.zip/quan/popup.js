(function() {

	button.onclick = goShowPage;
	search.onkeydown = function(e) {
		if (e.keyCode == 13)
			goShowPage();
	}
	tb.onclick = function() {
		window.open("https://www.taobao.com", "_blank");
	}
	tm.onclick = function() {
		window.open("https://www.tmall.com", "_blank");
	}
	setE(button);
	setE(tb);
	setE(tm);

	function setE(elem) {
		elem.onmousedown = function() {
		this.style.backgroundColor = "#ff0036";
		}
		elem.onmouseup = function() {
			this.style.backgroundColor = "";
		}
		elem.onmouseout = function() {
			this.style.backgroundColor = "";
		}
	}
	function goShowPage() {
		var data = search.value;
		if (data) {
			chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
				if (tabs[0].id) {
					chrome.tabs.sendMessage(tabs[0].id, data);
				}
			});
		}
		var text = search.parentElement.previousElementSibling;
		if (text.hasAttribute("waring")) return;
		text.setAttribute("waring", 1);
		var num = 0;
		var timer = setInterval(function() {
			console.log(text.className);
			console.log(num);
			if (text.className == "red")
				text.setAttribute("class", "black");
			else if (text.className == "black")
				text.setAttribute("class", "red");
			if (++num == 30) {
				clearInterval(timer);
				text.removeAttribute("waring");
			}
		}, 100);
	}
})();





















