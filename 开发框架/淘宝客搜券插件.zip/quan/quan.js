(function() {
	
	window.onload = function() {
		console.log("quan is starting");
		var target = null;
		var windowMark = "";
		var titleMark = "";
		var tb = document.querySelector("#mainsrp-itemlist");
		var tm = document.querySelector("#J_ItemList");
		if (!tb && !tm) {
			quanMain(false, null, function() {
				var id = location.href.match(/[&\?]id=\d+/);
				if (!id) return null;
				id = id[0].replace(/[&\?]id=/, "");
				return id;
			});
			return;
		}
		
		if (tb) {
			target = tb;
			windowMark = "div.item";
			titleMark = "div.title a";
		}
		
		if (tm) {
			target = tm;
			windowMark = "div.product";
		}
		
		new MutationObserver(function() {
			doIt(windowMark, titleMark);
		}).observe(target, {childList:true});
		doIt(windowMark, titleMark);
		function doIt(windowMark, titleMark) {
			if (windowMark == "") return;
			var elems = document.querySelectorAll(windowMark);
			var windows = [];
			for (var i = 0; i < elems.length; i++) {
				var elem = elems[i];
				var id = 0;
				if (titleMark !== "") {
					id = elems[i].querySelector(titleMark);
					id = id.getAttribute("data-nid");
				} else id = elems[i].getAttribute("data-id");
				windows[i] = [id, elem];
			}
			quanMain(true, windows, null);
		}

	};
	
	function quanMain(isSearchPage, windows, getId) {
		quanData();
		if (!isSearchPage) {
			console.log("这是产品页面");
			id = getId();
			if (id === null) return;
			var res = localStorage.getItem(`quan_${id}`);
			if (res) {
				res = JSON.parse(res);
				if (!res || res.code != 200 || res.data.coupon == 0) {
					let title = document.title;
					title = title.replace(/-.*$/, "");
					setQuan(title);
					return;
				}
				setQuan(res);
			} else getTBKJson(id, null, setQuan);
		}	else {
			console.log("这是搜索页面");
			for (var i = 0; i < windows.length; i++) {
				var id = windows[i][0];
				var res = localStorage.getItem(`quan_${id}`);
				if (res) {
					res = JSON.parse(res);
					if (!res || res.code != 200 || res.data.coupon == 0)
						continue;
					setCouponInfo(res, windows[i][1]);
				} else {
					getTBKJson(id, windows[i][1], function(res, elem) {
						setCouponInfo(res, elem);
					});
				}
			}
		}
	}

	function getTBKJson(id, elem, fn) {
		var xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function() {
			if (this.readyState == 4 &&
					this.status == 200) {
				localStorage.setItem(`quan_${id}`, this.responseText);
				var res = JSON.parse(this.responseText);
				console.log(`请求成功, id = ${id}, status = ${res.code}`);
				if (!res || res.code != 200 || res.data.coupon == 0) {
					if (!elem) {
						let title = document.title;
						title = title.replace(/-.*$/, "");
						setQuan(title);
					}
					return;
				}
				if (elem)	fn(res, elem);
				else fn(res);
			}
		}
		xhr.open("post", "https://api.tbk.dingdanxia.com/tbk/id_privilege");
		xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded;charset=UTF-8");
		if (elem) xhr.send(`id=${id}&apikey=SKOnU1Qy9tgZvfSGLqANkibJ21tvJFjr&shorturl=true`);
		else xhr.send(`id=${id}&apikey=SKOnU1Qy9tgZvfSGLqANkibJ21tvJFjr&itemInfo=true`);
	}

	function quanData() {
		if (!localStorage.getItem("quan_date"))
			localStorage.setItem("quan_date", new Date());
		else {
			let now = new Date();
			let that = new Date(localStorage.getItem("quan_date"));
			if (now - that >= 86400000) {
				let quanTips = localStorage.getItem("quan_tips");
				localStorage.clear();
				localStorage.setItem("quan_date", new Date());
				if (quanTips && quanTips == "true")
					localStorage.setItem("quan_tips", quanTips);
			}
		}
	}

	function setCouponInfo(res, elem) {
		console.log("设置搜索页的window");
		elem.style.position = "relative";
		var info = document.createElement("div");
		info.setAttribute("class", "hasQuan");
		info.appendChild(document.createTextNode("优惠券：￥" + res.data.coupon));
		elem.appendChild(info);
	}

	function setQuan(res) {
		console.log("设置产品页提示信息");
		var quan = document.createElement("div");
		quan.setAttribute("id", "quan");
		setTimeout(function() {
			quan.style.opacity = 1;
		},200);
		
		var qTitle = document.createElement("div");
		qTitle.setAttribute("class", "qTitle");
		qTitle.setAttribute("title", "点击拖动");
		qTitle.innerHTML += "<span>优惠券QUAN</span>";
		qTitle.onmousedown = function(e) {
			this.setAttribute("clicked",
				`[${e.offsetX}, ${e.offsetY}]`);
		}
		qTitle.onmouseup = function() {
			this.removeAttribute("clicked");
		}
		qTitle.onmousemove = function(e) {
			if (this.hasAttribute("clicked")) {
				var XY = this.getAttribute("clicked");
				XY = JSON.parse(XY);
				var x = XY[0];
				var y = XY[1];
				var left = parseInt(getComputedStyle(quan).left);
				var top = parseInt(getComputedStyle(quan).top);
				quan.style.left = e.offsetX - x + left + "px";
				quan.style.top = e.offsetY - y + top + "px";
			}
		}
		
		var qClose = document.createElement("div");
		qClose.setAttribute("class", "qClose");
		qClose.setAttribute("title", "点击关闭");
		qClose.onclick = function() {
			quan.style.opacity = 0;
			setTimeout(function() {
				document.body.removeChild(quan);
			}, 1000);
		}
			
		var qBody = document.createElement("div");
		qBody.setAttribute("class", "qBody");
		qBody.setAttribute("title", "点击进入优惠页面");
		if (typeof(res) != "string")
			qBody.onclick = function(e) {
				quanTips.setAttribute("json", JSON.stringify(res));
				if (localStorage.getItem("quan_tips") == "true")
					quanTipsYes.click();
				else quanTips.style.display = "block";
			}
		
		if (typeof(res) != "string") {
			var qCoupon = document.createElement("div");
			qCoupon.setAttribute("class", "qCoupon");
			qCoupon.innerHTML += `<span>￥</span>${res.data.coupon}`;

			var qCouponFinal = document.createElement("p");
			qCouponFinal.setAttribute("class", "qCouponFinal");
			qCouponFinal.innerHTML += `券后价：￥${res.data.itemInfo.qh_final_price}`;
			
			var qCouponInfo = document.createElement("div");
			qCouponInfo.setAttribute("class", "qCouponInfo");
			qCouponInfo.appendChild(document.createTextNode(`说明：${res.data.coupon_info}`));
			
			var qCouponTotal = document.createElement("div");
			qCouponTotal.setAttribute("class", "qCouponTotal");
			qCouponTotal.appendChild(document.createTextNode(`优惠券总量：${res.data.coupon_total_count}`));
			
			var qCouponRemain = document.createElement("div");
			qCouponRemain.setAttribute("class", "qCouponRemain");
			qCouponRemain.appendChild(document.createTextNode(`优惠券剩余：${res.data.coupon_remain_count}`));

		}
				
		quan.appendChild(qTitle);
		quan.appendChild(qClose);
		quan.appendChild(qBody);
		if (typeof(res) == "string")
			qBody.innerHTML = `<span class="qCouponNone">无优惠券</span>`;
		if (typeof(res) != "string") {
			qBody.appendChild(qCoupon);
			qBody.appendChild(qCouponFinal);
			qBody.appendChild(qCouponInfo);
			qBody.appendChild(qCouponTotal);
			qBody.appendChild(qCouponRemain);
		}
		document.body.appendChild(quan);
	}

	var quanTips = document.createElement("div");
	quanTips.setAttribute("id", "quanTips");
	quanTips.innerHTML = 
		"将要跳转到淘客链接，是否继续？";
	var quanTipsDisplay = document.createElement("label");
	quanTipsDisplay.innerHTML = "<input type=checkbox /> 不再显示";
	quanTipsDisplay.onclick = function() {
		let checkbox = this.querySelector("input[type=checkbox]");
		if (checkbox.checked)
			localStorage.setItem("quan_tips", "true");
	}
	var quanTipsYes = document.createElement("input");
	quanTipsYes.setAttribute("type", "button");
	quanTipsYes.setAttribute("class", "quanTipsYes");
	quanTipsYes.setAttribute("value", "确定");
	quanTipsYes.onclick = function() {
		let data = this.parentElement.getAttribute("json");
		if (data) data = JSON.parse(data);
		if (data.code != 200) return;
		else data = data.data;
		if (data) {
			let price = "";
			if (data.itemInfo.qh_final_price)
				price = data.itemInfo.qh_final_price;
			else return;
			
			let pic = "";
			if (data.itemInfo.pict_url)
				pic = data.itemInfo.pict_url;
			else return;
			
			let text = "";
			if (data.itemInfo.title)
				text = data.itemInfo.title;
			else return;
			
			let url = "";
			if (data.coupon_click_url)
				url = data.coupon_click_url;
			else if (data.item_url)
				url = data.item_url;
			else return;
			
			pic = encodeURIComponent(pic);
			text = encodeURIComponent(text);
			url = encodeURIComponent(url);
			
			window.open(`http://tb-yhq.vip/getTkl.html?&price=${price}&pic=${pic}&text=${text}&url=${url}`);
		}
		this.nextElementSibling.click();
	}
	quanTipsYes.onmousedown = function() {
		this.style.backgroundColor = "#ff0036";
	}
	quanTipsYes.onmouseup = function() {
		this.style.backgroundColor = "";
	}
	quanTipsYes.onmouseout = function() {
		this.style.backgroundColor = "";
	}
	var quanTipsNo = document.createElement("input");
	quanTipsNo.setAttribute("type", "button");
	quanTipsNo.setAttribute("class", "quanTipsNo");
	quanTipsNo.setAttribute("value", "取消");
	quanTipsNo.onclick = function() {
		this.parentElement.style.display = "none";
	}
	quanTipsNo.onmousedown = function() {
		this.style.backgroundColor = "#ff0036";
	}
	quanTipsNo.onmouseup = function() {
		this.style.backgroundColor = "";
	}
	quanTipsNo.onmouseout = function() {
		this.style.backgroundColor = "";
	}
	
	quanTips.appendChild(quanTipsDisplay);
	quanTips.appendChild(quanTipsYes);
	quanTips.appendChild(quanTipsNo);
	document.body.appendChild(quanTips);

})();

