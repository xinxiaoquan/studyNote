
var url = "http://127.0.0.1/挖掘老域名/urls.txt";
ajax(url+"?"+Math.random(), setDataToBoard);
setInterval(function() {
	ajax(url+"?"+Math.random(), setDataToBoard);
}, 10000);

function setDataToBoard(data) {
	if (!data) return;
	data = data.replace(/\r\n/g, "</li><li>");
	data = "<li>"+data+"</li>";
	board.innerHTML = data;
	board.removeChild(board.lastElementChild);
	if (board.lastElementChild)
	board.lastElementChild.scrollIntoView();
}

function ajax(url, fn) {
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if (fn) fn(this.responseText);
		}
	}
	xhr.open("get", url);
	xhr.send(null);
}