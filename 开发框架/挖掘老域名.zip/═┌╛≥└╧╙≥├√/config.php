<?php
header("Access-Control-Allow-Origin:*");
if (!isset($_GET["host"])) exit;
$host = $_GET["host"];
$data = file_get_contents("config.kang");
$data = preg_replace('/\/\*[\s\S]*?\*\/|\/\/.*/', "", $data);
$data = explode("\r\n", $data);
$length = count($data);
for ($i = 0; $i < $length; $i++) {
	$one = $data[$i];
	$one = preg_replace('/\r|\n/', "", $one);
	if (!$one) continue;
	$tmp = explode("|", $one);
	if (!isset($tmp[0]) || !isset($tmp[1])) continue;
	if ($tmp[0] == $host) {
		$time = @$tmp[2]?$tmp[2]:30;
		$isRefresh = @$tmp[3]?$tmp[3]:false;
		die(json_encode([$tmp[1], $time, $isRefresh]));
	}
}