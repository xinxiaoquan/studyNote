<?php

$api = 
'http://api.k780.com/?app=domain.whois&domain={$url}&appkey=45722&sign=a6324a6ffa7475e5b72ae40a2e2264ff&format=json';

ini_set("error_reporting", E_ALL);
if (!isset($_GET["url"])) exit;
$url = $_GET["url"];
date_default_timezone_set("prc");
$date = date("Y/m/d h:i:s");
$json = file_get_contents(str_replace('{$url}', $url, $api));
$obj = json_decode($json);
if (isset($obj->result) && is_object($obj->result))
	$status = @$obj->result->status;
else $status = null;
$msg = @$obj->msg;
$msg = $msg?$msg:"无错误";
file_put_contents("log.txt", "{$url} -- {$msg} -- {$date}\r\n", FILE_APPEND);
if ($status == "NOT_REGISTER") {
 if (file_exists("urls.txt")) {
	 $urls = file_get_contents("urls.txt");
	 if (strpos($urls, $url) !== false) exit;
 }
 file_put_contents("urls.txt", "{$url}\r\n", FILE_APPEND);
}





