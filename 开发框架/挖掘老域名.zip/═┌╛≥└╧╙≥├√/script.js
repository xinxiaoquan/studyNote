var host = location.host;
ajax("http://127.0.0.1/挖掘老域名/config.php?host="+host, function(config) {
	analysis(config);
});

function analysis(config) {
	if (config) {
		config = JSON.parse(config);
		console.log("config.kang指令接受成功！正在挖掘此网站~~~ 延时"+config[1]+"秒进行下一页挖掘");
		sendData();
		setTimeout(function() {
			clickNextPage(config[0], config[2]);
		}, config[1]*1000);
	} else console.log("config.kang指令接受成功！没有此域名网址规则，请在config.kang中添加");
}

function sendData() {
	var inner = document.body.innerText;
	innner = inner.replace(/[\u4E00-\u9FFF]/g, "");
	var arr = innner.match(/([\w\-_]+(\.[\w\-_]+)+)/g);
	if (arr) {
		var newArr = [];
		for (var i = 0; i < arr.length; i++) {
			if (arr[i].indexOf(".gov") != -1 ||
					arr[i].indexOf("gov.") != -1 ||
					arr[i].indexOf(".edu") != -1 ||
					arr[i].indexOf("edu.") != -1 ||
					arr[i].length >= 20 ||
					arr[i].length <= 5) continue;
			for (var j = 0; j < newArr.length; j++)
				if (newArr[j] == arr[i]) break;
			if (j < newArr.length) continue;
			newArr.push(arr[i]);
			ajax("http://127.0.0.1/挖掘老域名/?url="+newArr[newArr.length-1]);
		}
		console.log(newArr);
	}
}

function clickNextPage(selector, isRefresh) {
	var elem = document.querySelector(selector);
	if (elem) {
		elem.click();
		if (isRefresh)
			setTimeout(function() {
				location.href = location.href;
			}, 2000);
	} else alert("挖掘完成！去urls.txt中查看数据！");
}

function ajax(url, fn) {
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if (fn) fn(this.responseText);
		}
	}
	xhr.open("get", url);
	xhr.send(null);
}



	
