<?php
if (!isset($mysql))
	die("数据库未连接！");

//提取库中的表
$allTables = [];
$sql = "show tables";
$res = $mysql->query($sql);
while ($row = $res->fetch_row()) {
	$allTables[$row[0]] = true;
}

//广告联盟表
if (!@$allTables["ad"]) {
	//name 联盟名称
	//url 联盟网址
	//recommend 联盟介绍
	//pay_cycle 支付周期 1日付 2周付 3月付 4季付
	//start_pay 起付金额
	//type 广告类型 字符串型，值是cpc cpa cps等
	//display 平台展示 1电脑 2苹果 3安卓
	//time 添加时间
	/*下列所有的值都是四舍五入的
	具体数据在json/contentScore/ad/X.josn中
		timely 结算及时性 1-5分
		credit 服务商信用 1-5分
		service 客户服务质量 1-5分
		code_rich 代码丰富度 1-5分
	*/
	//views 访问次数
	//coms 点评数量
	//user 提交的用户
	$sql = "CREATE TABLE ad(
			id int unsigned primary key auto_increment,
			name text,
			url text,
			recommend text,
			pay_cycle text,
			start_pay text,
			type text,
			display varchar(1),
			time text,
			timely text,
			credit text,
			service text,
			code_rich text,
			views int unsigned,
			coms int unsigned,
			is_pass varchar(1),
			user text
		)";
	$mysql->query($sql);
}
//广告联盟点评表
if (!@$allTables["ad_com"]) {
	//title 标题
	//nickname 昵称 
	//content 内容
	//time 时间
	//ip 评论者ip地址
	//area 评论者地区
	//is_pass 是否通过，0未通过，1通过
	$sql = "CREATE TABLE ad_com(
		id int unsigned primary key auto_increment,
		pId int unsigned,
		title text,
		timely varchar(1),
		credit varchar(1),
		service varchar(1),
		code_rich varchar(1),
		nickname text,
		content text,
		time text,
		ip text,
		area text,
		is_pass varchar(1)
	)";
	$mysql->query($sql);
}
//广告联盟资讯表
if (!@$allTables["ad_info"]) {
	$sql = "CREATE TABLE ad_info(
		id int unsigned primary key auto_increment,
		title text,
		time text,
		content text
	)";
	$mysql->query($sql);
}

//seo表
if (!@$allTables["seo"]) {
	//name 公司/团队名
	//url 网址
	//adress详细地址
	//mobile 手机
	//qq QQ号
	//wx 微信号
	//recommend 公司/个人介绍
	//type 平台类型 1:PC	2移动
	//class 平台分类 1百度 2:360 3搜狗
	//area 所属地区
	//quality 资质 1个人 2团队 3公司
	//time 添加时间
	/*下列所有的值都是四舍五入的
	具体数据在json/contentScore/ad/X.josn中
		speed	完成速度 1-5分
		stable 排名稳定 1-5分
		service 服务质量 1-5分
		price_ratio 性价比 1-5分
	*/
	//views 访问次数
	//coms 点评数量
	//user 提交的用户
	$sql = "CREATE TABLE seo(
		id int unsigned primary key auto_increment,
		name text,
		url text,
		adress text,
		mobile text,
		qq text,
		wx text,
		recommend text,
		type varchar(1),
		class varchar(1),
		area varchar(2),
		quality varchar(1),
		time text,
		speed text,
		stable text,
		service text,
		price_ratio text,
		views int unsigned,
		coms int unsigned,
		is_pass varchar(1),
		user text
	)";
	$mysql->query($sql);
}
//seo表评价
if (!@$allTables["seo_com"]) {
	//title 标题
	//nickname 昵称 
	//content 内容
	//time 时间
	//ip 评论者ip地址
	//area 评论者地区
	//is_pass 是否通过，0未通过，1通过
	$sql = "CREATE TABLE seo_com(
		id int unsigned primary key auto_increment,
		pId int unsigned,
		title text,
		speed varchar(1),
		stable varchar(1),
		service varchar(1),
		price_ratio varchar(1),
		nickname text,
		content text,
		time text,
		ip text,
		area text,
		is_pass varchar(1)
	)";
	$mysql->query($sql);
}
//SEO资讯表
if (!@$allTables["seo_info"]) {
	$sql = "CREATE TABLE seo_info(
		id int unsigned primary key auto_increment,
		title text,
		time text,
		content text
	)";
	$mysql->query($sql);
}

//app推广表
if (!@$allTables["app"]) {
	//name 名称
	//class 平台类型 1不限 2安卓 3苹果 4PC
	//ad_type 广告类型 1不限 2cpa 3cps 4cpm 5换量 6分销/代理
	//settle 结算方式 1不限 2日结 3月结 4季度结 5预付
	//query 收入查询 1不限 2后台 3截图
	//pro_type 产品类型 1不限 2IT/互联网 3游戏 4金融服务 5视频/直播 6棋牌 7影视/动漫 8亲子/母婴 9教育/培训 10汽车 11化妆品/美容美体 12旅游 13婚庆 14房产 15餐饮 16快消/食品饮料 17办公用品/生活用品 18家居建材 19家政服务 20娱乐/休闲 21媒体 22广告/公关/展览 23医药/医疗/健康/保健 24投融资 25智能产业 26服装/服饰 27家电/数码/手机 28企业服务 29通讯 30能源/制造 31其他
	//price 单价
	//content 内容
	//contact 联系方式 1QQ 2微信 3手机
	$sql = "CREATE TABLE app(
		id int unsigned primary key auto_increment,
		name text,
		class varchar(1),
		ad_type varchar(1),
		settle varchar(1),
		query varchar(1),
		pro_type varchar(2),
		price text,
		content text,
		contact varchar(1),
		time text,
		timely text,
		credit text,
		service text,
		code_rich text,
		views int unsigned,
		coms int unsigned,
		is_pass varchar(1),
		user text
	)";
	$mysql->query($sql);
}
//app推广点评
if (!@$allTables["app_com"]) {
	//title 标题
	//timely 结算及时性 1-5分
	//credit 服务商信用 1-5分
	//service 客户服务质量 1-5分
	//code_rich 代码丰富度 1-5分
	//nickname 昵称 
	//content 内容
	//time 时间
	//ip 评论者ip地址
	//area 评论者地区
	//is_pass 是否通过，0未通过，1通过
	$sql = "CREATE TABLE app_com(
		id int unsigned primary key auto_increment,
		pId int unsigned,
		title text,
		timely varchar(1),
		credit varchar(1),
		service varchar(1),
		code_rich varchar(1),
		nickname text,
		content text,
		time text,
		ip text,
		area text,
		is_pass varchar(1)
	)";
	$mysql->query($sql);
}
//APP资讯表
if (!@$allTables["app_info"]) {
	$sql = "CREATE TABLE app_info(
		id int unsigned primary key auto_increment,
		title text,
		time text,
		content text
	)";
	$mysql->query($sql);
}

//vps云主机表
if (!@$allTables["vps"]) {
	//name 主机名称
	//adress 公司所在地
	/*
		1	北京
		2	上海
		3	广东
		4	福建
		5	浙江
		6	山东
		7	山西
		8	辽宁
		9	湖北
		10 河北
		11 重庆
		12 陕西
		13 河南
		14 四川
		15 湖南
		16 江西
		17 天津
		18 江苏
		19 广西
		20 安徽
		21 吉林
		22 黑龙江
		23 海南
		24 贵州
		25 云南
		26 甘肃
		27 青海
		28 内蒙古
		29 西藏
		30 宁夏
		31 新疆
		32 香港
		33 澳门
		34 台湾
		35 日本
		36 美国
		37 韩国
		38 欧洲
		39 印度
		40 泰国
		41 缅甸
		42 老挝
		43 越南
		44 新加坡
		45 柬埔寨
		46 俄罗斯
		47 其他国家
	*/
	//room 机房所在地
	/* 
		同公司所在地 
	*/
	//line 服务器线路
	/*
		1 中国联通
		2 中国电信
		3 中国移动
		4 港台线路
		5 双线主机
		6 海外主机
		7 其他线路
	*/
	//class 服务器类别
	/*
		1 国外服务器
		2 国内服务器
		3 国内VPS
		4 国外VPS
		5 国外虚拟主机
		6 国内虚拟主机
	*/
	//type 服务器类型
	/*
		1 DDOS高防服务器
		2 抗投诉服务器
		3 站群服务器
		4 不限流量服务器
		5 不限内容服务器
	*/
	//vps_class vps类型
	/*
		1 国内VPS
		2 国外VPS
		3 DDOS高防VPS
		4 不限流量VPS
		5 windows VPS
		6 VPS云/云服务器
	*/
	//url 网址
	//recommend 介绍
	/*
		fast 主机速度
		price_ratio 性价比
		service 服务质量
		security 安全性
		high_safety 高防性
	*/
	$sql = "CREATE TABLE vps(
		id int unsigned primary key auto_increment,
		name text,
		adress varchar(2),
		room varchar(2),
		line varchar(1),
		class varchar(1),
		type varchar(1),
		vps_class varchar(1),
		url text,
		recommend text,
		time text,
		fast text,
		price_ratio text,
		service text,
		security text,
		high_safety text,
		views int unsigned,
		coms int unsigned,
		is_pass varchar(1),
		user text
	)";
	$mysql->query($sql);
}

//vps主机点评
if (!@$allTables["vps_com"]) {
	//title 标题
	//nickname 昵称 
	//content 内容
	//time 时间
	//ip 评论者ip地址
	//area 评论者地区
	//is_pass 是否通过，0未通过，1通过
	$sql = "CREATE TABLE vps_com(
		id int unsigned primary key auto_increment,
		pId int unsigned,
		title text,
		nickname text,
		content text,
		fast varchar(1),
		price_ratio varchar(1),
		service varchar(1),
		security varchar(1),
		high_safety varchar(1),
		time text,
		ip text,
		area text,
		is_pass varchar(1)
	)";
	$mysql->query($sql);
}
//VPS资讯表
if (!@$allTables["vps_info"]) {
	$sql = "CREATE TABLE vps_info(
		id int unsigned primary key auto_increment,
		title text,
		time text,
		content text
	)";
	$mysql->query($sql);
}

//用户表
if (!@$allTables["users"]) {
	//昵称 用户名 密码
	$sql = "CREATE TABLE users(
		id int unsigned primary key auto_increment,
		mobile text,
		nickname text,
		pwd text
	)";
	$mysql->query($sql);
}

//IP黑名单
if(!@$allTables["ip_blacklist"]) {
	$sql = "CREATE TABLE ip_blacklist(
		id int unsigned primary key auto_increment,
		ip text
	)";
	$mysql->query($sql);
}

























