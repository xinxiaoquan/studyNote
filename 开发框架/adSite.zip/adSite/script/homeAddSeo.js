window.AFTER = function(info) {
	alert(info);
	setCreateHtmlBubbles();
}

var seoName = document.querySelector("input[name=seoName]");
window.FORMRULE(seoName, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "公司名/团队名不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var seoUrl = document.querySelector("input[name=seoUrl]");
window.FORMRULE(seoUrl, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "网站网址不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var seoAdress = document.querySelector("input[name=seoAdress]");
window.FORMRULE(seoAdress, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "详细地址不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var seoMobile = document.querySelector("input[name=seoMobile]");
window.FORMRULE(seoMobile, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "手机号不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	if (isNaN(Number(this.value))) {
		window.FORMERR(span, "手机号必须都是数字！");
		if (!e) this.scrollIntoView();
		return;
	}
	if (this.value.length > 11) {
		window.FORMERR(span, "手机号位数不能大于11！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var seoQQ = document.querySelector("input[name=seoQQ]");
window.FORMRULE(seoQQ, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "QQ号不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	if (isNaN(Number(this.value))) {
		window.FORMERR(span, "QQ号必须都是数字！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var seoWX = document.querySelector("input[name=seoWX]");
window.FORMRULE(seoWX, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "微信号不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var seoRecommend = document.querySelector("textarea[name=seoRecommend]");
window.FORMRULE(seoRecommend, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "公司/个人介绍不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var time = document.querySelector("form [name=time]");
time.value = new Date().getTime();









