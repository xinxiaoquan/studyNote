//定义后台表单输入框规则的函数
window.FORMRULE = function(input, event, fn) {
	input.addEventListener(event, fn);
	input.myRule = fn;
}
//后台规则错误
window.FORMERR = function(span, info) {
	if (!span) return;
	if (!hasClass(span, "err"))
		addClass(span, "err");
	span.innerHTML = info;
}
//后台删除错误
window.FORMDELERR = function(span) {
	if (!span) return;
	replaceClass(span, "err", "");
	span.innerHTML = "";
}

//获取数据修改表单的方法
window.MODIFYFORM = function(data, reWriteName) {
	var elems = document.querySelectorAll("[name]");
	for (var i = 0; i < elems.length; i++) {
		var elem = elems[i];
		var name = elem.getAttribute("name");
		if (reWriteName)
			name = reWriteName(name);
		if (elem.nodeName == "INPUT" || elem.nodeName == "TEXTAREA") {
			var value = decodeURIComponent(data[name]);
			if (elem.getAttribute("type") == "checkbox") {
				value = JSON.parse(value);
				elem.checked = false;
				if (value.indexOf(elem.value) != -1 && !elem.checked)
					elem.checked = true;
				continue;
			}
			if (value) elem.value = value;
		}
		if (elem.nodeName == "SELECT")  {
			var children = elem.children;
			var value = data[name];
			value = decodeURIComponent(value);
			for (var j = 0; j < children.length; j++) {
				if (children[j].value == value) {
					children[j].setAttribute("selected", "selected");
					continue;
				}
				if (children[j].hasAttribute("selected"))
					children[j].removeAttribute("selected");
			}
		}
	}
}

//清空表单（reset）
window.FORMRESET = function() {
	var reset = document.querySelector("input[type=reset]");
	reset.click();
}

;(function() {
	
	var spans = document.querySelectorAll("form span");
	if (spans)
	for (var i = 0; i < spans.length; i++) {
		spans[i].className += " err";
	}
	var texts = document.querySelectorAll("form [type=text], form [type=password], form textarea");
	if (texts) {
		for (var i = 0; i < texts.length; i++) {
			texts[i].title = texts[i].placeholder;
			texts[i].setAttribute("autocomplete", "off");
			texts[i].addEventListener("click", function() {
				var span = document.querySelector("span."+this.name);
				span.innerHTML = "";
			});
		}
	}
	
	//验证码图片点击重新加载
	var captchaImg = document.querySelector("form img.captcha");
	if (captchaImg)
	captchaImg.onclick = function() {
		this.src = this.src;
	}
	
	var submit = document.querySelector("form input[type=submit]");
	if (submit)
	submit.onclick = function() {
		var inputs = document.querySelectorAll("input, textarea, button");
		for (var i = 0; i < inputs.length; i++) {
			if (inputs[i].myRule) {
				inputs[i].myRule();
				if (inputs[i].name) var query = `span.${inputs[i].name}`;
				else if (inputs[i].className) var query = `span.${inputs[i].className}`;
				else return false;
				var span = document.querySelector(query);
				if (span)
				if (hasClass(span, "err")) return false;
			}
		}
		
		var form = document.querySelector("form");
		if (form.getAttribute("isAjax") != "false") {
			var method = form.method;
			var url = form.action;
			var data = "";
			var checkbox = document.querySelectorAll("input[type=checkbox]");
			var checkedArr = [];
			for (var i = 0; i < checkbox.length; i++) {
				if(!checkedArr.hasOwnProperty(checkbox[i].name))
					checkedArr[checkbox[i].name] = [];
				if (checkbox[i].checked)
					checkedArr[checkbox[i].name].push(checkbox[i].value);
			}
			for (var key in checkedArr) {
				if (checkedArr[key].length == 0) {
					alert("复选框未选！");
					return false;
				}
				data += `${key}=${encodeURIComponent(JSON.stringify(checkedArr[key]))}&`;
			}
			var names = document.querySelectorAll("[name]");
			for (var i = 0; i < names.length; i++) {
				if (names[i].getAttribute("type") == "checkbox")
					continue;
				var key = names[i].name;
				var value = names[i].value;
				data += `${key}=${encodeURIComponent(value)}&`;
			}
			if (method == "get") {
				url = `${url}?${data}`;
				data = null;
			}
			ajax(method, url, data, function(data) {
				if (data == "") return;
				//页面中执行表单完成后触发的函数
				if (window.AFTER) window.AFTER(data);
			});
			return false;
		}
	}
	
})();
























