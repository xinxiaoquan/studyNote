//获取未通过APP的个数（气泡）
setReviewBubbles();

//分页条绑定事件
function pageEvent(ul) {
	var lis = ul.querySelectorAll("li");
	for (var i = 0; i < lis.length; i++) {
		if (hasClass(lis[i], "select")) {
			lis[i].onclick = function() {
				var page = prompt("输入跳转的页数");
				if (!page || page <= 0)
					page = 1;
				else {
					var lastPageNo = this.parentElement.lastChild;
					lastPageNo = lastPageNo.getAttribute("pageNo");
					lastPageNo = Number(lastPageNo);
					if (page > lastPageNo)
						page = lastPageNo;
				}
				getAppPageBar(page);
			}
			continue;
		}
		lis[i].onclick = function() {
			var page = this.getAttribute("pageNo");
			if (page)	getAppPageBar(page);
		}
	}
}

//获取APP的数据
function getAppPageBar(pageNo) {
	if (!pageNo) pageNo = 1;
	
	var all = document.querySelector("#right table td.all");
	all.onclick = function() {
		var selects = document.querySelectorAll("#right table tr td:first-child");
		for (var i = 0; i < selects.length; i++) {
			if (selects[i] == this) continue;
			selects[i].onmousedown();
			selects[i].onmouseup();
		}
	}
	ajax("get", "../opaData/getPageBar.php?query=*&noPass&table=app&pageNo="+pageNo,
		null, function(data) {
		if (data == "") return;
		data = JSON.parse(data);

		var allRows = document.querySelector("#right ul.alert li:first-child");
		var selectRows = document.querySelector("#right ul.alert li:nth-child(2)");
		
		var tbody = document.querySelector("#right table tbody");
		tbody.innerHTML = "";
		var ul = document.querySelector("#right ul");
		ul.innerHTML = data["page"];
		pageEvent(ul);
		var rows = data["rows"];
		
		allRows.innerHTML = rows.length;

		for (var i = 0; i < rows.length; i++) {
			var tr = document.createElement("tr");
			tr.innerHTML = `
				<td>${decodeURIComponent(rows[i][0])}</td>
				<td>${decodeURIComponent(rows[i][18])}</td>
				<td>${decodeURIComponent(rows[i][1])}</td>
				<td>${change("class", rows[i][2])}</td>
				<td>${change("adType", rows[i][3])}</td>
				<td>${change("settle", rows[i][4])}</td>
				<td>${change("query", rows[i][5])}</td>
				<td>${change("proType", rows[i][6])}</td>
				<td>${change("price", rows[i][7])}</td>
				<td>${decodeURIComponent(rows[i][8])}</td>
				<td>${change("contact", rows[i][9])}</td>
				<td class="pass">通过</td>
				<td class="del">删除</td>
			`;
			function change(type, data) {
				data = decodeURIComponent(data);
				if (type == "time") {
					return toShowDate(data, "y-m-d h:i:s");
				}
				if (type == "price") {
					return data+"元";
				}
				if (type == "class") {
					if (data == 1) return "不限";
					if (data == 2) return "安卓";
					if (data == 3) return "苹果";
					if (data == 4) return "PC";
				}
				if (type == "adType") {
					if (data == 1) return "不限";
					if (data == 2) return "cpa";
					if (data == 3) return "cps";
					if (data == 4) return "cpm";
					if (data == 5) return "换量";
					if (data == 6) return "分销代理";
				}
				if (type == "settle") {
					if (data == 1) return "不限";
					if (data == 2) return "日结";
					if (data == 3) return "月结";
					if (data == 4) return "季度结";
					if (data == 5) return "预付";
				}
				if (type == "query") {
					if (data == 1) return "不限";
					if (data == 2) return "后台";
					if (data == 3) return "截图";
				}
				if (type == "proType") {
					if (data==1) return "不限";
					if (data==2) return "IT/互联网";
					if (data==3) return "游戏";
					if (data==4) return "金融服务";
					if (data==5) return "视频/直播";
					if (data==6) return "棋牌";
					if (data==7) return "影视/动漫";
					if (data==8) return "亲子/母婴";
					if (data==9) return "教育/培训";
					if (data==10) return "汽车";
					if (data==11) return "化妆品/美容美体";
					if (data==12) return "旅游";
					if (data==13) return "婚庆";
					if (data==14) return "房产";
					if (data==15) return "餐饮";
					if (data==16) return "快消/食品饮料";
					if (data==17) return "办公用品/生活用品";
					if (data==18) return "家居建材";
					if (data==19) return "家政服务";
					if (data==20) return "娱乐/休闲";
					if (data==21) return "媒体";
					if (data==22) return "广告/公关/展览";
					if (data==23) return "医药/医疗/健康/保健";
					if (data==24) return "投融资";
					if (data==25) return "智能产业";
					if (data==26) return "服装/服饰";
					if (data==27) return "家电/数码/手机";
					if (data==28) return "企业服务";
					if (data==29) return "通讯";
					if (data==30) return "能源/制造";
					if (data==31) return "其他";
				}
				if (type == "contact") {
					if (data == 1) return "QQ";
					if (data == 2) return "微信";
					if (data == 3) return "手机";
				}
				return data;
			}
			
			var select = tr.querySelector("td:first-child");
			select.onmousedown = function() {
				tbody.setAttribute("click", "true");
				if (this.parentElement.className != "select") {
					this.parentElement.className = "select";
					var del = this.parentElement.querySelector(".del");
					del.innerHTML = "批量删除";
					var pass = this.parentElement.querySelector(".pass");
					pass.innerHTML = "批量通过";
				} else {
					this.parentElement.className = "";
					var del = this.parentElement.querySelector(".del");
					del.innerHTML = "删除";
					var pass = this.parentElement.querySelector(".pass");
					pass.innerHTML = "通过";
				}
			}
			select.onmouseup = function() {
				tbody.setAttribute("click", "false");
				selectRows.innerHTML = document.querySelectorAll("#right tr.select").length;
			}
			select.onmouseover = function() {
				if (tbody.getAttribute("click") == "true") {
					if (this.parentElement.className != "select") {
						this.parentElement.className = "select";
						var del = this.parentElement.querySelector(".del");
						del.innerHTML = "批量删除";
						var pass = this.parentElement.querySelector(".pass");
						pass.innerHTML = "批量通过";
					} else {
						this.parentElement.className = "";
						var del = this.parentElement.querySelector(".del");
						del.innerHTML = "删除";
						var pass = this.parentElement.querySelector(".pass");
						pass.innerHTML = "通过";
					}
				}
			}
			tbody.appendChild(tr);
			
			var del = tr.querySelector("#right .del");
			del.onclick = function() {
				var tr = this.parentElement;
				tr.className = "select";
				var ids = tr.firstElementChild.innerHTML;
				var select = document.querySelectorAll("#right tr.select td:first-child");
				var td = tr.firstElementChild;
				for (var i = 0; i < select.length; i++) {
					if (select[i] == td) continue;
					ids += ","+select[i].innerHTML
				}
				if (!confirm("是否删除？"))
					return;
				ajax("get", "../opaData/homeDelApp.php?ids="+ids,
				null, function() {
					if (!select) return;
					for (var i = 0; i < select.length; i++) {
						var tr = select[i].parentElement;
						tr.parentElement.removeChild(tr);
					}
					setReviewBubbles();
				});
			}
			
			var pass = tr.querySelector("#right .pass");
			pass.onclick = function() {
				var tr = this.parentElement;
				tr.className = "select";
				var ids = tr.firstElementChild.innerHTML;
				var select = document.querySelectorAll("#right tr.select td:first-child");
				var td = tr.firstElementChild;
				for (var i = 0; i < select.length; i++) {
					if (select[i] == td) continue;
					ids += ","+select[i].innerHTML
				}
				if (!confirm("是否通过？"))
					return;
				ajax("get", `../opaData/homePassApp.php?ids=${ids}&time=${new Date().getTime()}`,
				null, function() {
					if (!select) return;
					for (var i = 0; i < select.length; i++) {
						for (var i = 0; i < select.length; i++) {
							var elem = select[i].parentElement.querySelector(".pass");
							elem.innerHTML = "通过通过"
							elem.className = "";
							elem.onclick = null;
						}
					}
					setReviewBubbles();
					setCreateHtmlBubbles();
				});
			}
			
		}
	});
}

getAppPageBar();




























