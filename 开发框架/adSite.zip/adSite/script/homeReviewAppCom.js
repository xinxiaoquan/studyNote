//获取未审核任务的个数（气泡）
setReviewComBubbles();

//分页条绑定事件
function pageEvent(ul) {
	var lis = ul.querySelectorAll("li");
	for (var i = 0; i < lis.length; i++) {
		if (hasClass(lis[i], "select")) {
			lis[i].onclick = function() {
				var page = prompt("输入跳转的页数");
				if (!page || page <= 0)
					page = 1;
				else {
					var lastPageNo = this.parentElement.lastChild;
					lastPageNo = lastPageNo.getAttribute("pageNo");
					lastPageNo = Number(lastPageNo);
					if (page > lastPageNo)
						page = lastPageNo;
				}
				getAppPageBar(page);
			}
			continue;
		}
		lis[i].onclick = function() {
			var page = this.getAttribute("pageNo");
			if (page)	getAppPageBar(page);
		}
	}
}

//获取广告联盟中的数据
function getAppPageBar(pageNo) {
	if (!pageNo) pageNo = 1;
	
	var all = document.querySelector("#right table td.all");
	all.onclick = function() {
		var selects = document.querySelectorAll("#right table tr td:first-child");
		for (var i = 0; i < selects.length; i++) {
			if (selects[i] == this) continue;
			selects[i].onmousedown();
			selects[i].onmouseup();
		}
	}
	
	ajax("get", `../opaData/getPageBar.php?query=*&table=app_com&allData=true&pageNo=${pageNo}`,
		null, function(data) {
		if (data == "") return;
		data = JSON.parse(data);

		var allRows = document.querySelector("#right ul.alert li:first-child");
		var selectRows = document.querySelector("#right ul.alert li:nth-child(2)");
		
		var tbody = document.querySelector("#right table tbody");
		tbody.innerHTML = "";
		var ul = document.querySelector("#right ul");
		ul.innerHTML = data["page"];
		pageEvent(ul);
		var rows = data["rows"];
		
		allRows.innerHTML = rows.length;

		for (var i = 0; i < rows.length; i++) {
			var tr = document.createElement("tr");
			tr.innerHTML = `
				<td>${decodeURIComponent(rows[i][0])}</td>
				<td>${decodeURIComponent(rows[i][1])}</td>
				<td>${decodeURIComponent(rows[i][7])}</td>
				<td>${decodeURIComponent(rows[i][2])}</td>
				<td>${decodeURIComponent(rows[i][8])}</td>
				<td class="ip">${decodeURIComponent(rows[i][10])}</td>
				<td>${decodeURIComponent(rows[i][11])}</td>
				<td>${toShowDate(rows[i][9], "y-m-d h:i:s")}</td>
				<td>${decodeURIComponent(rows[i][3])}</td>
				<td>${decodeURIComponent(rows[i][4])}</td>
				<td>${decodeURIComponent(rows[i][5])}</td>
				<td>${decodeURIComponent(rows[i][6])}</td>
				<td class="del">删除</td>
				<td class="pass">通过</td>
				<td class="pullBlack">拉黑</td>
			`;
			var select = tr.querySelector("td:first-child");
			select.onmousedown = function() {
				tbody.setAttribute("click", "true");
				if (this.parentElement.className != "select") {
					this.parentElement.className = "select";
					var del = this.parentElement.querySelector(".del");
					del.innerHTML = "批量删除";
					var pass = this.parentElement.querySelector(".pass");
					if (pass)
					pass.innerHTML = "批量通过";
					var pullBlack = this.parentElement.querySelector(".pullBlack");
					pullBlack.innerHTML = "批量拉黑";
				} else {
					this.parentElement.className = "";
					var del = this.parentElement.querySelector(".del");
					del.innerHTML = "删除";
					var pass = this.parentElement.querySelector(".pass");
					if (pass)
					pass.innerHTML = "通过";
					var pullBlack = this.parentElement.querySelector(".pullBlack");
					pullBlack.innerHTML = "拉黑";
				}
			}
			select.onmouseup = function() {
				tbody.setAttribute("click", "false");
				selectRows.innerHTML = document.querySelectorAll("#right tr.select").length;
			}
			select.onmouseover = function() {
				if (tbody.getAttribute("click") == "true") {
					if (this.parentElement.className != "select") {
						this.parentElement.className = "select";
						var del = this.parentElement.querySelector(".del");
						del.innerHTML = "批量删除";
						var pass = this.parentElement.querySelector(".pass");
						if (pass)	pass.innerHTML = "批量通过";
						var pullBlack = this.parentElement.querySelector(".pullBlack");
						pullBlack.innerHTML = "批量拉黑";
					} else {
						this.parentElement.className = "";
						var del = this.parentElement.querySelector(".del");
						del.innerHTML = "删除";
						var pass = this.parentElement.querySelector(".pass");
						if (pass)
						pass.innerHTML = "通过";
						var pullBlack = this.parentElement.querySelector(".pullBlack");
						pullBlack.innerHTML = "拉黑";
					}
				}
			}
			tbody.appendChild(tr);
			
			var del = tr.querySelector("#right .del");
			del.onclick = function() {
				var tr = this.parentElement;
				tr.className = "select";
				var ids = tr.firstElementChild.innerHTML;
				var select = document.querySelectorAll("#right tr.select td:first-child");
				var td = tr.firstElementChild;
				for (var i = 0; i < select.length; i++) {
					if (select[i] == td) continue;
					ids += ","+select[i].innerHTML
				}
				if (!confirm("是否删除？"))
					return;
				ajax("get", "../opaData/homeDelAppCom.php?ids="+ids, null, function() {
					if (!select) return;
					for (var i = 0; i < select.length; i++) {
						var tr = select[i].parentElement;
						tr.parentElement.removeChild(tr);
					}
					setReviewComBubbles();
				});
			}
			
			var pass = tr.querySelector("#right .pass");
			if (pass)
			if (decodeURIComponent(rows[i][12]) == 0) {
				pass.onclick = function() {
					var that = this;
					var tr = this.parentElement;
					tr.className = "select";
					var ids = tr.firstElementChild.innerHTML;
					var td = tr.firstElementChild;
					var select = document.querySelectorAll("#right tr.select td:first-child");
					for (var i = 0; i < select.length; i++) {
						if (select[i] == td) continue;
						ids += ","+select[i].innerHTML
					}
					if (!confirm("是否通过？"))
						return;
					ajax("get", "../opaData/homePassAppCom.php?ids="+ids, null, function() {
						for (var i = 0; i < select.length; i++) {
							var pass = select[i].parentElement.querySelector(".pass");
							if (pass) {
								pass.innerHTML = "已经通过";
								pass.className = "";
								pass.onclick = null;
							}
							select[i].parentElement.className = "";
						}
						setReviewComBubbles();
					});
				}
			} else {
				pass.className = "";
				pass.innerHTML = "已经通过";
			}
			
			var pullBlack = tr.querySelector("#right .pullBlack");
			pullBlack.onclick = function() {
				var that = this;
				var td = this.parentElement.firstElementChild;
				var ip = this.parentElement.querySelector(".ip");
				td.parentElement.className = "select";
				var ids = td.innerHTML;
				var ips = ip.innerHTML;
				var select = document.querySelectorAll("#right tr.select td:first-child");
				for (var i = 0; i < select.length; i++) {
					if (select[i] == td) continue;
					ids += ","+select[i].innerHTML;
					ips += ","+select[i].parentElement.querySelector(".ip").innerHTML;
				}
				if (!confirm("是否拉黑？"))
					return;
				ajax("get", `../opaData/homePullBlackAppCom.php?ids=${ids}&ips=${ips}`, null, function() {
					for (var i = 0; i < select.length; i++) {
						for (var i = 0; i < select.length; i++) {
							var tr = select[i].parentElement;
							tr.parentElement.removeChild(tr);
						}
						setReviewComBubbles();
					}
				});
			}
			
		}
	});
}

getAppPageBar();




























