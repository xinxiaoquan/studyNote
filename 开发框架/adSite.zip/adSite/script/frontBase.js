
//获得get的query字符串
function GET() {
	if (!location.search)
		return [];
	var search = location.search;
	var arr = [];
	search = search.replace(/^\?*/, "");
	var tmp1 = search.split("&");
	for (var i = 0; i < tmp1.length; i++) {
		var tmp2 = tmp1[i].split("=");
		arr[tmp2[0]] = tmp2[1];
	}
	return arr;
}

//判断是否登录，登录可以提交联盟
(function() {
	ajax("get", cssJsPos+"users/isSign.php",
	null, function(info) {
		if (info == "") return;
		if (info != "@err@") {
			var box = document.querySelector("#nav .box");
			if (info == "admin") {
				var home = document.createElement("a");
				home.innerHTML = "管理后台";
				home.className = "option";
				home.href = `${webRoot}home/`;
				home.target = "_blank";
				box.appendChild(home);
			}
			var exit = document.createElement("a");
			exit.innerHTML = "退出";
			exit.className = "option";
			exit.href = `${webRoot}users/exit.php`;
			box.appendChild(exit);
			var sign = document.querySelector("#nav .sign");
			if (TYPE == "ad") {
				sign.innerHTML = "提交联盟";
				sign.href = `${webRoot}submit/${TYPE}.html`;
			}
			if (TYPE == "seo") {
				sign.innerHTML = "提交SEO";
				sign.href = `${webRoot}submit/${TYPE}.html`;
			}
			if (TYPE == "app") {
				sign.innerHTML = "提交APP";
				sign.href = `${webRoot}submit/${TYPE}.html`;
			}
			if (TYPE == "vps") {
				sign.innerHTML = "提交VPS";
				sign.href = `${webRoot}submit/${TYPE}.html`;
			}
		}
		navEffects();
	});
})();

//导航条的特效
function navEffects() {
	var options = document.querySelectorAll("#nav .box .option");
	for (var i = 0; i < options.length; i++) {
		options[i].onmouseover = function() {
			var active = document.querySelector("#nav .option.active");
			if (active == this) return;
			replaceClass(active, "active", "active_del");
			if (!hasClass(this, "active"))
				addClass(this, "active");
		}
		options[i].onmouseout = function() {
			var activeDel = document.querySelector("#nav .option.active_del");
			if (!activeDel) return;
			replaceClass(activeDel, "active_del", "active");
			if (hasClass(this, "active"))
				delClass(this, "active");
		}
	}
}
navEffects();
































