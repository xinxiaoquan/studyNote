window.AFTER = function(info) {
	alert(info);
}

var title = document.querySelector("input[name=title]");
window.FORMRULE(title, "blur", function() {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "VPS资讯标题不能为空！");
		return;
	}
	window.FORMDELERR(span);
});

var content = document.querySelector("textarea[name=content]");
window.FORMRULE(content, "blur", function() {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "VPS资讯内容不能为空！");
		return;
	}
	window.FORMDELERR(span);
});

var time = document.querySelector("input[name=time]");
time.value = new Date().getTime();