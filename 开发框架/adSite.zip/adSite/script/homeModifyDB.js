window.AFTER = function(info) {
	alert(info);
}

var user = document.querySelector("form input[name=user]");
window.FORMRULE(user, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "用户名不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var pwd = document.querySelector("form input[name=pwd]");
window.FORMRULE(pwd, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "密码不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var dAdress = document.querySelector("form input[name=dAdress]");
window.FORMRULE(dAdress, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "数据库地址不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var dName = document.querySelector("form input[name=dName]");
window.FORMRULE(dName, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "数据库名不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var dUser = document.querySelector("form input[name=dUser]");
window.FORMRULE(dUser, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "数据库用户名不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var dPwd = document.querySelector("form input[name=dPwd]");
window.FORMRULE(dPwd, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "数据库密码不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

ajax("get", "../opaData/getDatabaseInfo.php", null, function(data) {
	if (data == "") return;
	data = JSON.parse(data);
	window.MODIFYFORM(data);
});