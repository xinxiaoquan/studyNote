//获取未通过SEO的个数（气泡）
setReviewBubbles();

//分页条绑定事件
function pageEvent(ul) {
	var lis = ul.querySelectorAll("li");
	for (var i = 0; i < lis.length; i++) {
		if (hasClass(lis[i], "select")) {
			lis[i].onclick = function() {
				var page = prompt("输入跳转的页数");
				if (!page || page <= 0)
					page = 1;
				else {
					var lastPageNo = this.parentElement.lastChild;
					lastPageNo = lastPageNo.getAttribute("pageNo");
					lastPageNo = Number(lastPageNo);
					if (page > lastPageNo)
						page = lastPageNo;
				}
				getSeoPageBar(page);
			}
			continue;
		}
		lis[i].onclick = function() {
			var page = this.getAttribute("pageNo");
			if (page)	getSeoPageBar(page);
		}
	}
}

//获取SEO的数据
function getSeoPageBar(pageNo) {
	if (!pageNo) pageNo = 1;
	
	var all = document.querySelector("#right table td.all");
	all.onclick = function() {
		var selects = document.querySelectorAll("#right table tr td:first-child");
		for (var i = 0; i < selects.length; i++) {
			if (selects[i] == this) continue;
			selects[i].onmousedown();
			selects[i].onmouseup();
		}
	}
	
	ajax("get", "../opaData/getPageBar.php?query=id,user,name,url,adress,mobile,qq,wx,recommend,type,class,area,quality,time&noPass&table=seo&pageNo="+pageNo,
		null, function(data) {
		if (data == "") return;
		data = JSON.parse(data);

		var allRows = document.querySelector("#right ul.alert li:first-child");
		var selectRows = document.querySelector("#right ul.alert li:nth-child(2)");
		
		var tbody = document.querySelector("#right table tbody");
		tbody.innerHTML = "";
		var ul = document.querySelector("#right ul");
		ul.innerHTML = data["page"];
		pageEvent(ul);
		var rows = data["rows"];
		
		allRows.innerHTML = rows.length;

		for (var i = 0; i < rows.length; i++) {
			var tr = document.createElement("tr");
			tr.innerHTML = `
				<td>${decodeURIComponent(rows[i][0])}</td>
				<td>${decodeURIComponent(rows[i][1])}</td>
				<td>${decodeURIComponent(rows[i][2])}</td>
				<td>${decodeURIComponent(rows[i][3])}</td>
				<td>${decodeURIComponent(rows[i][4])}</td>
				<td>${decodeURIComponent(rows[i][5])}</td>
				<td>${decodeURIComponent(rows[i][6])}</td>
				<td>${decodeURIComponent(rows[i][7])}</td>
				<td>${decodeURIComponent(rows[i][8])}</td>
				<td>${change("type", rows[i][9])}</td>
				<td>${change("class", rows[i][10])}</td>
				<td>${change("area", rows[i][11])}</td>
				<td>${change("quality", rows[i][12])}</td>
				<td class="pass">通过</td>
				<td class="del">删除</td>
			`;
			function change(type, data) {
				data = decodeURIComponent(data);
				if (type == "time") {
					data = toShowDate(data, "y-m-d h:i:s");
				}
				if (type == "type") {
					if (data == 1) data = "PC";
					if (data == 2) data = "移动";
				}
				if (type == "class") {
					if (data == 1) data = "百度";
					if (data == 2) data = "360";
					if (data == 3) data = "搜狗";
				}
				if (type == "area") {
					if (data == 1) data = "北京";
					if (data == 2) data = "上海";
					if (data == 3) data = "广东";
					if (data == 4) data = "福建";
					if (data == 5) data = "浙江";
					if (data == 6) data = "山东";
					if (data == 7) data = "山西";
					if (data == 8) data = "辽宁";
					if (data == 9) data = "湖北";
					if (data == 10) data = "河北";
					if (data == 11) data = "重庆";
					if (data == 12) data = "陕西";
					if (data == 13) data = "河南";
					if (data == 14) data = "四川";
					if (data == 15) data = "湖南";
					if (data == 16) data = "江西";
					if (data == 17) data = "天津";
					if (data == 18) data = "江苏";
					if (data == 19) data = "广西";
					if (data == 20) data = "安徽";
					if (data == 21) data = "吉林";
					if (data == 22) data = "黑龙江";
					if (data == 23) data = "海南";
					if (data == 24) data = "贵州";
					if (data == 25) data = "云南";
					if (data == 26) data = "甘肃";
					if (data == 27) data = "青海";
					if (data == 28) data = "内蒙古";
					if (data == 29) data = "西藏";
					if (data == 30) data = "宁夏";
					if (data == 31) data = "新疆";
					if (data == 32) data = "香港";
					if (data == 33) data = "澳门";
					if (data == 34) data = "台湾";
				}
				if (type == "quality") {
					if (data == 1) data = "个人";
					if (data == 2) data = "团队";
					if (data == 3) data = "公司";
				}
				return data;
			}
			
			var select = tr.querySelector("td:first-child");
			select.onmousedown = function() {
				tbody.setAttribute("click", "true");
				if (this.parentElement.className != "select") {
					this.parentElement.className = "select";
					var del = this.parentElement.querySelector(".del");
					del.innerHTML = "批量删除";
					var pass = this.parentElement.querySelector(".pass");
					pass.innerHTML = "批量通过";
				} else {
					this.parentElement.className = "";
					var del = this.parentElement.querySelector(".del");
					del.innerHTML = "删除";
					var pass = this.parentElement.querySelector(".pass");
					pass.innerHTML = "通过";
				}
			}
			select.onmouseup = function() {
				tbody.setAttribute("click", "false");
				selectRows.innerHTML = document.querySelectorAll("#right tr.select").length;
			}
			select.onmouseover = function() {
				if (tbody.getAttribute("click") == "true") {
					if (this.parentElement.className != "select") {
						this.parentElement.className = "select";
						var del = this.parentElement.querySelector(".del");
						del.innerHTML = "批量删除";
						var pass = this.parentElement.querySelector(".pass");
						pass.innerHTML = "批量通过";
					} else {
						this.parentElement.className = "";
						var del = this.parentElement.querySelector(".del");
						del.innerHTML = "删除";
						var pass = this.parentElement.querySelector(".pass");
						pass.innerHTML = "通过";
					}
				}
			}
			tbody.appendChild(tr);
			
			var del = tr.querySelector("#right .del");
			del.onclick = function() {
				var tr = this.parentElement;
				tr.className = "select";
				var ids = tr.firstElementChild.innerHTML;
				var select = document.querySelectorAll("#right tr.select td:first-child");
				var td = tr.firstElementChild;
				for (var i = 0; i < select.length; i++) {
					if (select[i] == td) continue;
					ids += ","+select[i].innerHTML
				}
				if (!confirm("是否删除？"))
					return;
				ajax("get", "../opaData/homeDelSeo.php?ids="+ids,
				null, function() {
					if (!select) return;
					for (var i = 0; i < select.length; i++) {
						var tr = select[i].parentElement;
						tr.parentElement.removeChild(tr);
					}
					setReviewBubbles();
				});
			}
			
			var pass = tr.querySelector("#right .pass");
			pass.onclick = function() {
				var tr = this.parentElement;
				tr.className = "select";
				var ids = tr.firstElementChild.innerHTML;
				var select = document.querySelectorAll("#right tr.select td:first-child");
				var td = tr.firstElementChild;
				for (var i = 0; i < select.length; i++) {
					if (select[i] == td) continue;
					ids += ","+select[i].innerHTML
				}
				if (!confirm("是否通过？"))
					return;
				ajax("get", `../opaData/homePassSeo.php?ids=${ids}&time=${new Date().getTime()}`,
				null, function() {
					if (!select) return;
					for (var i = 0; i < select.length; i++) {
						for (var i = 0; i < select.length; i++) {
							var elem = select[i].parentElement.querySelector(".pass");
							elem.innerHTML = "通过通过"
							elem.className = "";
							elem.onclick = null;
						}
					}
					setReviewBubbles();
					setCreateHtmlBubbles();
				});
			}
			
		}
	});
}

getSeoPageBar();




























