window.AFTER = function(info) {
	alert(info);
}

var id = document.querySelector("input[name=id]");
window.FORMRULE(id, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "联盟资讯ID不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});
id.addEventListener("blur", function() {
	if (this.value == "") return;
	ajax("get", "../opaData/getDatasById.php?table=ad_info&allData=true&id="+this.value,
	null, function(data) {
		if (!data || data == "null" || data == "数据不全！") {
			var span = document.querySelector("span."+id.name);
			window.FORMERR(span, "数据库中没有此ID，不能修改！");
			window.FORMRESET();
			return;
		}
		data = JSON.parse(decodeURIComponent(data));
		window.MODIFYFORM(data);
	});
});

var title = document.querySelector("input[name=title]");
window.FORMRULE(title, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "联盟资讯标题不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var content = document.querySelector("textarea[name=content]");
window.FORMRULE(content, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "联盟资讯内容不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var time = document.querySelector("input[name=time]");
time.value = new Date().getTime();