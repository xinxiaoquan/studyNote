window.AFTER = function(info) {
	alert(info);
	setCreateHtmlBubbles();
}

var vpsId = document.querySelector("form input[name=vpsId]");
window.FORMRULE(vpsId, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "VPS服务ID不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});
vpsId.addEventListener("blur", function() {
	if (this.value == "") return;
	ajax("get", "../opaData/getDatasById.php?table=vps&id="+this.value,
	null, function(data) {
		if (!data || data == "null" || data == "数据不全！") {
			var span = document.querySelector("span."+vpsId.name);
			window.FORMERR(span, "数据库中没有此ID，不能修改！");
			window.FORMRESET();
			return;
		}
		data = JSON.parse(decodeURIComponent(data));
		window.MODIFYFORM(data, function(name) {
			return name.replace("vps", "").toLowerCase();
		});
	});
});

var vpsName = document.querySelector("form input[name=vpsName]");
window.FORMRULE(vpsName, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "VPS名字不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var vpsUrl = document.querySelector("form input[name=vpsUrl]");
window.FORMRULE(vpsUrl, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "网址不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var vpsRecommend = document.querySelector("form textarea[name=vpsRecommend]");
window.FORMRULE(vpsRecommend, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "VPS介绍不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});