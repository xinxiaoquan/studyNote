
var imgFile = document.querySelector("input[type=file][name=img]");
var imgBtn = document.querySelector("button[class=img]");
imgBtn.onclick = function() {
	imgFile.click();
	return false;
}
window.FORMRULE(imgBtn, "blur", function() {
	var span = document.querySelector("span."+this.className);
	if (imgFile.value == "") {
		window.FORMERR(span, "图片文件不能为空！");
		return;
	}
	window.FORMDELERR(span);
});

var link = document.querySelector("input[name=link]");
window.FORMRULE(link, "blur", function() {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "广告链接不能为空！");
		return;
	}
	window.FORMDELERR(span);
});