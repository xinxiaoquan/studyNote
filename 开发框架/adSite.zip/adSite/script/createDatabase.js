window.AFTER = function(info) {
	alert(info);
	if (info == "数据写入成功！" ||
			info == "数据库信息已经存在！")
		location.href = "../home";
}
var user = document.querySelector("form input[name=user]");
window.FORMRULE(user, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "用户名不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var pwd = document.querySelector("form input[name=pwd]");
window.FORMRULE(pwd, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "密码不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var dAdress = document.querySelector("form input[name=dAdress]");
window.FORMRULE(dAdress, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "数据库地址不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var dName = document.querySelector("form input[name=dName]");
window.FORMRULE(dName, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "数据库名不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var dUser = document.querySelector("form input[name=dUser]");
window.FORMRULE(dUser, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "数据库用户名不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var dPwd = document.querySelector("form input[name=dPwd]");
window.FORMRULE(dPwd, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "数据库密码不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});
































