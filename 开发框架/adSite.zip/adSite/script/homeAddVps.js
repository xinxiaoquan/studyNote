window.AFTER = function(info) {
	alert(info);
	setCreateHtmlBubbles();
}

var vpsName = document.querySelector("form input[name=vpsName]");
window.FORMRULE(vpsName, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "VPS名字不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});
var vpsUrl = document.querySelector("form input[name=vpsUrl]");
window.FORMRULE(vpsUrl, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "网址不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});
var vpsRecommend = document.querySelector("form textarea[name=vpsRecommend]");
window.FORMRULE(vpsRecommend, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value == "") {
		window.FORMERR(span, "VPS介绍不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});
var time = document.querySelector("form [name=time]");
time.value = new Date().getTime();






