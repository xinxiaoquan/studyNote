//获取所有备份文件列表
(function() {
	ajax("get", "../opaData/backup.php?get=1", null, function(files) {
		if (files == "") return;
		var files = JSON.parse(files);
		var list = document.querySelector("#right .board .list");
		for (var i = 0; i < files.length; i++) {
			var li = document.createElement("li");
			var size = (files[i][1]/1024).toFixed(2);
			li.innerHTML = `<span class="file">${files[i][0]}</span><span class="goBack">还原</span><span class="download">下载</span><span class="del">删除</span><span>占地：${size}KB</span>`;
			setEvent(li);
			list.appendChild(li);
		}
	});
})();

//上传备份文件功能
(function() {
	var upload = document.querySelector("#right button.upload");
	var fileBtn = document.querySelector("#right form input[type=file]");
	var submit = document.querySelector("#right form input[type=submit]");
	upload.onclick = function() {
		fileBtn.click();
	}
	fileBtn.onchange = function() {
		submit.click();
	}
})();

//备份数据功能
(function() {
	var btn = document.querySelector("#right .backupBtn");
	var _alert = document.querySelector("#right .alert");
	btn.onclick = function() {
		delClass(_alert, "hidden");
		_alert.innerHTML = "正在备份，请稍后……";
		ajax("get", "../opaData/backup.php?backup=1", null, function(json) {
			if (json == "") return;
			addClass(_alert, "hidden");
			if (!json) return;
			if (json.indexOf("失败") != -1) {
				alert(json);
				return;
			}
			var data = JSON.parse(json);
			var size = (data[1]/1024).toFixed(2);
			var li = document.createElement("li");
			li.innerHTML = `<span class="file">${data[0]}</span><span class="goBack">还原</span><span class="download">下载</span><span class="del">删除</span><span>占地：${size}KB</span>`;
			var list = document.querySelector("#right .board .list");
			if (list.firstElementChild)
				list.insertBefore(li, list.firstElementChild);
			else list.appendChild(li);
			setEvent(li);
		});
	}
})();

//为新元素（LI）设置事件
function setEvent(li) {
	//还原
	var goBack = li.querySelector(".goBack");
	goBack.onclick = function() {
		var file = li.querySelector(".file");
		file = file.innerHTML;
		var _alert = document.querySelector("#right .alert");
		_alert.innerHTML = "正在还原，请稍后……";
		delClass(_alert, "hidden")
		ajax("get", "../opaData/backup.php?goBack="+file, null, function(info) {
			if (info == "") return;
			addClass(_alert, "hidden");
			alert(info);
			var tasks = document.querySelectorAll("[task]");
			for (var i = 0; i < tasks.length; i++)
				tasks[i].removeAttribute("task");
		});
	}
	//下载
	var download = li.querySelector(".download");
	download.onclick = function() {
		var file = li.querySelector(".file");
		file = file.innerHTML;
		window.open("../json/backup/"+file, "_blank");
	}
	//删除
	var del = li.querySelector(".del");
	del.onclick = function() {
		if (!confirm("确认删除？"))
			return;
		var that = this;
		var file = li.querySelector(".file");
		file = file.innerHTML;
		ajax("get", "../opaData/backup.php?del="+file, null, function(info) {
			if (info == "") return;
			if (info == "ok") {
				var elem = that.parentElement;
				elem.parentElement.removeChild(elem);
			} else alert("删除失败！请稍后重试！");
		});
	}
}



























