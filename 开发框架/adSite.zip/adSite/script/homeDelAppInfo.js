//分页条绑定事件
function pageEvent(ul) {
	var lis = ul.querySelectorAll("li");
	for (var i = 0; i < lis.length; i++) {
		if (hasClass(lis[i], "select")) {
			lis[i].onclick = function() {
				var page = prompt("输入跳转的页数");
				if (!page || page <= 0)
					page = 1;
				else {
					var lastPageNo = this.parentElement.lastChild;
					lastPageNo = lastPageNo.getAttribute("pageNo");
					lastPageNo = Number(lastPageNo);
					if (page > lastPageNo)
						page = lastPageNo;
				}
				getSeoPageBar(page);
			}
			continue;
		}
		lis[i].onclick = function() {
			var page = this.getAttribute("pageNo");
			if (page)	getSeoPageBar(page);
		}
	}
}

//获取APP中的数据
function getSeoPageBar(pageNo) {
	if (!pageNo) pageNo = 1;
	
	var all = document.querySelector("#right table td.all");
	all.onclick = function() {
		var selects = document.querySelectorAll("#right table tr td:first-child");
		for (var i = 0; i < selects.length; i++) {
			if (selects[i] == this) continue;
			selects[i].onmousedown();
			selects[i].onmouseup();
		}
	}
	
	ajax("get", "../opaData/getPageBar.php?query=id,title,content&allData&table=app_info&pageNo="+pageNo,
		null, function(data) {
		if (data == "") return;
		data = JSON.parse(data);
		
		var allRows = document.querySelector("#right ul.alert li:first-child");
		var selectRows = document.querySelector("#right ul.alert li:nth-child(2)");
		
		var tbody = document.querySelector("#right table tbody");
		tbody.innerHTML = "";
		var ul = document.querySelector("#right ul");
		ul.innerHTML = data["page"];	
		pageEvent(ul);
		var rows = data["rows"];
		
		allRows.innerHTML = rows.length;
		
		for (var i = 0; i < rows.length; i++) {
			var tr = document.createElement("tr");
			tr.innerHTML = `
				<td>${decodeURIComponent(rows[i][0])}</td>
				<td>${decodeURIComponent(rows[i][1])}</td>
				<td>${decodeURIComponent(rows[i][2])}</td>
			`;
			var select = tr.querySelector("td:first-child");
			select.onmousedown = function() {
				tbody.setAttribute("click", "true");
				if (this.parentElement.className != "select") {
					this.parentElement.className = "select";
					this.parentElement.lastChild.innerHTML = "批量删除";
				} else {
					this.parentElement.className = "";
					this.parentElement.lastChild.innerHTML = "删除";
				}
			}
			select.onmouseup = function() {
				tbody.setAttribute("click", "false");
				selectRows.innerHTML = document.querySelectorAll("#right tr.select").length;
			}
			select.onmouseover = function() {
				if (tbody.getAttribute("click") == "true") {
					if (this.parentElement.className != "select") {
						this.parentElement.className = "select";
						this.parentElement.lastChild.innerHTML = "批量删除";
					} else {
						this.parentElement.className = "";
						this.parentElement.lastChild.innerHTML = "删除";
					}
				}
			}
			var del = document.createElement("td");
			del.innerHTML = "删除";
			del.className = "del";
			del.onclick = function() {
				var td = this.parentElement.firstElementChild;
				td.parentElement.className = "select";
				var ids = td.innerHTML;
				var select = document.querySelectorAll("#right tr.select td:first-child");
				for (var i = 0; i < select.length; i++) {
					if (select[i] == td) continue;
					ids += ","+select[i].innerHTML
				}
				if (!confirm("是否删除？")) return;
				ajax("get", "../opaData/homeDelAppInfo.php?ids="+ids, null, function() {
					if (!select) return;
					for (var i = 0; i < select.length; i++) {
						var tr = select[i].parentElement;
						tr.parentElement.removeChild(tr);
					}
				});
			}
			tr.appendChild(del);
			tbody.appendChild(tr);
		}
	});
}

getSeoPageBar();




























