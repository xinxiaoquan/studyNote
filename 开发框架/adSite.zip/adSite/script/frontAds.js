
//渲染各种广告
(function() {
	var topAd = document.querySelector("#top");
	var textAd = document.querySelector("#textAd .box");
	var imgAd = document.querySelector("#imgAd");
	var middenAd = document.querySelector("#middenAd");
	ajax("get", `${cssJsPos}json/siteImgAd.json`, null, function(json) {
		if (json == "") return;
		var arr = JSON.parse(decodeURIComponent(json));
		if (Object.keys(arr).length == 0) return;
		var img = arr["img"];
		var link = arr["link"];
		topAd.innerHTML += `<div class="ad" onclick="window.open('${link}','_blank')"><img  src="${cssJsPos}images/siteImg/${img}" /></div>`;
	});
	ajax("get", `${cssJsPos}json/${TYPE}TextAd.json`, null, function(json) {
		if (json == "") return;
		var arr = JSON.parse(decodeURIComponent(json));
		if (Object.keys(arr).length == 0) return;
		textAd.parentElement.className = "";
		for (var i = 0; i < arr.length; i++) {
			var text = arr[i][0];
			var link = arr[i][1];
			textAd.innerHTML += `<div class="ad" onclick="window.open('${link}','_blank')">${text}</div>`;
		}
	});
	ajax("get", `${cssJsPos}json/${TYPE}ImgAd.json`, null, function(json) {
		if (json == "") return;
		var arr = JSON.parse(decodeURIComponent(json));
		if (Object.keys(arr).length == 0) return;
		imgAd.className = "";
		for (var i = 0; i < arr.length; i++) {
			var img = arr[i][0];
			var link = arr[i][1];
			imgAd.innerHTML += `<div class=\"ad\" onclick=\"window.open('${link}','_blank')\"><img src="${cssJsPos}images/${TYPE}Img/${img}" /></div>`;
		}
	});
	if (middenAd)
	ajax("get", `${cssJsPos}json/${TYPE}ContentImgAd.json`, null, function(json) {
		if (json == "") return;
		var arr = JSON.parse(decodeURIComponent(json));
		if (Object.keys(arr).length == 0) return;
		for (var i = 0; i < arr.length; i++) {
			var img = arr[i][0];
			var link = arr[i][1];
			middenAd.innerHTML += `<div class=\"ad\" onclick=\"window.open('${link}','_blank')\"><img src="${cssJsPos}images/${TYPE}ContentImg/${img}" /></div>`;
		}
	});
})();