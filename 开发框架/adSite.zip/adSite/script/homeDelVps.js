//分页条绑定事件
function pageEvent(ul) {
	var lis = ul.querySelectorAll("li");
	for (var i = 0; i < lis.length; i++) {
		if (hasClass(lis[i], "select")) {
			lis[i].onclick = function() {
				var page = prompt("输入跳转的页数");
				if (!page || page <= 0)
					page = 1;
				else {
					var lastPageNo = this.parentElement.lastChild;
					lastPageNo = lastPageNo.getAttribute("pageNo");
					lastPageNo = Number(lastPageNo);
					if (page > lastPageNo)
						page = lastPageNo;
				}
				getAdPageBar(page);
			}
			continue;
		}
		lis[i].onclick = function() {
			var page = this.getAttribute("pageNo");
			if (page)	getAdPageBar(page);
		}
	}
}

//获取广告联盟中的数据
function getAdPageBar(pageNo) {
	if (!pageNo) pageNo = 1;
	
	var all = document.querySelector("#right table td.all");
	all.onclick = function() {
		var selects = document.querySelectorAll("#right table tr td:first-child");
		for (var i = 0; i < selects.length; i++) {
			if (selects[i] == this) continue;
			selects[i].onmousedown();
			selects[i].onmouseup();
		}
	}
	
	ajax("get", "../opaData/getPageBar.php?query=*&table=vps&pageNo="+pageNo,
		null, function(data) {
		if (data == "") return;
		data = JSON.parse(data);
		
		var allRows = document.querySelector("#right ul.alert li:first-child");
		var selectRows = document.querySelector("#right ul.alert li:nth-child(2)");
		
		var tbody = document.querySelector("#right table tbody");
		tbody.innerHTML = "";
		var ul = document.querySelector("#right ul");
		ul.innerHTML = data["page"];
		pageEvent(ul);
		var rows = data["rows"];
		
		allRows.innerHTML = rows.length;
		
		for (var i = 0; i < rows.length; i++) {
			var tr = document.createElement("tr");
			tr.innerHTML = `
				<td>${decodeURIComponent(rows[i][0])}</td>
				<td>${decodeURIComponent(rows[i][1])}</td>
				<td>${change("adress", rows[i][2])}</td>
				<td>${change("room", rows[i][3])}</td>
				<td>${change("line", rows[i][4])}</td>
				<td>${change("class", rows[i][5])}</td>
				<td>${change("type", rows[i][6])}</td>
				<td>${change("vpsClass", rows[i][7])}</td>
				<td>${decodeURIComponent(rows[i][8])}</td>
				<td>${decodeURIComponent(rows[i][9])}</td>
				<td>${change("time", rows[i][10])}</td>
			`;
			function change(type, data) {
				data = decodeURIComponent(data);
				if (type == "adress" || type == "room") {
					if (data == 1) return "北京";
					if (data == 2) return "上海";
					if (data == 3) return "广东";
					if (data == 4) return "福建";
					if (data == 5) return "浙江";
					if (data == 6) return "山东";
					if (data == 7) return "山西";
					if (data == 8) return "辽宁";
					if (data == 9) return "湖北";
					if (data == 10) return "河北";
					if (data == 11) return "重庆";
					if (data == 12) return "陕西";
					if (data == 13) return "河南";
					if (data == 14) return "四川";
					if (data == 15) return "湖南";
					if (data == 16) return "江西";
					if (data == 17) return "天津";
					if (data == 18) return "江苏";
					if (data == 19) return "广西";
					if (data == 20) return "安徽";
					if (data == 21) return "吉林";
					if (data == 22) return "黑龙江";
					if (data == 23) return "海南";
					if (data == 24) return "贵州";
					if (data == 25) return "云南";
					if (data == 26) return "甘肃";
					if (data == 27) return "青海";
					if (data == 28) return "内蒙古";
					if (data == 29) return "西藏";
					if (data == 30) return "宁夏";
					if (data == 31) return "新疆";
					if (data == 32) return "香港";
					if (data == 33) return "澳门";
					if (data == 34) return "台湾";
					if (data == 35) return "日本";
					if (data == 36) return "美国";
					if (data == 37) return "韩国";
					if (data == 38) return "欧洲";
					if (data == 39) return "印度";
					if (data == 40) return "泰国";
					if (data == 41) return "缅甸";
					if (data == 42) return "老挝";
					if (data == 43) return "越南";
					if (data == 44) return "新加坡";
					if (data == 45) return "柬埔寨";
					if (data == 46) return "俄罗斯";
					if (data == 47) return "其他国家";
				}
				if (type == "line") {
					if (data == 1) return "中国联通";
					if (data == 2) return "中国电信";
					if (data == 3) return "中国移动";
					if (data == 4) return "港台线路";
					if (data == 5) return "双线主机";
					if (data == 6) return "海外主机";
					if (data == 7) return "其他线路";
				}
				if (type == "class") {
					if (data == 1) return "国外服务器";
					if (data == 2) return "国内服务器";
					if (data == 3) return "国内VPS";
					if (data == 4) return "国外VPS";
					if (data == 5) return "国外虚拟主机";
					if (data == 6) return "国内虚拟主机";
				}
				if (type == "type") {
					if (data == 1) return "DDOS高防服务器";
					if (data == 2) return "抗投诉服务器";
					if (data == 3) return "站群服务器";
					if (data == 4) return "不限流量服务器";
					if (data == 5) return "不限内容服务器";
				}
				if (type == "vpsClass") {
					if (data == 1) return "国内VPS";
					if (data == 2) return "国外VPS";
					if (data == 3) return "DDOS高防VPS";
					if (data == 4) return "不限流量VPS";
					if (data == 5) return "windows VPS";
					if (data == 6) return "VPS云/云服务器";
				}
				if (type == "time") {
					data = toShowDate(data, "y-m-d h:i:s");
				}
				return data;
			}
			var select = tr.querySelector("td:first-child");
			select.onmousedown = function() {
				tbody.setAttribute("click", "true");
				if (this.parentElement.className != "select") {
					this.parentElement.className = "select";
					this.parentElement.lastChild.innerHTML = "批量删除";
				} else {
					this.parentElement.className = "";
					this.parentElement.lastChild.innerHTML = "删除";
				}
			}
			select.onmouseup = function() {
				tbody.setAttribute("click", "false");
				selectRows.innerHTML = document.querySelectorAll("#right tr.select").length;
			}
			select.onmouseover = function() {
				if (tbody.getAttribute("click") == "true") {
					if (this.parentElement.className != "select") {
						this.parentElement.className = "select";
						this.parentElement.lastChild.innerHTML = "批量删除";
					} else {
						this.parentElement.className = "";
						this.parentElement.lastChild.innerHTML = "删除";
					}
				}
			}
			var del = document.createElement("td");
			del.innerHTML = "删除";
			del.className = "del";
			del.onclick = function() {
				var td = this.parentElement.firstElementChild;
				td.parentElement.className = "select";
				var ids = td.innerHTML;
				var select = document.querySelectorAll("#right tr.select td:first-child");
				for (var i = 0; i < select.length; i++) {
					if (select[i] == td) continue;
					ids += ","+select[i].innerHTML
				}
				if (!confirm("是否删除？"))
					return;
				ajax("get", "../opaData/homeDelVps.php?ids="+ids, null, function() {
					if (!select) return;
					for (var i = 0; i < select.length; i++) {
						var tr = select[i].parentElement;
						tr.parentElement.removeChild(tr);
					}
					setCreateHtmlBubbles();
				});
			}
			tr.appendChild(del);
			tbody.appendChild(tr);
		}
	});
}

getAdPageBar();




























