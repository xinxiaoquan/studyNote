//ajax异步函数的封装
function ajax(method, url, data, fn) {
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function() {
		if (this.readyState == 4) {
			var status = this.status;
			var response = this.responseText;
			if (fn)
				(function() {
					if (status != 200)
						fn("");
					else fn(response);
				})();
		}
	}
	xhr.open(method, url);
	xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded;charset=UTF-8");
	xhr.send(data);
}

//有顺序的异步请求
function queueAjax(taskList, finalFn) {
	//taskList 是每个请求的几个参数
	//finalFn 是所有ajax请求完成后执行的函数
	var length = taskList.length;
	if (length == 0) return;
	var index = 0;
	doIt(taskList[index]);
	function doIt(task) {
		//method, url, data, fn
		var method = task[0];
		var url = task[1];
		var data = task[2];
		var fn = task[3];
		ajax(method, url, data, function(data) {
			if(data) fn(data);
			index++;
			if (index < length)
				doIt(taskList[index]);
			else if (finalFn) finalFn();
		});
	}
}

//添加css样式
function addCSS(path) {
	var dom = document.createElement("link");
	dom.rel = "stylesheet";
	dom.href = path;
	document.head.appendChild(dom);
}
//重新加载css
function reloadCSS(dom) {
	if (!dom) return false;
	var path = dom.href;
	dom.parentElement.removeChild(dom);
	addCSS(path);
}

//添加js脚本
function addJS(path) {
	var dom = document.createElement("script");
	dom.src = path;
	document.body.appendChild(dom);
}
//重新加载js
function reloadJS(dom) {
	if (!dom) return false;
	var path = dom.src;
	dom.parentElement.removeChild(dom);
	addJS(path);
}

//判断类是否存在
function hasClass(dom, className) {
	if (!dom) return false;
	if (dom.className.indexOf(className) != -1)
		return true;
	else return false;
}
//添加类
function addClass(dom, className) {
	if (!dom) return false;
	if (dom.length !== undefined) {
		for (var i = 0; i < dom.length; i++) {
			if (dom[i].className.indexOf(className) == -1)
				dom[i].className += " "+className;
		}
	} else {
		if (dom.className.indexOf(className) == -1)
			dom.className += " "+className;
	}
}
//删除类
function delClass(dom, className) {
	if (!dom) return false;
	if (dom.length !== undefined) {
		for (var i = 0; i < dom.length; i++) {
			dom[i].className = dom[i].className.replace(" "+className, "");
		}
	} else dom.className = dom.className.replace(" "+className, "");
}
//替换类
function replaceClass(dom, oldClass, newClass) {
	if (!dom) return false;
	if (dom.length !== undefined) {
		for (var i = 0; i < dom.length; i++)
			dom[i].className = dom[i].className.replace(oldClass, newClass);
	} else dom.className = dom.className.replace(oldClass, newClass);
}

//时间戳转时间
function toShowDate(time, format) {
	var date = new Date(parseInt(time));
	var year = date.getFullYear();
	var month = date.getMonth()+1;
	if (month < 10) month = "0"+month;
	var day = date.getDate();
	if (day < 10) day = "0"+day;
	var hours = date.getHours();
	if (hours < 10) hours = "0"+hours;
	var minutes = date.getMinutes();
	if (minutes < 10) minutes = "0"+minutes;
	var seconds = date.getSeconds();
	if (seconds < 10) seconds = "0"+seconds;
	format = format.replace("y", year);
	format = format.replace("m", month);
	format = format.replace("d", day);
	format = format.replace("h", hours);
	format = format.replace("i", minutes);
	format = format.replace("s", seconds);
	return format;
}