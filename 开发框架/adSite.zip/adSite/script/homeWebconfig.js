window.AFTER = function(info) {
	alert(info);
}

ajax("get", "../json/webconfig.json", null, function(data) {
	if (!data) return;
	data = decodeURIComponent(data);
	data = JSON.parse(data);
	window.MODIFYFORM(data);
	
	adCopyright.value = adCopyright.value.replace(/<br\/>/g,"\n");
	seoCopyright.value = seoCopyright.value.replace(/<br\/>/g,"\n");
	appCopyright.value = appCopyright.value.replace(/<br\/>/g,"\n");
	vpsCopyright.value = vpsCopyright.value.replace(/<br\/>/g,"\n");
});

var webRoot = document.querySelector("form input[name=webRoot]");
window.FORMRULE(webRoot, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "网站根目录不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	if (this.value.charAt(this.value.length-1) != "/")
		this.value += "/";
	window.FORMDELERR(span);
});

var adDir = document.querySelector("form input[name=adDir]");
window.FORMRULE(adDir, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "广告联盟文件存储目录不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var adTitle = document.querySelector("form input[name=adTitle]");
window.FORMRULE(adTitle, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "广告联盟标题不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var adCopyright = document.querySelector("form textarea[name=adCopyright]");
window.FORMRULE(adCopyright, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "广告联盟底部版权不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var seoDir = document.querySelector("form input[name=seoDir]");
window.FORMRULE(seoDir, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "SEO文件存储目录不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var seoTitle = document.querySelector("form input[name=seoTitle]");
window.FORMRULE(seoTitle, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "SEO标题不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var seoCopyright = document.querySelector("form textarea[name=seoCopyright]");
window.FORMRULE(seoCopyright, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "SEO底部版权不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var appDir = document.querySelector("form input[name=appDir]");
window.FORMRULE(appDir, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "APP文件存储目录不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var appTitle = document.querySelector("form input[name=appTitle]");
window.FORMRULE(appTitle, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "APP标题不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var appCopyright = document.querySelector("form textarea[name=appCopyright]");
window.FORMRULE(appCopyright, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "APP底部版权不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var vpsDir = document.querySelector("form input[name=vpsDir]");
window.FORMRULE(vpsDir, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "VPS文件存储目录不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var vpsTitle = document.querySelector("form input[name=vpsTitle]");
window.FORMRULE(vpsTitle, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "VPS标题不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var vpsCopyright = document.querySelector("form textarea[name=vpsCopyright]");
window.FORMRULE(vpsCopyright, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "VPS底部版权不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});