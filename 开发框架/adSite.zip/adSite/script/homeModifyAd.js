window.AFTER = function(info) {
	alert(info);
	setCreateHtmlBubbles(true);
}

var adId = document.querySelector("form input[name=adId]");
window.FORMRULE(adId, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "联盟ID不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

adId.addEventListener("blur", function() {
	if (this.value == "") return;
	ajax("get", "../opaData/getDatasById.php?table=ad&id="+this.value,
	null, function(data) {
		if (!data || data == "null" || data == "数据不全！") {
			var span = document.querySelector("span."+adId.name);
			window.FORMERR(span, "数据库中没有此ID，不能修改！");
			window.FORMRESET();
			return;
		}
		data = JSON.parse(decodeURIComponent(data));
		for (var key in data) {
			var val = data[key];
			key = key.replace("_", "");
			data[key] = val;
		}
		window.MODIFYFORM(data, function(name) {
			return name.replace("ad", "").toLowerCase();
		});
	});
});

var adName = document.querySelector("form input[name=adName]");
window.FORMRULE(adName, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "联盟名称不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var adUrl = document.querySelector("form input[name=adUrl]");
window.FORMRULE(adUrl, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "联盟网址不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var adRecommend = document.querySelector("form [name=adRecommend]");
window.FORMRULE(adRecommend, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "联盟介绍不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

//复选框中的“全部”和“其他”
(function() {
	var checks = document.querySelectorAll("input[name=adType]");
	var all = document.querySelector("input[name=adType][value='全部']");
	var other = document.querySelector("input[name=adType][value='其他']");
	for (var i = 0; i < checks.length; i++) {
		checks[i].onclick = function() {
			if (this != all && this != other) {
				all.checked  = false;
				other.checked  = false;
				return;
			}
			for (var j = 0; j < checks.length; j++) {
				if (this != checks[j])
					checks[j].checked = false;
			}
		}
	}
})();