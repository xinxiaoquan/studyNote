
//右侧推荐联盟
//右侧随机排序
(function() {
	var suggest = document.querySelector("#suggest .rankinGList");
	var rand = document.querySelector("#rand .rankinGList");
	queueAjax([
		["get", `${cssJsPos}json/contentSort/${TYPE}/credit.json`, null, function(json) {
			if (json == "") return;
			suggest.appendChild(fn(json));
		}],
		["get", `${cssJsPos}json/contentSort/${TYPE}/rand.json`, null, function(json) {
			if (json == "") return;
			rand.appendChild(fn(json));
		}]
	], function() {
		var ids = [];
		var elems = document.querySelectorAll(".rankinGList li a");
		for (var i = 0; i < elems.length; i++) {
			var id = elems[i].innerHTML;
			if (id && !isNaN(Number(id)))
				ids[id] = true;
		}
		ids = Object.keys(ids);
		ajax("get", 
		`${cssJsPos}opaData/getPageBar.php?table=${TYPE}&query=id,name,time&orderBy=null&whereIdOr=${JSON.stringify(ids)}&bar=false`,
		null, function(json) {
			if (json == "") return;
			var arr = JSON.parse(json);
			arr = arr["rows"];
			var tmp = [];
			for (var i = 0; i < arr.length; i++)
				tmp[arr[i][0]] = [arr[i][1], arr[i][2]];
			arr = tmp;
			for (var i = 0; i < elems.length; i++) {
				var id = elems[i].innerHTML;
				if (isNaN(id)) continue;
				if (!arr[id]) {
					var parent = elems[i].parentElement.parentElement;
					var elem = elems[i].parentElement;
					parent.removeChild(elem);
					continue;
				}
				var title = decodeURIComponent(arr[id][0]);
				var rankinGList = elems[i].parentElement.parentElement;
				if (rankinGList.hasAttribute("showScore")) {
					var score = elems[i].parentElement.getAttribute("score");
					elems[i].innerHTML = `${title}`;
					elems[i].parentElement.innerHTML += `<span>${score}</span>`;
					continue;
				}
				var date = toShowDate(arr[id][1], "m-d");
				elems[i].innerHTML = `${title}`;
				elems[i].parentElement.innerHTML += `<span>${date}</span>`;
			}
		});
	});
	
	function fn(json) {
		var arr = JSON.parse(decodeURIComponent(json));
		var frag = document.createDocumentFragment();
		for (var i = 0; i < arr.length; i++) {
			if (arr[i] instanceof Array) {
				var id = arr[i][0];
				var score = arr[i][1];
			} else {
				var id = arr[i];
				var score = 0;
			}
			var li = document.createElement("li");
			li.setAttribute("score", score);
			var a = document.createElement("a");
			a.setAttribute("target", "_blank");
			a.setAttribute("href", `${webRoot}${DIR}/${id}.html`);
			a.innerHTML = id;
			li.appendChild(a);
			frag.appendChild(li);
		}
		return frag;
	}
})();

//资讯中所有的时间统一格式
(function() {
	var times = document.querySelectorAll("#showInfo .time");
	for (var i = 0; i < times.length; i++) {
		var num = times[i].innerHTML
		times[i].innerHTML = toShowDate(num, "y-m-d h:i:s");
	}
})();

//联盟资讯
(function() {
	var list = document.querySelector("#info .list");
	ajax("get", `${cssJsPos}opaData/getPageBar.php?table=${TYPE}_info&query=title&orderBy=rand()&pageNum=10&allData&bar=false`,
	null, function(json) {
		if (json == "") return;
		var rows = JSON.parse(json);
		rows = rows["rows"];
		for (var i = 0; i < rows.length; i++) {
			var title = decodeURIComponent(rows[i][0]);
			list.innerHTML += `<li>${title}</li>`;
		}
	});
	
	var more = document.querySelector("#info .more");
	more.onclick = function() {
		window.open(`${webRoot}info/${DIR}.html`, "_blank");
	}
})();

//获取分页条函数
function getPageBar(table, pageNo, show) {
	if (pageNo)
		pageNo = "&pageNo=" + pageNo;
	else pageNo = "&pageNo=1";
	var query = "query=id";
	if (show)
		query = "query=title,time,content";
	ajax("get", `${cssJsPos}opaData/getPageBar.php?${query}&table=${table}&pageNum=50&${pageNo}&allData=true&allNum&allPage`, null, function(data) {
		if (data == "") return;
		data = JSON.parse(data);
		
		var dataTotal = document.querySelector("#showInfo .pageNav .dataTotal");
		dataTotal.innerHTML = data["allNum"];
		var pageTotal = document.querySelector("#showInfo .pageNav .pageTotal");
		pageTotal.innerHTML = data["allPage"];
		
		if (show) {
			var showInfo = document.querySelector("#showInfo");
			var pageNav = showInfo.querySelector(".pageNav");
			var options = showInfo.querySelectorAll("#showInfo .option");
			for (var i = 0; i < options.length; i++)
				showInfo.removeChild(options[i]);
			var rows = data["rows"];
			var frag = document.createDocumentFragment();
			for (var i = 0; i < rows.length; i++) {
				var row = rows[i];
				var title = decodeURIComponent(row[0]);
				var time = decodeURIComponent(row[1]);
				var content = decodeURIComponent(row[2]);
				var option = document.createElement("div");
				option.className = "option";
				option.innerHTML = 
				`<a href=\"\" class=\"title\">${title}</a>
				<div class=\"time\">${toShowDate(time, "y-m-d h:i:s")}</div>
				<div class=\"des\">${content}</div>`;
				frag.appendChild(option);
			}
			showInfo.insertBefore(frag, pageNav);
		}
		
		var pageBar = document.querySelector("#showInfo .pageNav .pageBar");
		var pageGo = document.querySelector("#showInfo .pageGo");
		var pageBack = document.querySelector("#showInfo .pageBack");
		if (!data["page"]) {
			addClass(pageBar, "hidden");
			addClass(pageGo, "hidden");
			addClass(pageBack, "hidden");
			return;
		}
		
		delClass(pageBar, "hidden");
		delClass(pageGo, "hidden");
		delClass(pageBack, "hidden");
		
		pageBar.innerHTML = data["page"];
		
		var lis = pageBar.children;
		for (var i = 0; i < lis.length; i++) {
			var width = getComputedStyle(lis[i]).width;
			width = parseInt(width);
			if (width > 20)
				lis[i].style.padding = "2px 8px";
		}
		
		var active = pageBar.querySelector("li.active");
		var num = active.getAttribute("pageNo") - 1;
		if (num <= 0) num = 1
		pageGo.setAttribute("pageNo", num);
		var num = Number(active.getAttribute("pageNo")) + 1;
		var num2 = pageBar.lastChild.getAttribute("pageNo");
		if (Number(num) > Number(num2))
			num = num2;
		pageBack.setAttribute("pageNo", num);
		
		setUlEvent(table, pageGo, pageBar, pageBack);
		
	});
}

//为pageBar导航条设置事件
function setUlEvent(table, go, ul, back) {
	var children = ul.children;
	for (var i = 0; i < children.length; i++) {
		if (hasClass(children[i], "select")) {
			children[i].onclick = function() {
				var page = prompt("输入跳转的页数");
				page = Number(page);
				if (page <= 0) page = 1;
				else {
					var num = Number(ul.lastChild.getAttribute("pageNo"));
					if (page > num) page = num;
				}
				getPageBar(table, page, true);
			}
			continue;
		}
		children[i].onclick = fn;
	}
	go.onclick = fn;
	back.onclick = fn;
	
	function fn() {
		getPageBar(table, this.getAttribute("pageNo"), true);
	}
}

//获取分页条
getPageBar(TYPE+"_info", 1, false);































