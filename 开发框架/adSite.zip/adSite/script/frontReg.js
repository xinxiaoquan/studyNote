window.AFTER = function(info) {
	alert(info);
	if (info == "注册成功！") {
		location.href = "../";
	}
}

var nickname = document.querySelector("form input[name=nickname]");
window.FORMRULE(nickname, "blur", function() {
	if (this.value === "") {
		window.FORMERR(this, "昵称不能为空！");
		return;
	}
	window.FORMDELERR(this);
});

var mobile = document.querySelector("form input[name=mobile]");
window.FORMRULE(mobile, "blur", function() {
	if (this.value === "") {
		window.FORMERR(this, "手机号不能为空！");
		return;
	}
	window.FORMDELERR(this);
});

var pwd = document.querySelector("form input[name=pwd]");
window.FORMRULE(pwd, "blur", function() {
	if (this.value === "") {
		window.FORMERR(this, "密码不能为空！");
		return;
	}
	window.FORMDELERR(this);
});

var rPwd = document.querySelector("form input.rPwd");
window.FORMRULE(rPwd, "blur", function() {
	var pwd = document.querySelector("form input[name=pwd]");
	if (this.value == "") {
		window.FORMERR(this, "重复密码不能为空！");
		return;
	}
	if (this.value != pwd.value) {
		this.value = "";
		window.FORMERR(this, "密码不一致！");
		return;
	}
	window.FORMDELERR(this);
});

var captcha = document.querySelector("form input[name=captcha]");
window.FORMRULE(captcha, "blur", function() {
	if (this.value === "") {
		window.FORMERR(this, "验证码不能为空！");
		return;
	}
	window.FORMDELERR(this);
});

var reset = document.querySelector("form .reset");
if (reset)
reset.onclick = function() {
	var inputs = document.querySelectorAll("form input[type=text], form input[type=password]");
	for(var i = 0; i < inputs.length; i++) {
		inputs[i].value = "";
		delClass(inputs[i], "err");
	}
}
































