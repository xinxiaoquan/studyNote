
window.AFTER = function(info) {
	alert(info);
}

var position = document.querySelector("form input[name=position]");
window.FORMRULE(position, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "位置不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});