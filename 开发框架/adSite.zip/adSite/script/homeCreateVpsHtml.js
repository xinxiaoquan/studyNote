
//实时更新是否有未生成的网页
setCreateHtmlBubbles();

//按钮上获取未生成网页气泡的数据
(function() {
	var vpsHtml = document.querySelector("#left .createVpsHtml");
	var task = vpsHtml.getAttribute("task");
	if (task) {
		var create = document.querySelector("#right .create");
		create.innerHTML += ` （未生成的有${task}个）`;
	}
})();

//显示选择ID的文本框
(function() {
	var createSelect = document.querySelector(".createSelect");
	var input = document.querySelector(".inputId");
	createSelect.onchange = function() {
		if (this.value == 5) {
			delClass(input, "hidden", "");
			input.placeholder = "输入内容页ID";
		} else if (!hasClass(input, "hidden")) {
			addClass(input, "hidden");
		}
	}
})();

//当生成按钮按下的时候
(function() {
	var createBtn = document.querySelector("#right button.create");
	var createSelect = document.querySelector("#right .createSelect");
	var cmdList = document.querySelector("#right .cmdList");
	var input = document.querySelector(".inputId");
	createBtn.onclick = function() {
		//生成首页
		if (createSelect.value == 2) {
			cmdList.innerHTML = "";
			ajax("get", "../createHtml/main.php?type=vps&who=index",
			null, function(info) {
				if (info == "") return;
				cmdList.innerHTML += `<li><a target="_blank" href=${info}>${info} -- 文件生成成功！</a></li>`;
			});
		}
		//生成未生成的
		if (createSelect.value == 1) {
			cmdList.innerHTML = "";
			ajax("get", "../opaData/getCreateHtmlTask.php?type=vps",
			null, function(ini) {
				if (!ini) {
					cmdList.innerHTML += "<li>无任务！</li>";
					return;
				};
				var arr = ini.split("\r\n");
				var ajaxArr = [];
				for (var i = 0; i < arr.length; i++) {
					if (arr[i] == "") continue;
					ajaxArr.push([
						"get", "../createHtml/main.php?type=vps&who="+arr[i],
						null, function(info) {
							cmdList.innerHTML += `<li><a target="_blank" href=${info}>${info} -- 文件生成成功！</a></li>`;
						}
					]);
				}
				queueAjax(ajaxArr, function() {
					ajax("get", "../opaData/clearCreateHtmlTask.php?type=vps",
					null, function() {
						setCreateHtmlBubbles();
					});
				});
			});
		}
		//生成全部
		if (createSelect.value == 3) {
			cmdList.innerHTML = "";
			queueAjax([
				["get", "../createHtml/main.php?type=vps&who=index",
				null, function(info) {
					if (info == "") return;
					cmdList.innerHTML += `<li><a target="_blank" href=${info}>${info} -- 文件生成成功！</a></li>`;
				}],
				["get", "../createHtml/main.php?type=vps&who=com",
				null, function(info) {
					if (info == "") return;
					cmdList.innerHTML += `<li><a target="_blank" href=${info}>${info} -- 文件生成成功！</a></li>`;
				}],
				["get", "../createHtml/main.php?type=vps&who=info",
				null, function(info) {
					if (info == "") return;
					cmdList.innerHTML += `<li><a target="_blank" href=${info}>${info} -- 文件生成成功！</a></li>`;
				}],
				["get", "../createHtml/main.php?type=vps&who=submit",
				null, function(info) {
					if (info == "") return;
					cmdList.innerHTML += `<li><a target="_blank" href=${info}>${info} -- 文件生成成功！</a></li>`;
				}]
			], function() {
				ajax("get", "../opaData/getPageBar.php?table=vps&query=id&allData&bar=false",
				null, function(json) {
					if (json == "") return;
					var rows = JSON.parse(json);
					rows = rows["rows"];
					var ajaxArr = [];
					for (var i = 0; i < rows.length; i++) {
						ajaxArr.push([
							"get", "../createHtml/main.php?type=vps&who=" + rows[i],
							null, function(info) {
								if (info == "") return;
								cmdList.innerHTML += `<li><a target="_blank" href=${info}>${info} -- 文件生成成功！</a></li>`;
							}
						]);
					}
					queueAjax(ajaxArr, function() {
						ajax("get", "../opaData/clearCreateHtmlTask.php?type=vps",
						null, function() {
							setCreateHtmlBubbles();
						});
					});
				});
			});
		}
		//生成全部内容页
		if (createSelect.value == 4) {
			cmdList.innerHTML = "";
			ajax("get", "../opaData/getPageBar.php?table=vps&query=id&allData&bar=false",
				null, function(json) {
				if (json == "") return;
				var rows = JSON.parse(json);
				rows = rows["rows"];
				var ajaxArr = [];
				for (var i = 0; i < rows.length; i++) {
					ajaxArr.push([
						"get", "../createHtml/main.php?type=vps&who=" + rows[i],
						null, function(info) {
							if (info == "") return;
							cmdList.innerHTML += `<li><a target="_blank" href=${info}>${info} -- 文件生成成功！</a></li>`;
						}
					]);
				}
				queueAjax(ajaxArr, function() {
					ajax("get", "../opaData/clearCreateHtmlTask.php?type=vps",
					null, function() {
						setCreateHtmlBubbles();
					});
				});
			});
		}
		//生成单个内容页
		if (createSelect.value == 5) {
			if (input.value == "" || isNaN(Number(input.value)))
				return false;
			cmdList.innerHTML = "";
			ajax("get", "../createHtml/main.php?type=vps&who=" + input.value,
			null, function(info) {
				if (info == "") return;
				cmdList.innerHTML += `<li><a target="_blank" href=${info}>${info} -- 文件生成成功！</a></li>`;
			});
		}
		//生成评论页
		if (createSelect.value == 6) {
			cmdList.innerHTML = "";
			ajax("get", "../createHtml/main.php?type=vps&who=com",
			null, function(info) {
				if (info == "") return;
				cmdList.innerHTML += `<li><a target="_blank" href=${info}>${info} -- 文件生成成功！</a></li>`;
			});
		}
		//生成资讯页
		if (createSelect.value == 7) {
			cmdList.innerHTML = "";
			ajax("get", "../createHtml/main.php?type=vps&who=info",
			null, function(info) {
				if (info == "") return;
				cmdList.innerHTML += `<li><a target="_blank" href=${info}>${info} -- 文件生成成功！</a></li>`;
			});
		}
		//生成提交页
		if (createSelect.value == 8) {
			cmdList.innerHTML = "";
			ajax("get", "../createHtml/main.php?type=vps&who=submit",
			null, function(info) {
				if (info == "") return;
				cmdList.innerHTML += `<li><a target="_blank" href=${info}>${info} -- 文件生成成功！</a></li>`;
			});
		}
		
		return false;
	}
	
})();




































