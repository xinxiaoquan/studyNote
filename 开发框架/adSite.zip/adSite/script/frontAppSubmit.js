
//右侧推荐APP
//右侧随机排序
(function() {
	var suggest = document.querySelector("#suggest .rankinGList");
	var rand = document.querySelector("#rand .rankinGList");
	queueAjax([
		["get", `${cssJsPos}json/contentSort/${TYPE}/credit.json`, null, function(json) {
			if (json == "") return;
			suggest.appendChild(fn(json));
		}],
		["get", `${cssJsPos}json/contentSort/${TYPE}/rand.json`, null, function(json) {
			if (json == "") return;
			rand.appendChild(fn(json));
		}]
	], function() {
		var ids = [];
		var elems = document.querySelectorAll(".rankinGList li a");
		for (var i = 0; i < elems.length; i++) {
			var id = elems[i].innerHTML;
			if (id && !isNaN(Number(id)))
				ids[id] = true;
		}
		ids = Object.keys(ids);
		ajax("get", 
		`${cssJsPos}opaData/getPageBar.php?table=${TYPE}&query=id,name,time&orderBy=null&whereIdOr=${JSON.stringify(ids)}&bar=false`,
		null, function(json) {
			if (json == "") return;
			var arr = JSON.parse(json);
			arr = arr["rows"];
			var tmp = [];
			for (var i = 0; i < arr.length; i++)
				tmp[arr[i][0]] = [arr[i][1], arr[i][2]];
			arr = tmp;
			for (var i = 0; i < elems.length; i++) {
				var id = elems[i].innerHTML;
				if (isNaN(id)) continue;
				if (!arr[id]) {
					var parent = elems[i].parentElement.parentElement;
					var elem = elems[i].parentElement;
					parent.removeChild(elem);
					continue;
				}
				var title = decodeURIComponent(arr[id][0]);
				var rankinGList = elems[i].parentElement.parentElement;
				if (rankinGList.hasAttribute("showScore")) {
					var score = elems[i].parentElement.getAttribute("score");
					elems[i].innerHTML = `${title}`;
					elems[i].parentElement.innerHTML += `<span>${score}</span>`;
					continue;
				}
				var date = toShowDate(arr[id][1], "m-d");
				elems[i].innerHTML = `${title}`;
				elems[i].parentElement.innerHTML += `<span>${date}</span>`;
			}
		});
	});
	
	function fn(json) {
		var arr = JSON.parse(decodeURIComponent(json));
		var frag = document.createDocumentFragment();
		for (var i = 0; i < arr.length; i++) {
			if (arr[i] instanceof Array) {
				var id = arr[i][0];
				var score = arr[i][1];
			} else {
				var id = arr[i];
				var score = 0;
			}
			var li = document.createElement("li");
			li.setAttribute("score", score);
			var a = document.createElement("a");
			a.setAttribute("target", "_blank");
			a.setAttribute("href", `${webRoot}${DIR}/${id}.html`);
			a.innerHTML = id;
			li.appendChild(a);
			frag.appendChild(li);
		}
		return frag;
	}
})();

//表单的操作
window.AFTER = function(info) {
	alert(info);
}
var appName = document.querySelector("form input[name=appName]");
window.FORMRULE(appName, "blur", function() {
	if (this.value === "") {
		window.FORMERR(this, "APP名称不能为空！");
		return;
	}
	window.FORMDELERR(this);
});
var appPrice = document.querySelector("form input[name=appPrice]");
window.FORMRULE(appPrice, "blur", function() {
	if (this.value === "") {
		window.FORMERR(this, "单价不能为空！");
		return;
	}
	if (isNaN(Number(this.value))) {
		this.value = "";
		window.FORMERR(this, "单价必须是数字！");
		return;
	}
	window.FORMDELERR(this);
});
var appContent = document.querySelector("form textarea[name=appContent]");
window.FORMRULE(appContent, "blur", function() {
	if (this.value === "") {
		window.FORMERR(this, "APP内容不能为空！");
		return;
	}
	window.FORMDELERR(this);
});
var captcha = document.querySelector("form input[name=captcha]");
window.FORMRULE(captcha, "blur", function() {
	if (this.value === "") {
		window.FORMERR(this, "验证码不能为空！");
		return;
	}
	window.FORMDELERR(this);
});

//验证码点击更换
(function() {
	var img = document.querySelector("form .captcha img");
	img.onclick = function() {
		this.src = this.src;
	}
})();

//APP资讯
(function() {
	var list = document.querySelector("#info .list");
	ajax("get", `${cssJsPos}opaData/getPageBar.php?table=${TYPE}_info&query=title&orderBy=rand()&pageNum=10&allData&bar=false`,
	null, function(json) {
		if (json == "") return;
		var rows = JSON.parse(json);
		rows = rows["rows"];
		for (var i = 0; i < rows.length; i++) {
			var title = decodeURIComponent(rows[i][0]);
			list.innerHTML += `<li>${title}</li>`;
		}
	});
	
	var more = document.querySelector("#info .more");
	more.onclick = function() {
		window.open(`${webRoot}info/${DIR}.html`, "_blank");
	}
})();





















