
var imgFile = document.querySelector("input[type=file][name=img]");
var imgBtn = document.querySelector("button[class=img]");
imgBtn.onclick = function() {
	imgFile.click();
	return false;
}
window.FORMRULE(imgBtn, "blur", function(e) {
	var span = document.querySelector("span."+this.className);
	if (imgFile.value == "") {
		window.FORMERR(span, "图片文件不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var link = document.querySelector("input[name=link]");
window.FORMRULE(link, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "广告链接不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var position = document.querySelector("input[name=position]");
window.FORMRULE(position, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "位置不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	if (isNaN(Number(this.value))) {
		window.FORMERR(span, "位置必须是数字！");
		if (!e) this.scrollIntoView();
		return;
	} 
	window.FORMDELERR(span);
});