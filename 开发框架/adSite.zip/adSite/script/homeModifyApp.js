window.AFTER = function(info) {
	alert(info);
	setCreateHtmlBubbles();
}

var appId = document.querySelector("form input[name=appId]");
window.FORMRULE(appId, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "APP推广ID不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});
appId.addEventListener("blur", function() {
	if (this.value == "") return;
	ajax("get", "../opaData/getDatasById.php?table=app&id="+this.value,
	null, function(data) {
		if (!data || data == "null" || data == "数据不全！") {
			var span = document.querySelector("span."+appId.name);
			window.FORMERR(span, "数据库中没有此ID，不能修改！");
			window.FORMRESET();
			return;
		}
		data = JSON.parse(decodeURIComponent(data));
		window.MODIFYFORM(data, function(name) {
			return name.replace("app", "").toLowerCase();
		});
	});
});

var appName = document.querySelector("form input[name=appName]");
window.FORMRULE(appName, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "APP名称不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var appPrice = document.querySelector("form input[name=appPrice]");
window.FORMRULE(appPrice, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "单价不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	if (isNaN(Number(this.value))) {
		window.FORMERR(span, "单价必须是数字！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var appContent = document.querySelector("form textarea[name=appContent]");
window.FORMRULE(appContent, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "APP内容不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});