window.AFTER = function(info) {
	alert(info);
	setCreateHtmlBubbles();
}

var appName = document.querySelector("form input[name=appName]");
window.FORMRULE(appName, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "APP名称不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var appPrice = document.querySelector("form input[name=appPrice]");
window.FORMRULE(appPrice, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "单价不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	if (isNaN(Number(this.value))) {
		window.FORMERR(span, "单价必须是数字！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var appContent = document.querySelector("form textarea[name=appContent]");
window.FORMRULE(appContent, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "APP内容不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var time = document.querySelector("form [name=time]");
time.value = new Date().getTime();
























