
//联盟资讯
(function() {
	var list = document.querySelector("#info .list");
	ajax("get", `${cssJsPos}opaData/getPageBar.php?table=${TYPE}_info&query=title&orderBy=rand()&pageNum=10&allData&bar=false`,
	null, function(json) {
		if (json == "") return;
		var rows = JSON.parse(json);
		rows = rows["rows"];
		for (var i = 0; i < rows.length; i++) {
			var title = decodeURIComponent(rows[i][0]);
			list.innerHTML += `<li>${title}</li>`;
		}
	});
	
	var more = document.querySelector("#info .more");
	more.onclick = function() {
		window.open(`${webRoot}info/${DIR}.html`, "_blank");
	}
})();

//评论区显示时间
(function() {
	var elems = document.querySelectorAll("#com .option .time");
	for (var i = 0; i < elems.length; i++)
		elems[i].innerHTML = toShowDate(elems[i].innerHTML, "y-m-d h:i:s");
})();

//右侧推荐联盟
//右侧随机排序
(function() {
	var suggest = document.querySelector("#suggest .rankinGList");
	var rand = document.querySelector("#rand .rankinGList");
	queueAjax([
		["get", `${cssJsPos}json/contentSort/${TYPE}/credit.json`, null, function(json) {
			if (json == "") return;
			suggest.appendChild(fn(json));
		}],
		["get", `${cssJsPos}json/contentSort/${TYPE}/rand.json`, null, function(json) {
			if (json == "") return;
			rand.appendChild(fn(json));
		}]
	], function() {
		var ids = [];
		var elems = document.querySelectorAll(".rankinGList li a");
		for (var i = 0; i < elems.length; i++) {
			var id = elems[i].innerHTML;
			if (id && !isNaN(Number(id)))
				ids[id] = true;
		}
		ids = Object.keys(ids);
		ajax("get", 
		`${cssJsPos}opaData/getPageBar.php?table=${TYPE}&query=id,name,time&orderBy=null&whereIdOr=${JSON.stringify(ids)}&bar=false`,
		null, function(json) {
			if (json == "") return;
			var arr = JSON.parse(json);
			arr = arr["rows"];
			var tmp = [];
			for (var i = 0; i < arr.length; i++)
				tmp[arr[i][0]] = [arr[i][1], arr[i][2]];
			arr = tmp;
			for (var i = 0; i < elems.length; i++) {
				var id = elems[i].innerHTML;
				if (isNaN(id)) continue;
				if (!arr[id]) {
					var parent = elems[i].parentElement.parentElement;
					var elem = elems[i].parentElement;
					parent.removeChild(elem);
					continue;
				}
				var title = decodeURIComponent(arr[id][0]);
				var rankinGList = elems[i].parentElement.parentElement;
				if (rankinGList.hasAttribute("showScore")) {
					var score = elems[i].parentElement.getAttribute("score");
					elems[i].innerHTML = `${title}`;
					elems[i].parentElement.innerHTML += `<span>${score}</span>`;
					continue;
				}
				var date = toShowDate(arr[id][1], "m-d");
				elems[i].innerHTML = `${title}`;
				elems[i].parentElement.innerHTML += `<span>${date}</span>`;
			}
		});
	});
	
	function fn(json) {
		var arr = JSON.parse(decodeURIComponent(json));
		var frag = document.createDocumentFragment();
		for (var i = 0; i < arr.length; i++) {
			if (arr[i] instanceof Array) {
				var id = arr[i][0];
				var score = arr[i][1];
			} else {
				var id = arr[i];
				var score = 0;
			}
			var li = document.createElement("li");
			li.setAttribute("score", score);
			var a = document.createElement("a");
			a.setAttribute("target", "_blank");
			a.setAttribute("href", `${webRoot}${DIR}/${id}.html`);
			a.innerHTML = id;
			li.appendChild(a);
			frag.appendChild(li);
		}
		return frag;
	}
})();

//获取分页条函数
function getPageBar(table, pageNo, show, where) {
	if (pageNo)
		pageNo = "&pageNo=" + pageNo;
	else pageNo = "&pageNo=1";
	if (where)
		where = "&where=" + where;
	else where = "";
	var query = "query=id";
	if (show)
		query = "query=title,content,nickname,time,area,pId,credit,timely,service,code_rich";
	ajax("get", `${cssJsPos}opaData/getPageBar.php?${query}&table=${table}${where}&pageNum=50${pageNo}&allNum&allPage`, null, function(data) {
		if (data == "") return;
		data = JSON.parse(data);
		
		var dataTotal = document.querySelector("#com .pageNav .dataTotal");
		dataTotal.innerHTML = data["allNum"];
		var pageTotal = document.querySelector("#com .pageNav .pageTotal");
		pageTotal.innerHTML = data["allPage"];
		
		if (show) {
			var com = document.querySelector("#com");
			var pageNav = com.querySelector(".pageNav");
			var options = com.querySelectorAll(".option");
			for (var i = 0; i < options.length; i++)
				com.removeChild(options[i]);
			var rows = data["rows"];
			var frag = document.createDocumentFragment();
			for (var i = 0; i < rows.length; i++) {
				var row = rows[i];
				var object = decodeURIComponent(row[0]);
				var des = decodeURIComponent(row[1]);
				var user = decodeURIComponent(row[2]);
				var time = decodeURIComponent(row[3]);
				var area = decodeURIComponent(row[4]);
				var pId = decodeURIComponent(row[5]);
				var credit = decodeURIComponent(row[6]);
				var timely = decodeURIComponent(row[7]);
				var service = decodeURIComponent(row[8]);
				var codeRich = decodeURIComponent(row[9]);
				var option = document.createElement("div");
				option.className = "option";
				option.setAttribute("pId", pId);
				option.innerHTML = 
				`<div class=\"object\"><a target=\"_blank\" href=\"${webRoot}${DIR}/${pId}.html\">${object}</a></div>
					<div class=\"des\" title="${des}">${des}</div>
					<div class=\"user\">${user}</div>
					<div class=\"time\">${toShowDate(time, "y-m-d")}</div>
					<div class=\"area\">${area}</div>
					<div class=\"score\">
						<div class=\"timely\">${timely}</div>
						<div class=\"credit\">${credit}</div>
						<div class=\"codeRich\">${codeRich}</div>
						<div class=\"service\">${service}</div>
					</div>`;
				frag.appendChild(option);
			}
			com.insertBefore(frag, pageNav);
		}
		
		var pageBar = document.querySelector("#com .pageNav .pageBar");
		var pageGo = document.querySelector("#com .pageGo");
		var pageBack = document.querySelector("#com .pageBack");
		if (!data["page"]) {
			addClass(pageBar, "hidden");
			addClass(pageGo, "hidden");
			addClass(pageBack, "hidden");
			return;
		}
		
		delClass(pageBar, "hidden");
		delClass(pageGo, "hidden");
		delClass(pageBack, "hidden");
		
		pageBar.innerHTML = data["page"];
		
		var lis = pageBar.children;
		for (var i = 0; i < lis.length; i++) {
			var width = getComputedStyle(lis[i]).width;
			width = parseInt(width);
			if (width > 20)
				lis[i].style.padding = "2px 8px";
		}
		
		var active = pageBar.querySelector("li.active");
		var num = active.getAttribute("pageNo") - 1;
		if (num <= 0) num = 1
		pageGo.setAttribute("pageNo", num);
		var num = Number(active.getAttribute("pageNo")) + 1;
		var num2 = pageBar.lastChild.getAttribute("pageNo");
		if (Number(num) > Number(num2))
			num = num2;
		pageBack.setAttribute("pageNo", num);
		
		setUlEvent(table, pageGo, pageBar, pageBack, where);
	});
}

//为pageBar导航条设置事件
function setUlEvent(table, go, ul, back, where) {
	var children = ul.children;
	for (var i = 0; i < children.length; i++) {
		if (hasClass(children[i], "select")) {
			children[i].onclick = function() {
				var page = prompt("输入跳转的页数");
				page = Number(page);
				if (page <= 0) page = 1;
				else {
					var num = Number(ul.lastChild.getAttribute("pageNo"));
					if (page > num) page = num;
				}
				getPageBar(table, page, true, where);
			}
			continue;
		}
		children[i].onclick = fn;
	}
	go.onclick = fn;
	back.onclick = fn;
	
	function fn() {
		getPageBar(table, this.getAttribute("pageNo"), true, where);
	}
}

//获取分页条
var getArr = GET();
if (getArr.hasOwnProperty("pId")) {
	getPageBar(TYPE+"_com", 1, true, "pId=" + getArr["pId"]);
} else getPageBar(TYPE+"_com", 1, false);




























