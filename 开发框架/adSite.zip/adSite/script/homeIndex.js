
//为左侧边栏添加气泡
function addBubble(arr) {
	/*
		arr["elem"] 当前要添加气泡的元素
		arr["parent"] 要添加气泡的元素的父元素
		arr["num"] 要添加的数字
		arr["others"] 其他有气泡的元素
	*/
	var task = arr["elem"].getAttribute("task");
	if (!task) task = 0;
	var num = Number(task)+Number(arr["num"]);
	if (num == 0)
		arr["elem"].removeAttribute("task");
	else arr["elem"].setAttribute("task", num);
	var num = 0;
	for (var i = 0; i < arr["others"].length; i++) {
		var task = arr["others"][i].getAttribute("task");
		if (!task) task = 0;
		num += Number(task);
	}
	task = arr["elem"].getAttribute("task");
	if (!task) task = 0;
	num += Number(task);
	if (num == 0)
		arr["parent"].removeAttribute("task");
	else arr["parent"].setAttribute("task", num);
}
//为左侧边栏删除气泡
function delBubble(arr) {
	/*
		arr["elem"] 当前要添加气泡的元素
		arr["parent"] 要添加气泡的元素的父元素
		arr["num"] 要添加的数字
		arr["others"] 其他有气泡的元素
	*/
	var task = arr["elem"].getAttribute("task");
	if (!task) task = 0;
	var res = Number(task) - Number(arr["num"]);
	if (res <= 0)
		arr["elem"].removeAttribute("task");
	else arr["elem"].setAttribute("task", res);
	var num = 0;
	for (var i = 0; i < arr["others"].length; i++) {
		var task = arr["others"][i].getAttribute("task");
		if (!task) task = 0;
		num += Number(task);
	}
	task = arr["elem"].getAttribute("task");
	if (!task) task = 0;
	num += Number(task);
	if (num == 0)
		arr["parent"].removeAttribute("task");
	else arr["parent"].setAttribute("task", num);
}

//获取生成HTML的所有任务（气泡）
function setCreateHtmlBubbles() {
	ajax("get", "../opaData/getCreateHtmlBubbles.php", null, function(json) {
		if (json == "") return;
		var data = JSON.parse(json);
		if (data.ad >= 0) {
			var elem = document.querySelector("#left .createAdHtml");
			var parent = document.querySelector("#left .ad");
			var adCom = document.querySelector("#left .reviewAdCom");
			var reviewAd = document.querySelector("#left .reviewAd");
			elem.removeAttribute("task");
			addBubble({
				"elem":elem,
				"parent":parent,
				"num":data.ad,
				"others":[
					adCom,
					reviewAd
				]
			});
		}
		if (data.seo >= 0) {
			var elem = document.querySelector("#left .createSeoHtml");
			var parent = document.querySelector("#left .seo");
			var seoCom = document.querySelector("#left .reviewSeoCom");
			var reviewSeo = document.querySelector("#left .reviewSeo");
			elem.removeAttribute("task");
			addBubble({
				"elem":elem,
				"parent":parent,
				"num":data.seo,
				"others":[
					seoCom,
					reviewSeo
				]
			});
		}
		if (data.app >= 0) {
			var elem = document.querySelector("#left .createAppHtml");
			var parent = document.querySelector("#left .app");
			var appCom = document.querySelector("#left .reviewAppCom");
			var reviewApp = document.querySelector("#left .reviewApp");
			elem.removeAttribute("task");
			addBubble({
				"elem":elem,
				"parent":parent,
				"num":data.app,
				"others":[
					appCom,
					reviewApp
				]
			});
		}
		if (data.vps >= 0) {
			var elem = document.querySelector("#left .createVpsHtml");
			var parent = document.querySelector("#left .vps");
			var vpsCom = document.querySelector("#left .reviewVpsCom");
			var reviewVps = document.querySelector("#left .reviewVps");
			elem.removeAttribute("task");
			addBubble({
				"elem":elem,
				"parent":parent,
				"num":data.vps,
				"others":[
					vpsCom,
					reviewVps
				]
			});
		}
	});
}
setCreateHtmlBubbles();

//获取所有审核任务（气泡）
function setReviewBubbles() {
	ajax("get", "../opaData/getReviewBubbles.php",
	null, function(json) {
		if (json == "") return;
		var data = JSON.parse(json);
		if (data.ad >= 0) {
			var parent = document.querySelector("#left .ad");
			var adHtml = document.querySelector("#left .createAdHtml");
			var adCom = document.querySelector("#left .reviewAdCom");
			var elem = document.querySelector("#left .reviewAd");
			elem.removeAttribute("task");
			addBubble({
				"elem":elem,
				"parent":parent,
				"num":data.ad,
				"others":[
					adHtml,
					adCom
				]
			});
		}
		if (data.seo >= 0) {
			var parent = document.querySelector("#left .seo");
			var seoHtml = document.querySelector("#left .createSeoHtml");
			var seoCom = document.querySelector("#left .reviewSeoCom");
			var elem = document.querySelector("#left .reviewSeo");
			elem.removeAttribute("task");
			addBubble({
				"elem":elem,
				"parent":parent,
				"num":data.seo,
				"others":[
					seoHtml,
					seoCom
				]
			});
		}
		if (data.app >= 0) {
			var parent = document.querySelector("#left .app");
			var appHtml = document.querySelector("#left .createAppHtml");
			var appCom = document.querySelector("#left .reviewAppCom");
			var elem = document.querySelector("#left .reviewApp");
			elem.removeAttribute("task");
			addBubble({
				"elem":elem,
				"parent":parent,
				"num":data.app,
				"others":[
					appHtml,
					appCom
				]
			});
		}
		if (data.vps >= 0) {
			var parent = document.querySelector("#left .vps");
			var vpsHtml = document.querySelector("#left .createVpsHtml");
			var vpsCom = document.querySelector("#left .reviewVpsCom");
			var elem = document.querySelector("#left .reviewVps");
			elem.removeAttribute("task");
			addBubble({
				"elem":elem,
				"parent":parent,
				"num":data.vps,
				"others":[
					vpsHtml,
					vpsCom
				]
			});
		}
	});
}
setReviewBubbles();

//获取所有评论的审核任务（气泡）
function setReviewComBubbles() {
	ajax("get", "../opaData/getReviewComBubbles.php",
	null, function(json) {
		if (json == "") return;
		var data = JSON.parse(json);
		if (data.ad >= 0) {
			var parent = document.querySelector("#left .ad");
			var adHtml = document.querySelector("#left .createAdHtml");
			var elem = document.querySelector("#left .reviewAdCom");
			var reviewAd = document.querySelector("#left .reviewAd");
			elem.removeAttribute("task");
			addBubble({
				"elem":elem,
				"parent":parent,
				"num":data.ad,
				"others":[
					adHtml,
					reviewAd
				]
			});
		}
		if (data.seo >= 0) {
			var parent = document.querySelector("#left .seo");
			var seoHtml = document.querySelector("#left .createSeoHtml");
			var elem = document.querySelector("#left .reviewSeoCom");
			var reviewSeo = document.querySelector("#left .reviewSeo");
			elem.removeAttribute("task");
			addBubble({
				"elem":elem,
				"parent":parent,
				"num":data.seo,
				"others":[
					seoHtml,
					reviewSeo
				]
			});
		}
		if (data.app >= 0) {
			var parent = document.querySelector("#left .app");
			var appHtml = document.querySelector("#left .createAppHtml");
			var elem = document.querySelector("#left .reviewAppCom");
			var reviewApp = document.querySelector("#left .reviewApp");
			elem.removeAttribute("task");
			addBubble({
				"elem":elem,
				"parent":parent,
				"num":data.app,
				"others":[
					appHtml,
					reviewApp
				]
			});
		}
		if (data.vps >= 0) {
			var parent = document.querySelector("#left .vps");
			var vpsHtml = document.querySelector("#left .createVpsHtml");
			var elem = document.querySelector("#left .reviewVpsCom");
			var reviewVps = document.querySelector("#left .reviewVps");
			elem.removeAttribute("task");
			addBubble({
				"elem":elem,
				"parent":parent,
				"num":data.vps,
				"others":[
					vpsHtml,
					reviewVps
				]
			});
		}
	});
}
setReviewComBubbles();

(function() {
	var right = document.querySelector("#right");
	var lis = document.querySelectorAll("#left li");

	//鼠标放上和移开，点击的特效
	for (var i = 0; i < lis.length; i++) {
		lis[i].addEventListener("mouseover", function() {
			var active = document.querySelector(".active");
			replaceClass(active, "active", "del_active");
		});
		lis[i].addEventListener("mouseout", function() {
			var active = document.querySelector(".del_active");
			replaceClass(active, "del_active", "active");
		});
		lis[i].addEventListener("click", function() {
			if (hasClass(this, "index")) return;
			delClass(lis, "del_active");
			addClass(this, "active");
		});
		
		//父子菜单
		if (!hasClass(lis[i], "parent") && !hasClass(lis[i], "child"))
			continue;
		if (hasClass(lis[i], "child"))
			addClass(lis[i], "hidden");
		if (hasClass(lis[i], "parent")) {
			addClass(lis[i], "hidden");
			lis[i].addEventListener("click", function() {
				var state = "hidden";
				if (hasClass(this, "hidden")) {
					replaceClass(this, "hidden", "show");
					state = "show";
				} else if (hasClass(this, "show")) {
					replaceClass(this, "show", "hidden");
					state = "hidden";
				} else addClass(this, state);
				var dom = this.nextElementSibling;
				while (dom && hasClass(dom, "child")) {
					if (state == "hidden") {
						if (hasClass(dom, "show"))
							replaceClass(dom, "show", "hidden");
						else addClass(dom, "hidden");
					}
					if (state == "show") {
						if (hasClass(dom, "hidden"))
							replaceClass(dom, "hidden", "show");
						else addClass(dom, "show");
					}
					dom = dom.nextElementSibling;
				}
			});
		}
	}
	
	//返回主页
	var index = document.querySelector("#left .index");
	index.addEventListener("click", function() {
		window.open("../", "_blank");
	});
	
	//多开后台
	var home = document.querySelector("#left .home");
	home.addEventListener("click", function() {
		window.open("../home", "_blank");
	});
	
	//修改数据库信息
	var modifyDB = document.querySelector("#left .modifyDB");
	modifyDB.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		ajax("get", "funs/modifyDB.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			document.title = "修改数据库信息";
			
			var form = document.querySelector("script[src*='homeForm.js']");
			if (form) reloadJS(form);
			else addJS("../script/homeForm.js");
			
			var modifyDBJS = document.querySelector("script[src*='homeModifyDB.js']");
			if (modifyDBJS) reloadJS(modifyDBJS);
			else addJS("../script/homeModifyDB.js");
		});
	});
	
	//后台主页直接跳转修改数据库信息
	modifyDB.click();
	
	//管理IP黑名单
	var ipBlackList = document.querySelector("#left .ipBlackList");
	ipBlackList.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "管理IP黑名单";
		ajax("get", "funs/ipBlackList.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var ipBlackListJS = document.querySelector("script[src*='homeIpBlackList.js']");
			if (ipBlackListJS) reloadJS(ipBlackListJS);
			else addJS("../script/homeIpBlackList.js");
		});
	});
	
	//修改网站配置
	var webconfig = document.querySelector("#left .webconfig");
	webconfig.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		ajax("get", "funs/webconfig.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			document.title = "修改网站配置";
			
			var form = document.querySelector("script[src*='homeForm.js']");
			if (form) reloadJS(form);
			else addJS("../script/homeForm.js");
			
			var webconfigJS = document.querySelector("script[src*='homeWebconfig.js']");
			if (webconfigJS) reloadJS(webconfigJS);
			else addJS("../script/homeWebconfig.js");
		});
	});
	
	//数据库备份和还原
	var backup = document.querySelector("#left .backup");
	backup.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "数据库备份和还原";
		ajax("get", "funs/backup.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var backupJS = document.querySelector("script[src*='homeBackup.js']");
			if (backupJS) reloadJS(backupJS);
			else addJS("../script/homeBackup.js");
		});
	});
	
	//全站图文广告
	var siteImgAd = document.querySelector("#left .siteImgAd");
	siteImgAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "设置全站广告";
		ajax("get", "funs/siteImgAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var siteImgAdJS = document.querySelector("script[src*='homeSiteImgAd.js']");
			if (siteImgAdJS) reloadJS(siteImgAdJS);
			else addJS("../script/homeSiteImgAd.js");
		});
	});
	
	//广告联盟
	//审核联盟
	var reviewAd = document.querySelector("#left .reviewAd");
	reviewAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "审核广告联盟";
		ajax("get", "funs/reviewAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var reviewAdJS = document.querySelector("script[src*='homeReviewAd.js']");
			if (reviewAdJS) reloadJS(reviewAdJS);
			else addJS("../script/homeReviewAd.js");
		});
	});
	//审核广告联盟评论
	var reviewAdCom = document.querySelector("#left .reviewAdCom");
	reviewAdCom.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "审核广告联盟评论";
		ajax("get", "funs/reviewAdCom.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var reviewAdComJS = document.querySelector("script[src*='homeReviewAdCom.js']");
			if (reviewAdComJS) reloadJS(reviewAdComJS);
			else addJS("../script/homeReviewAdCom.js");
		});
	});
	//生成广告联盟HTML
	var createAdHtml = document.querySelector("#left .createAdHtml");
	createAdHtml.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "生成广告联盟HTML";
		ajax("get", "funs/createHtml.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var adCreateHtmlJS = document.querySelector("script[src*='homeCreateAdHtml.js']");
			if (adCreateHtmlJS) reloadJS(adCreateHtmlJS);
			else addJS("../script/homeCreateAdHtml.js");
		});
	});
	//增加联盟
	var addAd = document.querySelector("#left .addAd");
	addAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加广告联盟信息";
		ajax("get", "funs/addAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addAdJS = document.querySelector("script[src*='homeAddAd.js']");
			if (addAdJS) reloadJS(addAdJS);
			else addJS("../script/homeAddAd.js");
		});
	});
	//修改联盟
	var modifyAd = document.querySelector("#left .modifyAd");
	modifyAd.addEventListener("click",function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "修改广告联盟信息";
		ajax("get", "funs/modifyAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var modifyAdJS = document.querySelector("script[src*='homeModifyAd.js']");
			if (modifyAdJS) reloadJS(modifyAdJS);
			else addJS("../script/homeModifyAd.js");
		});
	});
	//删除联盟
	var delAd = document.querySelector("#left .delAd");
	delAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "删除广告联盟信息";
		ajax("get", "funs/delAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var delAdJS = document.querySelector("script[src*='homeDelAd.js']");
			if (delAdJS) reloadJS(delAdJS);
			else addJS("../script/homeDelAd.js");
		});
	});
	//增加联盟资讯
	var addAdInfo = document.querySelector("#left .addAdInfo");
	addAdInfo.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加广告联盟资讯";
		ajax("get", "funs/addAdInfo.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addAdInfoJS = document.querySelector("script[src*='homeAddAdInfo.js']");
			if (addAdInfoJS) reloadJS(addAdInfoJS);
			else addJS("../script/homeAddAdInfo.js");
		});
	});
	//修改联盟资讯
	var modifyAdInfo = document.querySelector("#left .modifyAdInfo");
	modifyAdInfo.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "修改广告联盟资讯";
		ajax("get", "funs/modifyAdInfo.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var modifyAdInfoJS = document.querySelector("script[src*='homeModifyAdInfo.js']");
			if (modifyAdInfoJS) reloadJS(modifyAdInfoJS);
			else addJS("../script/homeModifyAdInfo.js");
		});
	});
	//删除联盟资讯
	var delAdInfo = document.querySelector("#left .delAdInfo");
	delAdInfo.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "删除广告联盟资讯";
		ajax("get", "funs/delAdInfo.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var delAdInfoJS = document.querySelector("script[src*='homeDelAdInfo.js']");
			if (delAdInfoJS) reloadJS(delAdInfoJS);
			else addJS("../script/homeDelAdInfo.js");
		});
	});
	//添加广告联盟文字广告位
	var addAdTextAd = document.querySelector("#left .addAdTextAd");
	addAdTextAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加广告联盟文字广告位";
		ajax("get", "funs/addAdTextAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addAdTextAdJS = document.querySelector("script[src*='homeAddTextAd.js']");
			if (addAdTextAdJS) reloadJS(addAdTextAdJS);
			else addJS("../script/homeAddTextAd.js");
		});
	});
	//增加广告联盟图文广告位
	var addAdImgAd = document.querySelector("#left .addAdImgAd");
	addAdImgAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加广告联盟图文广告位";
		ajax("get", "funs/addAdImgAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addAdImgAdJS = document.querySelector("script[src*='homeAddImgAd.js']");
			if (addAdImgAdJS) reloadJS(addAdImgAdJS);
			else addJS("../script/homeAddImgAd.js");
		});
	});
	//增加广告联盟内页3个广告位
	var addAdContentImgAd = document.querySelector("#left .addAdContentImgAd");
	addAdContentImgAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加广告联盟内页3个图文广告位";
		ajax("get", "funs/addAdContentImgAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addImgAdJS = document.querySelector("script[src*='homeAddImgAd.js']");
			if (addImgAdJS) reloadJS(addImgAdJS);
			else addJS("../script/homeAddImgAd.js");
		});
	});	
	//删除广告联盟广告位
	var delAdAd = document.querySelector("#left .delAdAd");
	delAdAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "删除广告联盟广告位";
		ajax("get", "funs/delAdAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var delAdAdJS = document.querySelector("script[src*='homeDelAllAds.js']");
			if (delAdAdJS) reloadJS(delAdAdJS);
			else addJS("../script/homeDelAllAds.js");
		});
	});
	
	//SEO
	//审核seo
	var reviewSeo = document.querySelector("#left .reviewSeo");
	reviewSeo.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "审核seo服务";
		ajax("get", "funs/reviewSeo.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var reviewSeoJS = document.querySelector("script[src*='homeReviewSeo.js']");
			if (reviewSeoJS) reloadJS(reviewSeoJS);
			else addJS("../script/homeReviewSeo.js");
		});
	});
	//审核广告联盟评论
	var reviewSeoCom = document.querySelector("#left .reviewSeoCom");
	reviewSeoCom.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "审核seo评论";
		ajax("get", "funs/reviewSeoCom.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var reviewSeoComJS = document.querySelector("script[src*='homeReviewSeoCom.js']");
			if (reviewSeoComJS) reloadJS(reviewSeoComJS);
			else addJS("../script/homeReviewSeoCom.js");
		});
	});
	//生成seo HTML
	var createSeoHtml = document.querySelector("#left .createSeoHtml");
	createSeoHtml.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "生成seo HTML";
		ajax("get", "funs/createHtml.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
		
			var seoCreateHtmlJS = document.querySelector("script[src*='homeCreateSeoHtml.js']");
			if (seoCreateHtmlJS) reloadJS(seoCreateHtmlJS);
			else addJS("../script/homeCreateSeoHtml.js");
		});
	});
	//增加服务
	var addSeo = document.querySelector("#left .addSeo");
	addSeo.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加seo服务信息";
		ajax("get", "funs/addSeo.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addSeoJS = document.querySelector("script[src*='homeAddSeo.js']");
			if (addSeoJS) reloadJS(addSeoJS);
			else addJS("../script/homeAddSeo.js");
		});
	});
	//修改服务
	var modifySeo = document.querySelector("#left .modifySeo");
	modifySeo.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "修改seo服务信息";
		ajax("get", "funs/modifySeo.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
	
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var modifySeoJS = document.querySelector("script[src*='homeModifySeo.js']");
			if (modifySeoJS) reloadJS(modifySeoJS);
			else addJS("../script/homeModifySeo.js");
		});
	});
	//删除服务
	var delSeo = document.querySelector("#left .delSeo");
	delSeo.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "删除seo服务信息";
		ajax("get", "funs/delSeo.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var delSeoJS = document.querySelector("script[src*='homeDelSeo.js']");
			if (delSeoJS) reloadJS(delSeoJS);
			else addJS("../script/homeDelSeo.js");
		});
	});
	//增加seo资讯
	var addSeoInfo = document.querySelector("#left .addSeoInfo");
	addSeoInfo.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加seo资讯";
		ajax("get", "funs/addSeoInfo.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addSeoInfoJS = document.querySelector("script[src*='homeAddSeoInfo.js']");
			if (addSeoInfoJS) reloadJS(addSeoInfoJS);
			else addJS("../script/homeAddSeoInfo.js");
		});
	});
	//修改seo资讯
	var modifySeoInfo = document.querySelector("#left .modifySeoInfo");
	modifySeoInfo.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "修改seo资讯";
		ajax("get", "funs/modifySeoInfo.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var modifySeoInfoJS = document.querySelector("script[src*='homeModifySeoInfo.js']");
			if (modifySeoInfoJS) reloadJS(modifySeoInfoJS);
			else addJS("../script/homeModifySeoInfo.js");
		});
	});
	//删除seo资讯
	var delSeoInfo = document.querySelector("#left .delSeoInfo");
	delSeoInfo.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "删除seo资讯";
		ajax("get", "funs/delSeoInfo.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var delSeoInfoJS = document.querySelector("script[src*='homeDelSeoInfo.js']");
			if (delSeoInfoJS) reloadJS(delSeoInfoJS);
			else addJS("../script/homeDelSeoInfo.js");
		});
	});
	//添加seo服务文字广告位
	var addSeoTextAd = document.querySelector("#left .addSeoTextAd");
	addSeoTextAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加seo文字广告位";
		ajax("get", "funs/addSeoTextAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addSeoTextAdJS = document.querySelector("script[src*='homeAddTextAd.js']");
			if (addSeoTextAdJS) reloadJS(addSeoTextAdJS);
			else addJS("../script/homeAddTextAd.js");
		});
	});
	//添加seo服务图文广告位
	var addSeoImgAd = document.querySelector("#left .addSeoImgAd");
	addSeoImgAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加seo图文广告位";
		ajax("get", "funs/addSeoImgAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addSeoImgAdJS = document.querySelector("script[src*='homeAddImgAd.js']");
			if (addSeoImgAdJS) reloadJS(addSeoImgAdJS);
			else addJS("../script/homeAddImgAd.js");
		});
	});	
	//增加seo内页3个广告位
	var addSeoContentImgAd = document.querySelector("#left .addSeoContentImgAd");
	addSeoContentImgAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加seo内页3个图文广告位";
		ajax("get", "funs/addSeoContentImgAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addImgAdJS = document.querySelector("script[src*='homeAddImgAd.js']");
			if (addImgAdJS) reloadJS(addImgAdJS);
			else addJS("../script/homeAddImgAd.js");
		});
	});	
	//删除seo服务广告位
	var delSeoAd = document.querySelector("#left .delSeoAd");
	delSeoAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "删除seo广告位";
		ajax("get", "funs/delSeoAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var delSeoAdJS = document.querySelector("script[src*='homeDelAllAds.js']");
			if (delSeoAdJS) reloadJS(delSeoAdJS);
			else addJS("../script/homeDelAllAds.js");
		});
	});
	
	//APP推广
	//审核APP
	var reviewApp = document.querySelector("#left .reviewApp");
	reviewApp.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "审核APP服务";
		ajax("get", "funs/reviewApp.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var reviewAppJS = document.querySelector("script[src*='homeReviewApp.js']");
			if (reviewAppJS) reloadJS(reviewAppJS);
			else addJS("../script/homeReviewApp.js");
		});
	});
	//审核广告联盟评论
	var reviewAppCom = document.querySelector("#left .reviewAppCom");
	reviewAppCom.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "审核APP评论";
		ajax("get", "funs/reviewAppCom.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var reviewAppComJS = document.querySelector("script[src*='homeReviewAppCom.js']");
			if (reviewAppComJS) reloadJS(reviewAppComJS);
			else addJS("../script/homeReviewAppCom.js");
		});
	});
	//生成app HTML
	var createAppHtml = document.querySelector("#left .createAppHtml");
	createAppHtml.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "生成APP HTML";
		ajax("get", "funs/createHtml.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
		
			var appCreateHtmlJS = document.querySelector("script[src*='homeCreateAppHtml.js']");
			if (appCreateHtmlJS) reloadJS(appCreateHtmlJS);
			else addJS("../script/homeCreateAppHtml.js");
		});
	});
	//增加APP
	var addApp = document.querySelector("#left .addApp");
	addApp.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加APP信息";
		ajax("get", "funs/addApp.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addAppJS = document.querySelector("script[src*='homeAddApp.js']");
			if (addAppJS) reloadJS(addAppJS);
			else addJS("../script/homeAddApp.js");
		});
	});
	//修改APP
	var modifyApp = document.querySelector("#left .modifyApp");
	modifyApp.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "修改APP信息";
		ajax("get", "funs/modifyApp.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var modifyAppJS = document.querySelector("script[src*='homeModifyApp.js']");
			if (modifyAppJS) reloadJS(modifyAppJS);
			else addJS("../script/homeModifyApp.js");
		});
	});
	//删除APP
	var delApp = document.querySelector("#left .delApp");
	delApp.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "删除APP信息";
		ajax("get", "funs/delApp.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var delAppJS = document.querySelector("script[src*='homeDelApp.js']");
			if (delAppJS) reloadJS(delAppJS);
			else addJS("../script/homeDelApp.js");
		});
	});
	//添加APP资讯
	var addAppInfo = document.querySelector("#left .addAppInfo");
	addAppInfo.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加APP资讯";
		ajax("get", "funs/addAppInfo.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addAppInfoJS = document.querySelector("script[src*='homeAddAppInfo.js']");
			if (addAppInfoJS) reloadJS(addAppInfoJS);
			else addJS("../script/homeAddAppInfo.js");
			
		});
	});
	//修改APP资讯
	var modifyAppInfo = document.querySelector("#left .modifyAppInfo");
	modifyAppInfo.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "修改APP资讯";
		ajax("get", "funs/modifyAppInfo.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var modifyAppInfoJS = document.querySelector("script[src*='homeModifyAppInfo.js']");
			if (modifyAppInfoJS) reloadJS(modifyAppInfoJS);
			else addJS("../script/homeModifyAppInfo.js");
			
		});
	});
	//删除APP资讯
	var delAppInfo = document.querySelector("#left .delAppInfo");
	delAppInfo.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "删除APP资讯";
		ajax("get", "funs/delAppInfo.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var delAppInfoJS = document.querySelector("script[src*='homeDelAppInfo.js']");
			if (delAppInfoJS) reloadJS(delAppInfoJS);
			else addJS("../script/homeDelAppInfo.js");
			
		});
	});		
	//增加APP文字广告位
	var addAppTextAd = document.querySelector("#left .addAppTextAd");
	addAppTextAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加APP文字广告位";
		ajax("get", "funs/addAppTextAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addAppTextAdJS = document.querySelector("script[src*='homeAddTextAd.js']");
			if (addAppTextAdJS) reloadJS(addAppTextAdJS);
			else addJS("../script/homeAddTextAd.js");
			
		});
	});
	//增加APP图文广告位
	var addAppImgAd = document.querySelector("#left .addAppImgAd");
	addAppImgAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加APP图文广告位";
		ajax("get", "funs/addAppImgAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addAppImgAdJS = document.querySelector("script[src*='homeAddImgAd.js']");
			if (addAppImgAdJS) reloadJS(addAppImgAdJS);
			else addJS("../script/homeAddImgAd.js");
		});
	});
	//增加APP内页3个广告位
	var addAppContentImgAd = document.querySelector("#left .addAppContentImgAd");
	addAppContentImgAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加APP内页3个图文广告位";
		ajax("get", "funs/addAppContentImgAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addImgAdJS = document.querySelector("script[src*='homeAddImgAd.js']");
			if (addImgAdJS) reloadJS(addImgAdJS);
			else addJS("../script/homeAddImgAd.js");
		});
	});	
	//删除APP广告
	var delAppAd = document.querySelector("#left .delAppAd");
	delAppAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "删除APP广告位";
		ajax("get", "funs/delAppAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var delAppAdJS = document.querySelector("script[src*='homeDelAllAds.js']");
			if (delAppAdJS) reloadJS(delAppAdJS);
			else addJS("../script/homeDelAllAds.js");
		});
	});
	
	//VPS
	//审核vps
	var reviewVps = document.querySelector("#left .reviewVps");
	reviewVps.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "审核vps服务";
		ajax("get", "funs/reviewVps.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var reviewVpsJS = document.querySelector("script[src*='homeReviewVps.js']");
			if (reviewVpsJS) reloadJS(reviewVpsJS);
			else addJS("../script/homeReviewVps.js");
		});
	});
	//审核广告联盟评论
	var reviewVpsCom = document.querySelector("#left .reviewVpsCom");
	reviewVpsCom.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "审核vps评论";
		ajax("get", "funs/reviewVpsCom.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var reviewVpsComJS = document.querySelector("script[src*='homeReviewVpsCom.js']");
			if (reviewVpsComJS) reloadJS(reviewVpsComJS);
			else addJS("../script/homeReviewVpsCom.js");
		});
	});
	//生成vps HTML
	var createVpsHtml = document.querySelector("#left .createVpsHtml");
	createVpsHtml.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "生成vps HTML";
		ajax("get", "funs/createHtml.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
		
			var vpsCreateHtmlJS = document.querySelector("script[src*='homeCreateVpsHtml.js']");
			if (vpsCreateHtmlJS) reloadJS(vpsCreateHtmlJS);
			else addJS("../script/homeCreateVpsHtml.js");
		});
	});
	//增加VPS
	var addVps = document.querySelector("#left .addVps");
	addVps.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加VPS信息";
		ajax("get", "funs/addVps.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addVpsJS = document.querySelector("script[src*='homeAddVps.js']");
			if (addVpsJS) reloadJS(addVpsJS);
			else addJS("../script/homeAddVps.js");
		});
	});
	//修改VPS
	var modifyVps = document.querySelector("#left .modifyVps");
	modifyVps.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "修改VPS信息";
		ajax("get", "funs/modifyVps.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var modifyVpsJS = document.querySelector("script[src*='homeModifyVps.js']");
			if (modifyVpsJS) reloadJS(modifyVpsJS);
			else addJS("../script/homeModifyVps.js");
		});
	});	
	//删除VPS
	var delVps = document.querySelector("#left .delVps");
	delVps.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "删除VPS信息";
		ajax("get", "funs/delVps.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var delVpsJS = document.querySelector("script[src*='homeDelVps.js']");
			if (delVpsJS) reloadJS(delVpsJS);
			else addJS("../script/homeDelVps.js");
		});
	});	
	//增加VPS资讯
	var addVpsInfo = document.querySelector("#left .addVpsInfo");
	addVpsInfo.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加VPS资讯";
		ajax("get", "funs/addVpsInfo.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addVpsInfoJS = document.querySelector("script[src*='homeAddVpsInfo.js']");
			if (addVpsInfoJS) reloadJS(addVpsInfoJS);
			else addJS("../script/homeAddVpsInfo.js");
		});
	});
	//修改VPS资讯
	var modifyVpsInfo = document.querySelector("#left .modifyVpsInfo");
	modifyVpsInfo.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "修改VPS资讯";
		ajax("get", "funs/modifyVpsInfo.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var modifyVpsInfoJS = document.querySelector("script[src*='homeModifyVpsInfo.js']");
			if (modifyVpsInfoJS) reloadJS(modifyVpsInfoJS);
			else addJS("../script/homeModifyVpsInfo.js");
		});
	});
	//删除VPS资讯
	var delVpsInfo = document.querySelector("#left .delVpsInfo");
	delVpsInfo.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "删除VPS资讯";
		ajax("get", "funs/delVpsInfo.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var delVpsInfoJS = document.querySelector("script[src*='homeDelVpsInfo.js']");
			if (delVpsInfoJS) reloadJS(delVpsInfoJS);
			else addJS("../script/homeDelVpsInfo.js");
		});
	});
	//增加VPS文字广告位
	var addVpsTextAd = document.querySelector("#left .addVpsTextAd");
	addVpsTextAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加VPS文字广告位";
		ajax("get", "funs/addVpsTextAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addVpsTextAdJS = document.querySelector("script[src*='homeAddTextAd.js']");
			if (addVpsTextAdJS) reloadJS(addVpsTextAdJS);
			else addJS("../script/homeAddTextAd.js");
		});
	});
	//增加VPS图文广告位
	var addVpsImgAd = document.querySelector("#left .addVpsImgAd");
	addVpsImgAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加VPS图文广告位";
		ajax("get", "funs/addVpsImgAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addVpsImgAdJS = document.querySelector("script[src*='homeAddImgAd.js']");
			if (addVpsImgAdJS) reloadJS(addVpsImgAdJS);
			else addJS("../script/homeAddImgAd.js");
		});
	});
	//增加VPS内页3个广告位
	var addVpsContentImgAd = document.querySelector("#left .addVpsContentImgAd");
	addVpsContentImgAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "增加VPS内页3个图文广告位";
		ajax("get", "funs/addVpsContentImgAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var addImgAdJS = document.querySelector("script[src*='homeAddImgAd.js']");
			if (addImgAdJS) reloadJS(addImgAdJS);
			else addJS("../script/homeAddImgAd.js");
		});
	});	
	//删除VPS广告
	var delVpsAd = document.querySelector("#left .delVpsAd");
	delVpsAd.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "删除VPS广告位";
		ajax("get", "funs/delVpsAd.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var formJS = document.querySelector("script[src*='homeForm.js']");
			if (formJS) reloadJS(formJS);
			else addJS("../script/homeForm.js");
			
			var delVpsAdJS = document.querySelector("script[src*='homeDelAllAds.js']");
			if (delVpsAdJS) reloadJS(delVpsAdJS);
			else addJS("../script/homeDelAllAds.js");
		});
	});

	//管理用户
	var opaUsers = document.querySelector("#left .opaUsers");	
	opaUsers.addEventListener("click", function() {
		right.innerHTML = "<img src='../images/loading.gif' />";
		document.title = "管理用户";
		ajax("get", "funs/opaUsers.html", null, function(data) {
			if (data == "") return;
			right.innerHTML = data;
			
			var opaUsersJS = document.querySelector("script[src*='homeOpaUsers.js']");
			if (opaUsersJS) reloadJS(opaUsersJS);
			else addJS("../script/homeOpaUsers.js");
		});
	});
	
	//恢复出厂设置
	var rollBack = document.querySelector("#left .rollBack");	
	rollBack.addEventListener("click", function() {
		document.title = "恢复出厂设置";
		
		ajax("get", "../opaData/rollBack.php", null, function() {
			alert("恢复成功！");
		});
	});

	//退出管理员登录
	var exit = document.querySelector("#left .exit");	
	exit.addEventListener("click", function() {
		location.href = "../users/exit.php";
	});
	
})();





































