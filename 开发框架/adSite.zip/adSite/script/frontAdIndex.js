
//高级搜索隐藏和显示功能按钮
(function() {
	var btn = document.querySelector("#input span");
	var query = document.querySelector("#query");
	if (!hasClass(query, "hidden"))
		addClass(query, "hidden");
	btn.onclick = function() {
		if (hasClass(query, "hidden"))
			replaceClass(query, "hidden", "show");
		else if (hasClass(query, "show"))
			replaceClass(query, "show", "hidden");
	}
})();

//右侧列表的序号
(function() {
	var latelyList = lately.querySelectorAll("li");
	for (var i = 0; i < latelyList.length; i++) {
		latelyList[i].setAttribute("data-list", i+1);
	}
	var timelyList = timely.querySelectorAll("li");
	for (var i = 0; i < timelyList.length; i++) {
		timelyList[i].setAttribute("data-list", i+1);
	}
	var creditList = credit.querySelectorAll("li");
	for (var i = 0; i < creditList.length; i++) {
		creditList[i].setAttribute("data-list", i+1);
	}
	var serviceList = service.querySelectorAll("li");
	for (var i = 0; i < serviceList.length; i++) {
		serviceList[i].setAttribute("data-list", i+1);
	}
	var codeRichList = codeRich.querySelectorAll("li");
	for (var i = 0; i < codeRichList.length; i++) {
		codeRichList[i].setAttribute("data-list", i+1);
	}
	var popularityList = popularity.querySelectorAll("li");
	for (var i = 0; i < popularityList.length; i++) {
		popularityList[i].setAttribute("data-list", i+1);
	}
})();

//设置主页搜索结果每个广告联盟的3个值设置到元素中
function setScore(type) {
	var elems = document.querySelectorAll("#result .option");
	for (var i = 0; i < elems.length; i++) {
		elems[i].querySelector(".comNum").onclick = function() {
			var pId = this.parentElement.getAttribute("pId");
			window.open(`${webRoot}com/${type}.html?pId=${pId}`, "_blank");
		}
		var pId = elems[i].getAttribute("pId");
		(function(elem, pId) {
			ajax("get", `${cssJsPos}json/contentScore/${type}/${pId}.json`, null, function(data) {
				if (data == "") return;
				data = decodeURIComponent(data);
				data = JSON.parse(data);
				var credit = data["credit"];
				var timely = data["timely"];
				var service = data["service"];
				var codeRich = data["code_rich"];
				var latestCom = data["latestCom"];
				elem.querySelector(".credit").innerHTML = credit;
				elem.querySelector(".timely").innerHTML = timely;
				elem.querySelector(".service").innerHTML = service;
				elem.querySelector(".service").innerHTML = service;
				elem.querySelector(".codeRich").innerHTML = codeRich;
				elem.querySelector(".latestCom").innerHTML = decodeURIComponent(latestCom);
			});
		})(elems[i], pId);
	}
}

//为每个搜索结果设置评分
setScore(TYPE);

//设置分页条函数
function getPageBar(table, pageNo, show, cmd) {
	if (pageNo)
		pageNo = "&pageNo=" + pageNo;
	else pageNo = "&pageNo=1";
	var tmp1 = `${cssJsPos}opaData/getPageBar.php?`;
	var tmp2 = `&table=${TYPE}&pageNum=50&allNum&allPage`;
	if (!cmd && show)	query = `${tmp1}query=id,name,coms${tmp2}`;
	if (!cmd && !show) query = `${tmp1}query=id&table=${TYPE}${tmp2}`;
	if (cmd) query = cmd;
	query += pageNo;
	ajax("get", query, null, function(data) {
		if (data == "") return;
		
		data = JSON.parse(data);
		var dataTotal = document.querySelector("#result .pageNav .dataTotal");
		dataTotal.innerHTML = data["allNum"];
		var pageTotal = document.querySelector("#result .pageNav .pageTotal");
		pageTotal.innerHTML = data["allPage"];
		
		if (show) {
			var result = document.querySelector("#result");
			var pageNav = result.querySelector(".pageNav");
			var options = result.querySelectorAll(".option");
			for (var i = 0; i < options.length; i++)
				result.removeChild(options[i]);
			var rows = data["rows"];
			var frag = document.createDocumentFragment();
			for (var i = 0; i < rows.length; i++) {
				var row = rows[i];
				var id = decodeURIComponent(row[0]);
				var title = decodeURIComponent(row[1]);
				var coms = decodeURIComponent(row[2]);
				var option = document.createElement("div");
				option.className = "option";
				option.setAttribute("pId", id);
				option.innerHTML = 
				`<div class="name"><a target="_blank" href=\"${webRoot}${DIR}/${id}.html\">${title}</a></div>
				<div class="score">
					<div class="credit">0</div>
					<div class="timely">0</div>
					<div class="service">0</div>
					<div class="codeRich">0</div>
				</div>
				<div class="latestCom"></div>
				<div class="comNum">${coms}</div>
				`;
				frag.appendChild(option);
			}
			result.insertBefore(frag, pageNav);
			
			//为每个搜索结果设置评分
			setScore(TYPE);
		}
		
		var pageBar = document.querySelector("#result .pageNav .pageBar");
		var pageGo = document.querySelector("#result .pageGo");
		var pageBack = document.querySelector("#result .pageBack");
		if (!data["page"]) {
			addClass(pageBar, "hidden");
			addClass(pageGo, "hidden");
			addClass(pageBack, "hidden");
			return;
		}
		
		delClass(pageBar, "hidden");
		delClass(pageGo, "hidden");
		delClass(pageBack, "hidden");
		
		pageBar.innerHTML = data["page"];
		
		var lis = pageBar.children;
		for (var i = 0; i < lis.length; i++) {
			var width = getComputedStyle(lis[i]).width;
			width = parseInt(width);
			if (width > 20)
				lis[i].style.padding = "2px 8px";
		}
		
		var active = pageBar.querySelector("li.active");
		var num = active.getAttribute("pageNo") - 1;
		if (num <= 0) num = 1
		pageGo.setAttribute("pageNo", num);
		var num = Number(active.getAttribute("pageNo")) + 1;
		var num2 = pageBar.lastChild.getAttribute("pageNo");
		if (Number(num) > Number(num2))
			num = num2;
		pageBack.setAttribute("pageNo", num);
		
		setUlEvent(table, pageGo, pageBar, pageBack, cmd);
	});
}

//为pageBar导航条设置事件
function setUlEvent(table, go, ul, back, cmd) {
	var children = ul.children;
	for (var i = 0; i < children.length; i++) {
		if (hasClass(children[i], "select")) {
			children[i].onclick = function() {
				var page = prompt("输入跳转的页数");
				page = Number(page);
				if (page <= 0) page = 1;
				else {
					var num = Number(ul.lastChild.getAttribute("pageNo"));
					if (page > num) page = num;
				}
				getPageBar(table, page, true, cmd);
			}
			continue;
		}
		children[i].onclick = fn;
	}
	go.onclick = fn;
	back.onclick = fn;
	
	function fn() {
		getPageBar(table, this.getAttribute("pageNo"), true, cmd);
	}
}

//获取分页条
getPageBar(TYPE, 1, false);

//高级搜索功能
(function() {
	var btn = document.querySelector("#input button");
	var input = document.querySelector("#input input");
	btn.onclick = searchFn;
	input.onkeydown = function(e) {
		if (e.keyCode == 13)
			searchFn();
	}
	
	function searchFn() {
		var queryElem = document.getElementById("query");
		var input = document.querySelector("#input input");
		if (hasClass(queryElem, "hidden")) {
			getPageBar(TYPE, 1, true, cssJsPos+"opaData/frontAdSearch.php?simple&query="+input.value);
			return;
		}
		var payCycle = document.querySelector("#query .payCycle");
		payCycle = payCycle.value;
		var startPay = document.querySelector("#query .startPay");
		startPay = startPay.value;
		var type = document.querySelectorAll("#query .type");
		var typeBox = [];
		for (var i = 0; i < type.length; i++)
			if (type[i].checked)
				typeBox.push(type[i].value);
		var display = document.querySelector("#query .display");
		display = display.value;
		var sort = document.querySelector("#query .sort");
		sort = sort.value;
		var sortRule = document.querySelector("#query .sortRule");
		sortRule = sortRule.value;
		
		var searchElem = document.querySelector("#search");
		var query = `?payCycle=${payCycle}&startPay=${startPay}&type=${JSON.stringify(typeBox)}&display=${display}&sort=${sort}&sortRule=${sortRule}`;
		query += "&query="+input.value;
		
		getPageBar(TYPE, 1, true, cssJsPos+"opaData/frontAdSearch.php"+query);
		
	}
})();

//最近收录
//结账及时性
//信誉度排行
//客户服务质量
//代码丰富度
//人气（访问次数）排行
(function() {
	var lately = document.querySelector("#lately .rankinGList");
	var timely = document.querySelector("#timely .rankinGList");
	var credit = document.querySelector("#credit .rankinGList");
	var service = document.querySelector("#service .rankinGList");
	var codeRich = document.querySelector("#codeRich .rankinGList");
	var popularity = document.querySelector("#popularity .rankinGList");
	queueAjax([
		["get",
		`${cssJsPos}json/contentLatest/${TYPE}.json`,
		null, function(json) {
			if (json == "") return;
			arr = JSON.parse(decodeURIComponent(json));
			var inner = "";
			for (var i = 0; i < arr.length; i++) {
				var id = arr[i][0];
				var title = arr[i][1];
				var time = arr[i][2];
				inner += `<li data-list="${i+1}"><a target="_blank" href="${webRoot}${DIR}/${id}.html">${decodeURIComponent(title)}</a><span>${toShowDate(time,"m-d")}</span></li>`;
			}
			lately.innerHTML = inner;
		}],
		["get",
		`${cssJsPos}json/contentSort/${TYPE}/timely.json`,
		null, function(data) {
			if (data == "") return;
			fn(data, timely);
		}],
		["get",
		`${cssJsPos}json/contentSort/${TYPE}/credit.json`,
		null, function(data) {
			if (data == "") return;
			fn(data, credit);
		}],
		["get",
		`${cssJsPos}json/contentSort/${TYPE}/service.json`,
		null, function(data) {
			if (data == "") return;
			fn(data, service);
		}],
		["get",
		`${cssJsPos}json/contentSort/${TYPE}/code_rich.json`,
		null, function(data) {
			if (data == "") return;
			fn(data, codeRich);
		}],
		["get",
		`${cssJsPos}json/contentViewsSort/${TYPE}.json`,
		null, function(json) {
			var arr = JSON.parse(json);
			var inner = "";
			for (var i = 0; i < arr.length; i++) {
				var views = arr[i]['views'];
				if (views >= 1000 && views <= 10000)
					views = (views/1000).toFixed(1) + "K";
				if (views > 10000)
					views = (views/10000).toFixed(1) + "W";
				inner += `<li data-list=${i+1}><a target="_blank" href="${webRoot}${DIR}/${arr[i]['id']}.html">${arr[i]['id']}</a><span>${views}</span></div>`;
			}
			popularity.innerHTML = inner;
		}]
	], function() {
		var ids = [];
		var elems = document.querySelectorAll(".rankinGList li a");
		for (var i = 0; i < elems.length; i++) {
			var id = elems[i].innerHTML;
			if (id && !isNaN(Number(id)))
				ids[id] = true;
		}
		ids = Object.keys(ids);
		ajax("get", 
		`${cssJsPos}opaData/getPageBar.php?table=${TYPE}&query=id,name&orderBy=null&whereIdOr=${JSON.stringify(ids)}&bar=false`,
		null, function(json) {
			if (json == "") return;
			var arr = JSON.parse(json);
			arr = arr["rows"];
			var tmp = [];
			for (var i = 0; i < arr.length; i++)
				tmp[arr[i][0]] = arr[i][1];
			arr = tmp;
			for (var i = 0; i < elems.length; i++) {
				var id = elems[i].innerHTML;
				if (isNaN(id)) continue;
				if (!arr[id]) {
					var parent = elems[i].parentElement.parentElement;
					var elem = elems[i].parentElement;
					parent.removeChild(elem);
					continue;
				}
				var title = decodeURIComponent(arr[id]);
				elems[i].innerHTML = title;
			}
		}
		);
	});
	
	function fn(data, elem) {
		var arr = JSON.parse(decodeURIComponent(data));
		var inner = "";
		for (var i = 0; i < arr.length; i++) {
			inner += `<li data-list="${i+1}"><a target="_blank" href="${webRoot}${DIR}/${arr[i][0]}.html">${arr[i][0]}</a><span>${arr[i][1]}</span></li>`;
		}
		elem.innerHTML = inner;
	}
})();

//联盟资讯
(function() {
	var list = document.querySelector("#info .list");
	ajax("get", `${cssJsPos}opaData/getPageBar.php?table=${TYPE}_info&query=title&orderBy=rand()&pageNum=10&allData&bar=false`,null, function(json) {
		if (json == "") return;
		var rows = JSON.parse(json);
		rows = rows["rows"];
		for (var i = 0; i < rows.length; i++) {
			var title = decodeURIComponent(rows[i][0]);
			list.innerHTML += `<li>${title}</li>`;
		}
	});
	
	var more = document.querySelector("#info .more");
	more.onclick = function() {
		window.open(`${webRoot}info/${DIR}.html`, "_blank");
	}
})();

//更多点评的“更多”
(function() {
	var more = document.querySelector("#com .more");
	more.onclick = function() {
		window.open(`${webRoot}com/${DIR}.html`, "_blank");
	}
})();

//复选框中的“全部”和“其他”
(function() {
	var checks = document.querySelectorAll("input.type");
	var all = document.querySelector("input.type[value='全部']");
	var other = document.querySelector("input.type[value='其他']");
	for (var i = 0; i < checks.length; i++) {
		checks[i].onclick = function() {
			if (this != all && this != other) {
				all.checked  = false;
				other.checked  = false;
				return;
			}
			for (var j = 0; j < checks.length; j++) {
				if (this != checks[j])
					checks[j].checked = false;
			}
		}
	}
})();

































