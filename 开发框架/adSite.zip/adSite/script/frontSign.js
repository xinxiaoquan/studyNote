window.AFTER = function(info) {
	alert(info);
	if (info == "登录成功！")
		location.href = "../";
	if (info == "您就是超级管理员吗？登录成功了！")
		location.href = "../home";
	if (info == "超级管理员已经登录！")
		location.href = "../home";
}

var mobile = document.querySelector("form input[name=mobile]");
window.FORMRULE(mobile, "blur", function() {
	if (this.value === "") {
		window.FORMERR(this, "用户名不能为空！");
		return;
	}
	window.FORMDELERR(this);
});

var pwd = document.querySelector("form input[name=pwd]");
window.FORMRULE(pwd, "blur", function() {
	if (this.value === "") {
		window.FORMERR(this, "密码不能为空！");
		return;
	}
	window.FORMDELERR(this);
});

