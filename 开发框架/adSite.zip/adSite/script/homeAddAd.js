window.AFTER = function(info) {
	alert(info);
	setCreateHtmlBubbles();
}

var adName = document.querySelector("form input[name=adName]");
window.FORMRULE(adName, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "联盟名称不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var adUrl = document.querySelector("form input[name=adUrl]");
window.FORMRULE(adUrl, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "联盟网址不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var adRecommend = document.querySelector("form [name=adRecommend]");
window.FORMRULE(adRecommend, "blur", function(e) {
	var span = document.querySelector("span."+this.name);
	if (this.value === "") {
		window.FORMERR(span, "联盟介绍不能为空！");
		if (!e) this.scrollIntoView();
		return;
	}
	window.FORMDELERR(span);
});

var time = document.querySelector("form [name=time]");
time.value = new Date().getTime();

//复选框中的“全部”和“其他”
(function() {
	var checks = document.querySelectorAll("input[name=adType]");
	var all = document.querySelector("input[name=adType][value='全部']");
	var other = document.querySelector("input[name=adType][value='其他']");
	for (var i = 0; i < checks.length; i++) {
		checks[i].onclick = function() {
			if (this != all && this != other) {
				all.checked  = false;
				other.checked  = false;
				return;
			}
			for (var j = 0; j < checks.length; j++) {
				if (this != checks[j])
					checks[j].checked = false;
			}
		}
	}
})();





















