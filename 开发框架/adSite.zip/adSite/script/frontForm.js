//定义前台表单输入框规则的函数
window.FORMRULE = function(input, event, fn) {
	input.addEventListener(event, fn);
	input.myRule = fn;
}
//前台规则错误
window.FORMERR = function(input, info) {
	if (!input) return;
	if (!hasClass(input, "err"))
		addClass(input, "err");
	input.placeholder = info;
}
//前台删除错误
window.FORMDELERR = function(input) {
	if (!input) return;
	replaceClass(input, "err", "");
}

//清空表单（reset）
window.FORMRESET = function() {
	var reset = document.querySelector("input[type=reset]");
	reset.click();
}

;(function() {
	
	var texts = document.querySelectorAll("form [type=text], form [type=password], form textarea");
	if (texts) {
		for (var i = 0; i < texts.length; i++) {
			texts[i].title = texts[i].placeholder;
			texts[i].setAttribute("autocomplete", "off");
			texts[i].addEventListener("click", function() {
				delClass(this, "err");
			});
		}
	}
	
	var submit = document.querySelector("form input[type=submit]");
	if (submit)
	submit.onclick = function() {

		var isPass = true;
		for (var i = 0; i < texts.length; i++) {
			texts[i].myRule();
			if (hasClass(texts[i], "err"))
				isPass = false;
		}
		if (!isPass) return false;
		var form = document.querySelector("form");
		if (form.getAttribute("isAjax") != "false") {
			var method = form.method;
			var url = form.action;
			var data = "";
			var checkbox = document.querySelectorAll("input[type=checkbox]");
			var checkedArr = [];
			for (var i = 0; i < checkbox.length; i++) {
				if(!checkedArr.hasOwnProperty(checkbox[i].name))
					checkedArr[checkbox[i].name] = [];
				if (checkbox[i].checked)
					checkedArr[checkbox[i].name].push(checkbox[i].value);
			}
			for (var key in checkedArr) {
				if (checkedArr[key].length == 0) {
					alert("复选框未选！");
					return false;
				}
				data += `${key}=${encodeURIComponent(JSON.stringify(checkedArr[key]))}&`;
			}
			var names = document.querySelectorAll("form [name]");
			for (var i = 0; i < names.length; i++) {
				if (names[i].getAttribute("type") == "checkbox")
					continue;
				var key = names[i].name;
				var value = names[i].value;
				data += `${key}=${encodeURIComponent(value)}&`;
			}
			var serviceStar = document.querySelector("form .service ul[selected]");
			if (serviceStar)
				data += `serviceStar=${serviceStar.getAttribute("selected")}&`;
			var timelyStar = document.querySelector("form .timely ul[selected]");
			if (timelyStar)
				data += `timelyStar=${timelyStar.getAttribute("selected")}&`;
			var creditStar = document.querySelector("form .credit ul[selected]");
			if (creditStar)
				data += `creditStar=${creditStar.getAttribute("selected")}&`;
			var codeRichStar = document.querySelector("form .codeRich ul[selected]");
			if (codeRichStar)
				data += `codeRichStar=${codeRichStar.getAttribute("selected")}&`;
			
			var speedStar = document.querySelector("form .speed ul[selected]");
			if (speedStar)
				data += `speedStar=${speedStar.getAttribute("selected")}&`;
			var stableStar = document.querySelector("form .stable ul[selected]");
			if (stableStar)
				data += `stableStar=${stableStar.getAttribute("selected")}&`;
			var priceRatioStar = document.querySelector("form .priceRatio ul[selected]");
			if (priceRatioStar)
				data += `priceRatioStar=${priceRatioStar.getAttribute("selected")}&`;
			
			var fastStar = document.querySelector("form .fast ul[selected]");
			if (fastStar)
				data += `fastStar=${fastStar.getAttribute("selected")}&`;
			var securityStar = document.querySelector("form .security ul[selected]");
			if (securityStar)
				data += `securityStar=${securityStar.getAttribute("selected")}&`;
			var highSafetyStar = document.querySelector("form .highSafety ul[selected]");
			if (highSafetyStar)
				data += `highSafetyStar=${highSafetyStar.getAttribute("selected")}&`;
			
			if (method == "get") {
				url = `${url}?${data}`;
				data = null;
			}
			ajax(method, url, data, function(data) {
				if (data == "") return;
				//页面中执行表单完成后触发的函数
				if (window.AFTER) window.AFTER(data);
				
				var captcha = document.querySelector("form .captcha");
				if (captcha && captcha.nodeName == "IMG")
					captcha.src = captcha.src;
				if (captcha && captcha.nodeName == "DIV") {
					var img = captcha.querySelector("img");
					img.src = img.src;
				}
				
			});
			
			return false;
		}
	}
	
})();
























