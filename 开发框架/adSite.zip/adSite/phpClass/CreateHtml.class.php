<?php
class createHtml {
	private $php;
	private $html;
	private $data;
	
	public function __construct($php, $html, $data) {
		$this->php = $php;
		$this->html = $html;
		$this->data = $data;
	}
	
	public function create() {
		$mysql = $GLOBALS["mysql"];
		date_default_timezone_set("prc");
		$date = date("Y-m-d H:i:s");
		$DATA = $this->data;
		ob_start();
		include $this->php;
		$content = ob_get_contents();
		file_put_contents($this->html, $content);
		ob_end_clean();
	}
}