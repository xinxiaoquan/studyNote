<?php
class ContentLatest {
	private $contentName;
	public function __construct($contentName) {
		$this->contentName = $contentName;
		if (!is_dir("../json/contentLatest/"))
			mkdir("../json/contentLatest/", "0777", true);
	}
	public function create() {
		$mysql = $GLOBALS["mysql"];
		$path = "../json/contentLatest/{$this->contentName}.json";
		$arr = [];
		$sql = "SELECT id,name,time FROM {$this->contentName} WHERE is_pass=1 ORDER BY id DESC LIMIT 10";
		$res = $mysql -> query($sql);
		if (!$res) return;
		while ($row = $res->fetch_array()) {
			$id = $row[0];
			$title = $row[1];
			$time = $row[2];
			$arr[] = [$id,$title,$time];
		}
		$json = json_encode($arr);
		file_put_contents($path, myUrlencode($json));
	}
}