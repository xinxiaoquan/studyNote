<?php
//生成网页的任务，写入配置文件
class CreateHtmlTask {
	private $iniPath;
	private $info;
	public function __construct($iniPath, $info) {
		$this->iniPath = "../json/createHtml/{$iniPath}";
		$this->info = $info."\r\n";
		if (!is_dir("../json/createHtml/"))
			mkdir("../json/createHtml/", "0777", true);
	}
	public function add() {
		$data = @file_get_contents($this->iniPath);
		if ($data) {
			if (strpos($data, $this->info) !== false)
				return;
		}
		file_put_contents($this->iniPath, $this->info, FILE_APPEND);
	}
	public function del() {
		$data = @file_get_contents($this->iniPath);
		if (!$data) return;
		$data = str_replace($this->info, "", $data);
		file_put_contents($this->iniPath, $data);
	}
}