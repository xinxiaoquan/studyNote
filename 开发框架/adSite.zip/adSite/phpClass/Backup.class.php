<?php
class Backup {
	//存储数据的路径
	private $path;
	//数据库名
	private $database;
	public function save($path, $database) {
		$sql = "show tables";
		$res = $GLOBALS["mysql"] -> query($sql);
		$allTables = [];
		while ($row = $res->fetch_array())
			$allTables[] = $row[0];
		$length = count($allTables);
		for ($i = 0; $i < $length; $i++) {
			$sql = "SELECT * FROM {$allTables[$i]}";
			$res = $GLOBALS["mysql"] -> query($sql);
			$sql = "INSERT INTO {$allTables[$i]} VALUES";
			$fragment = "";
			while ($row = $res -> fetch_object()) {
				$str = "";
				foreach ($row as $key=>$val)
					$str .= "'{$val}',";
				$str = substr($str, 0, strlen($str)-1);
				$fragment .= "({$str}),";
			}
			if ($fragment) {
				$fragment = substr($fragment, 0, strlen($fragment)-1);
				$sql = "truncate table {$allTables[$i]};\r\n".$sql;
				$sql .= "{$fragment};\r\n";
				file_put_contents($path, $sql, FILE_APPEND);
			}
		}
	}
}







































