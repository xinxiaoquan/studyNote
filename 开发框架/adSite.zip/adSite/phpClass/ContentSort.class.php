<?php
class ContentSort {
	//内页表ID
	private $pId;
	//评论表名
	private $comName;
	//内页表名
	private $contentName;
	public function __construct($pId,$comName,$contentName){
		$this->pId = $pId;
		$this->comName = $comName;
		$this->contentName = $contentName;
	}
	//写入内页各项评分的平均值
	public function avg() {
		$mysql = $GLOBALS["mysql"];
		if ($this->contentName == "ad" || $this->contentName == "app")
			$sql = "SELECT timely,credit,service,code_rich FROM {$this->comName} WHERE pId={$this->pId} AND is_pass=1";
		if ($this->contentName == "seo")
			$sql = "SELECT speed,stable,service,price_ratio FROM {$this->comName} WHERE pId={$this->pId} AND is_pass=1";
		if ($this->contentName == "vps")
			$sql = "SELECT fast,price_ratio,service,security,high_safety FROM {$this->comName} WHERE pId={$this->pId} AND is_pass=1";
		$res = $mysql -> query($sql);
		if (!$res) return;
		
		if ($this->contentName == "ad" || $this->contentName == "app") {
			$timely = [];
			$credit = [];
			$service = [];
			$code_rich = [];
			while ($row = $res->fetch_array()) {
				$timely[] = $row[0];
				$credit[] = $row[1];
				$service[] = $row[2];
				$code_rich[] = $row[3];
			}
			$timely = $this->arrAvg($timely);
			$credit = $this->arrAvg($credit);
			$service = $this->arrAvg($service);
			$code_rich = $this->arrAvg($code_rich);
		}
		if ($this->contentName == "seo") {
			$speed = [];
			$stable = [];
			$service = [];
			$price_ratio = [];
			while ($row = $res->fetch_array()) {
				$speed[] = $row[0];
				$stable[] = $row[1];
				$service[] = $row[2];
				$price_ratio[] = $row[3];
			}
			$speed = $this->arrAvg($speed);
			$stable = $this->arrAvg($stable);
			$service = $this->arrAvg($service);
			$price_ratio = $this->arrAvg($price_ratio);
		}
		if ($this->contentName == "vps") {
			$fast = [];
			$priceRatio = [];
			$service = [];
			$security = [];
			$highSafety = [];
			while ($row = $res->fetch_array()) {
				$fast[] = $row[0];
				$priceRatio[] = $row[1];
				$service[] = $row[2];
				$security[] = $row[3];
				$highSafety[] = $row[4];
			}
			$fast = $this->arrAvg($fast);
			$priceRatio = $this->arrAvg($priceRatio);
			$service = $this->arrAvg($service);
			$security = $this->arrAvg($security);
			$highSafety = $this->arrAvg($highSafety);
		}
		
		$sql = "SELECT content FROM {$this->comName} WHERE pId={$this->pId} AND is_pass=1 ORDER BY id DESC LIMIT 1";
		$res = $mysql -> query($sql);
		$latestCom = $res->fetch_array()[0];
		if (!$latestCom) $latestCom = "";
		
		if ($this->contentName == "ad" || $this->contentName == "app") {
			$data = json_encode([
				"timely"=>$timely,
				"credit"=>$credit,
				"service"=>$service,
				"code_rich"=>$code_rich,
				"latestCom"=>$latestCom
			]);
		}
		if ($this->contentName == "seo") {
			$data = json_encode([
				"speed"=>$speed,
				"stable"=>$stable,
				"service"=>$service,
				"price_ratio"=>$price_ratio,
				"latestCom"=>$latestCom
			]);
		}
		if ($this->contentName == "vps") {
			$data = json_encode([
				"fast"=>$fast,
				"price_ratio"=>$priceRatio,
				"service"=>$service,
				"security"=>$security,
				"high_safety"=>$highSafety,
				"latestCom"=>$latestCom
			]);
		}
		
		$path = "../json/contentScore/{$this->contentName}/{$this->pId}.json";
		if (!is_dir("../json/contentScore/{$this->contentName}/"))
			mkdir("../json/contentScore/{$this->contentName}/", "0777", true);
		$data = myUrlencode($data);
		file_put_contents($path, $data);
		
		if ($this->contentName == "ad" || $this->contentName == "app")
			$sql = "UPDATE {$this->contentName} SET timely={$timely},credit={$credit},service={$service},code_rich={$code_rich} WHERE id={$this->pId}";
		if ($this->contentName == "seo")
			$sql = "UPDATE {$this->contentName} SET speed={$speed},stable={$stable},service={$service},price_ratio={$price_ratio} WHERE id={$this->pId}";
		if ($this->contentName == "vps")
			$sql = "UPDATE {$this->contentName} SET fast={$fast},price_ratio={$priceRatio},service={$service},security={$security},high_safety={$highSafety} WHERE id={$this->pId}";
		$mysql -> query($sql);
	}
	//内容页通过评分的各种排序
	public function createJson() {
		$contentBase = [];
		$path = "../json/contentScore/{$this->contentName}/";
		if (!is_dir($path)) mkdir($path, "07777", true);
		$dir = opendir($path);
		while ($file = readdir($dir)) {
			if ($file == "." || $file == "..")
				continue;
			if (strpos($file, ".json") != -1) {
				$sub = str_replace(".json", "", $file);
				$data = file_get_contents("{$path}{$file}");
				$data = json_decode(urldecode($data));
				$contentBase[$sub] = $data;
			}
		}
		closedir($dir);
		
		$path = "../json/contentSort/{$this->contentName}/";
		if (!is_dir($path))
			mkdir($path, "0777", true);
		
		if ($this->contentName == "ad" || $this->contentName == "app") {
			if (count($contentBase) == 0) {
				$res = [
					"timely"=>"",
					"credit"=>"",
					"service"=>"",
					"code_rich"=>"",
					"rand"=>""
				];
			} else $res = $this->manyArrSort($contentBase);
			$arr = $res["timely"];
			if ($arr) {
				$newArr = [];
				foreach ($arr as $key=>$val)
					$newArr[] = [$key, $val];
				file_put_contents(
					"{$path}timely.json",
					myUrlencode(json_encode($newArr))
				);
			}
			$arr = $res["credit"];
			if ($arr) {
				$newArr = [];
				foreach ($arr as $key=>$val)
					$newArr[] = [$key, $val];
				file_put_contents(
					"{$path}credit.json",
					myUrlencode(json_encode($newArr))
				);
			}
			$arr = $res["service"];
			if ($arr) {
				$newArr = [];
				foreach ($arr as $key=>$val)
					$newArr[] = [$key, $val];
				file_put_contents(
					"{$path}service.json",
					myUrlencode(json_encode($newArr))
				);
			}
			$arr = $res["code_rich"];
			if ($arr) {
				$newArr = [];
				foreach ($arr as $key=>$val)
					$newArr[] = [$key, $val];
				file_put_contents(
					"{$path}code_rich.json",
					myUrlencode(json_encode($newArr))
				);
			}
			$arr = $res["rand"];
			file_put_contents(
				"{$path}rand.json",
				myUrlencode(json_encode($arr))
			);
		}
		
		if ($this->contentName == "seo") {
			if (count($contentBase) == 0) {
				$res = [
					"speed"=>"",
					"stable"=>"",
					"service"=>"",
					"price_ratio"=>"",
					"rand"=>""
				];
			} else $res = $this->manyArrSort($contentBase);
			$arr = $res["speed"];
			if ($arr) {
				$newArr = [];
				foreach ($arr as $key=>$val)
					$newArr[] = [$key, $val];
				file_put_contents(
					"{$path}speed.json",
					myUrlencode(json_encode($newArr))
				);
			}
			$arr = $res["stable"];
			if ($arr) {
				$newArr = [];
				foreach ($arr as $key=>$val)
					$newArr[] = [$key, $val];
				file_put_contents(
					"{$path}stable.json",
					myUrlencode(json_encode($newArr))
				);
			}
			$arr = $res["service"];
			if ($arr) {
				$newArr = [];
				foreach ($arr as $key=>$val)
					$newArr[] = [$key, $val];
				file_put_contents(
					"{$path}service.json",
					myUrlencode(json_encode($newArr))
				);
			}
			$arr = $res["price_ratio"];
			if ($arr) {
				$newArr = [];
				foreach ($arr as $key=>$val)
					$newArr[] = [$key, $val];
				file_put_contents(
					"{$path}price_ratio.json",
					myUrlencode(json_encode($newArr))
				);
			}
			$arr = $res["rand"];
			file_put_contents(
				"{$path}rand.json",
				myUrlencode(json_encode($arr))
			);
		}
		
		if ($this->contentName == "vps") {
			if (count($contentBase) == 0) {
				$res = [
					"fast"=>"",
					"price_ratio"=>"",
					"service"=>"",
					"security"=>"",
					"high_safety"=>"",
					"rand"=>""
				];
			} else $res = $this->manyArrSort($contentBase);
			$arr = $res["fast"];
			if ($arr) {
				$newArr = [];
				foreach ($arr as $key=>$val)
					$newArr[] = [$key, $val];
				file_put_contents(
					"{$path}fast.json",
					myUrlencode(json_encode($newArr))
				);
			}
			$arr = $res["price_ratio"];
			if ($arr) {
				$newArr = [];
				foreach ($arr as $key=>$val)
					$newArr[] = [$key, $val];
				file_put_contents(
					"{$path}price_ratio.json",
					myUrlencode(json_encode($newArr))
				);
			}
			$arr = $res["service"];
			if ($arr) {
				$newArr = [];
				foreach ($arr as $key=>$val)
					$newArr[] = [$key, $val];
				file_put_contents(
					"{$path}service.json",
					myUrlencode(json_encode($newArr))
				);
			}
			$arr = $res["security"];
			if ($arr) {
				$newArr = [];
				foreach ($arr as $key=>$val)
					$newArr[] = [$key, $val];
				file_put_contents(
					"{$path}security.json",
					myUrlencode(json_encode($newArr))
				);
			}
			$arr = $res["high_safety"];
			if ($arr) {
				$newArr = [];
				foreach ($arr as $key=>$val)
					$newArr[] = [$key, $val];
				file_put_contents(
					"{$path}high_safety.json",
					myUrlencode(json_encode($newArr))
				);
			}
			$arr = $res["rand"];
			file_put_contents(
				"{$path}rand.json",
				myUrlencode(json_encode($arr))
			);
		}
	}
	//写入评论的数量
	public function writeComNum() {
		$mysql = $GLOBALS["mysql"];
		$sql = "SELECT count(*) FROM {$this->comName} WHERE pId={$this->pId} AND is_pass=1";
		$res = $mysql -> query($sql);
		$num = $res -> fetch_array()[0];
		$sql = "UPDATE {$this->contentName} SET coms={$num} WHERE id={$this->pId}";
		$mysql -> query($sql);
	}
	//数组求平均
	private function arrAvg($arr) {
		$length = count($arr);
		if ($length == 0) return 0;
		$add = 0;
		for ($i = 0; $i < $length; $i++) {
			$add += $arr[$i];
		}
		return round($add/$length, 2);
	}
	//多数组排序
	private function manyArrSort($arr) {
		if ($this->contentName == "ad" || $this->contentName == "app") {
			$timely = [];
			$credit = [];
			$service = [];
			$code_rich = [];
			$rand = [];
			foreach ($arr as $key=>$val) {
				$val = (array)$val;
				$timely[$key] = $val["timely"];
				$credit[$key] = $val["credit"];
				$service[$key] = $val["service"];
				$code_rich[$key] = $val["code_rich"];
				if (mt_rand(1,10) <= 5)
					$rand[] = $key;
			}
			arsort($timely);
			$timely = $this->getArrTen($timely);
			arsort($credit);
			$credit = $this->getArrTen($credit);
			arsort($service);
			$service = $this->getArrTen($service);
			arsort($code_rich);
			$code_rich = $this->getArrTen($code_rich);
			$rand = $this->getArrTen($rand);
			return [
				"timely"=>$timely,
				"credit"=>$credit,
				"service"=>$service,
				"code_rich"=>$code_rich,
				"rand"=>$rand
			];
		}
		
		if ($this->contentName == "seo") {
			$speed = [];
			$stable = [];
			$service = [];
			$price_ratio = [];
			$rand = [];
			foreach ($arr as $key=>$val) {
				$val = (array)$val;
				$speed[$key] = $val["speed"];
				$stable[$key] = $val["stable"];
				$service[$key] = $val["service"];
				$price_ratio[$key] = $val["price_ratio"];
				if (mt_rand(1,10) <= 5)
					$rand[] = $key;
			}
			arsort($speed);
			$speed = $this->getArrTen($speed);
			arsort($stable);
			$stable = $this->getArrTen($stable);
			arsort($service);
			$service = $this->getArrTen($service);
			arsort($price_ratio);
			$price_ratio = $this->getArrTen($price_ratio);
			$rand = $this->getArrTen($rand);
			return [
				"speed"=>$speed,
				"stable"=>$stable,
				"service"=>$service,
				"price_ratio"=>$price_ratio,
				"rand"=>$rand
			];
		}
		
		if ($this->contentName == "vps") {
			$fast = [];
			$price_ratio = [];
			$service = [];
			$security = [];
			$high_safety = [];
			$rand = [];
			foreach ($arr as $key=>$val) {
				$val = (array)$val;
				$fast[$key] = $val["fast"];
				$price_ratio[$key] = $val["price_ratio"];
				$service[$key] = $val["service"];
				$security[$key] = $val["security"];
				$high_safety[$key] = $val["high_safety"];
				if (mt_rand(1,10) <= 5)
					$rand[] = $key;
			}
			arsort($fast);
			$fast = $this->getArrTen($fast);
			arsort($price_ratio);
			$price_ratio = $this->getArrTen($price_ratio);
			arsort($service);
			$service = $this->getArrTen($service);
			arsort($security);
			$security = $this->getArrTen($security);
			arsort($high_safety);
			$high_safety = $this->getArrTen($high_safety);
			$rand = $this->getArrTen($rand);
			return [
				"fast"=>$fast,
				"price_ratio"=>$price_ratio,
				"service"=>$service,
				"security"=>$security,
				"high_safety"=>$high_safety,
				"rand"=>$rand
			];
		}
	}
	//截取数组前十个
	private function getArrTen($arr) {
		$index = 1;
		$newArr = [];
		foreach ($arr as $key=>$val) {
			$newArr[$key] = $val;
			if ($index++ == 10)
				break;
		}
		return $newArr;
	}
}


























