<?php
class Page {
	private $now;
	private $all;
	
	public function __construct($now, $all) {
		$this -> now = $now;
		$this -> all = $all;
	}
	
	public function create() {
		$first = $this->now - 5;
		if ($first <= 1) $first = 2;
		$end = $this->now + 5;
		if ($end >= $this->all)
			$end = $this->all - 1;
		
		$html = "";
		
		if ($this->all > 1) {
			if ($this->now == 1)
				$html .= "<li class=active pageNo=1>首页</li>";
			else $html .= "<li pageNo=1>首页</li>";
		}
		
		if ($first > 2) $html .= "<li class=select>…</li>";
		
		for ($i = $first; $i <= $end; $i++) {
			if ($i == $this->now)
				$html .= "<li pageNo={$i} class=active>{$i}</li>";
			else $html .= "<li pageNo={$i}>{$i}</li>";
		}
		
		if ($end < $this->all - 1) $html .= "<li class=select>…</li>";
		
		if ($this->all > 1) {
			if ($this->now == $this->all)
				$html .= "<li class=active pageNo={$this->all}>尾页</li>";
			else $html .= "<li pageNo={$this->all}>尾页</li>";
		}
		return $html;
	}
}




























