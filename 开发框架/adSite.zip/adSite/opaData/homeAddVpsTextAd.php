<?php
include "handle.php";

$text = @$_POST["text"];
$link = @$_POST["link"];
$position = @$_POST["position"];

if (!$text || !$link || $position === null)
	die("数据不全！");

$path = "../json/vpsTextAd.json";
if (!file_exists($path))
	$json = "[]";
else $json = urldecode(file_get_contents($path));

$data = json_decode($json);
$length = count($data);
if ($position < 0) $position = 0;
if ($position > $length) $position = $length;
for ($i = $length; $i >= $position; $i--) {
	if ($i-1 >= 0)
		$data[$i] = $data[$i-1];
	if ($i == $position) {
		$data[$i] = [$text, $link];
	}
}

$json = myUrlencode(json_encode($data));
file_put_contents($path, $json);

echo "广告添加成功！添加到了第{$position}条的后面";



















