<?php
include "handle.php";
include "../phpClass/ContentSort.class.php";

$ids = @$_GET["ids"];
$ips = @$_GET["ips"];
if (!$ids || !$ips) die("数据不全！");

$arr = explode(",", $ids);
for ($i = 0; $i < count($arr); $i++) {
	$sql = "SELECT pId FROM vps_com WHERE id='{$arr[$i]}'";
	$res = $mysql -> query($sql);
	$res = $res -> fetch_array();
	$pId = $res[0];
	
	$sql = "DELETE FROM vps_com WHERE id='{$arr[$i]}'";
	$mysql -> query($sql);
	
	$c = new ContentSort($pId,"vps_com","vps");
	$c -> avg();
	$c -> createJson();
	$c -> writeComNum();
}

$arr = explode(",", $ips);
for ($i = 0; $i < count($arr); $i++) {
	$sql = "SELECT id FROM ip_blacklist WHERE ip='{$arr[$i]}'";
	$res = $mysql -> query($sql);
	if ($res -> fetch_array()) continue;
	$sql = "INSERT INTO ip_blacklist VALUES(null,'{$arr[$i]}')";
	$mysql -> query($sql);
}

echo "ok";





















