<?php
include "handle.php";
include "../phpClass/CreateHtmlTask.class.php";

$ids = @$_GET["ids"];
$time = @$_GET["time"];

$arr = explode(",", $ids);
for ($i = 0; $i < count($arr); $i++) {
	$sql = "UPDATE seo SET is_pass=1,time='{$time}' WHERE id={$arr[$i]}";
	$mysql -> query($sql);
	
	$t = new CreateHtmlTask("seo.ini", "{$arr[$i]}");
	$t -> add();
}

echo "ok";

include "../phpClass/ContentLatest.class.php";
$l = new ContentLatest("seo");
$l -> create();



























