<?php
include "handle.php";

$title = @$_POST["title"];
$time = @$_POST["time"];
$content = @$_POST["content"];

if (!$title || !$time || !$content)
	die("数据不全！");

$title = myUrlencode($title);
$time = myUrlencode($time);
$content = myUrlencode($content);

$sql = "INSERT INTO seo_info VALUES(null, '{$title}', '{$time}', '{$content}')";
$mysql->query($sql);

echo "添加一条SEO资讯成功！\r\n";
echo "新添加资讯的ID：".$mysql->insert_id;