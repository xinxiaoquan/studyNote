<?php
if (!$_GET) exit;

$query = @$_GET["query"];
$table = @$_GET["table"];
$query = filter($query);
$table = filter($table);

if (!$query || !$table)
	die("数据不全！");

function filter($str) {
	if ($str === null) return null;
	return preg_replace("/\s/", "", $str);
}

global $databaseInfo;
global $mysql;
$databaseInfo = file_get_contents("../data/databaseInfo.php");
$databaseInfo = preg_replace('/^<\?.+\/\//', "", $databaseInfo);
$databaseInfo = json_decode(urldecode($databaseInfo));
$mysql = new mySQLi(
	$databaseInfo -> dAdress,
	$databaseInfo -> dUser,
	$databaseInfo -> dPwd,
	$databaseInfo -> dName,
	3306
);

$pageNo = @$_GET["pageNo"];
$pageNo = filter($pageNo);
if (!$pageNo)
	$pageNo = 1;

$pageNum = @$_GET["pageNum"];
$pageNum = filter($pageNum);
if (!$pageNum)
	$pageNum = 100;

$where = @$_GET["where"];
$where = filter($where);
if ($where)
	$where = "WHERE is_pass=1 AND {$where} ";
else $where = "WHERE is_pass=1 ";

$whereIdOr = @$_GET["whereIdOr"];
if ($whereIdOr) {
	$arr = json_decode($whereIdOr);
	$length = count($arr);
	if ($length != 0) {
		$where .= " AND ";
		for ($i = 0; $i < $length; $i++) {
			$where .= "id={$arr[$i]}";
			if ($i < $length-1)
				$where .= " OR ";
		}
	}
}

if (isset($_GET["noPass"]))
	$where = str_replace("is_pass=1", "is_pass=0", $where);

if (isset($_GET["allData"]))
	$where = preg_replace("/is_pass=\d/", "1", $where);

if (isset($_GET["bar"]))
	$bar = false;
else $bar = true;

$orderBy = "ORDER by id";
if (isset($_GET["orderBy"])) {
	if ($_GET["orderBy"] == null)
		$orderBy = "";
	else $orderBy = "ORDER by ".$_GET["orderBy"];
}

$start = ($pageNo - 1) * $pageNum;

$sql = "SELECT {$query} FROM {$table} {$where} {$orderBy} DESC LIMIT {$start},{$pageNum}";
$rows = $mysql -> query($sql);
$rows = $rows -> fetch_all();

$sql = "SELECT count(*) FROM {$table} {$where}";
$allNum = $mysql -> query($sql);
$allNum = $allNum -> fetch_array();
$allNum = $allNum[0];
$allPage = ceil($allNum / $pageNum);
if ($bar)
	if (!$allPage || $allPage <= 1) $pageHtml = "";
	else {
		include "../phpClass/Page.class.php";
		$pageHtml = new Page($pageNo, $allPage);
		$pageHtml = $pageHtml -> create();
	}

$data = [];
$data["rows"] = $rows;
if ($bar)
	$data["page"] = $pageHtml;
if (isset($_GET["allPage"]))
	$data["allPage"] = $allPage;
if (isset($_GET["allNum"]))
	$data["allNum"] = $allNum;

echo json_encode($data);





