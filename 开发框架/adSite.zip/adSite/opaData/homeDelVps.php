<?php
$ids = @$_GET["ids"];
if (!$ids) die("数据不全！");

include "handle.php";
include "../phpClass/CreateHtmlTask.class.php";
include "../phpClass/ContentSort.class.php";
include "../phpClass/ContentLatest.class.php";

$webconfig = @file_get_contents("../json/webconfig.json");
if (!$webconfig) $webconfig = ["vpsDir"=>"vps"];
else $webconfig = json_decode(urldecode($webconfig));

$arr = explode(",", $ids);
$delVps = "";
$delVpsCom = "";
for ($i = 0; $i < count($arr); $i++) {
	$delVps .= "id={$arr[$i]} ";
	$delVpsCom .= "pId={$arr[$i]} ";
	if ($i != count($arr)-1) {
		$delVps .= "or ";
		$delVpsCom .= "or ";
	}
	
	$t = new CreateHtmlTask("vps.ini", "{$arr[$i]}");
	$t -> del();
	
	$path = "../json/contentScore/vps/{$arr[$i]}.json";
	@unlink($path);
	$path = "../json/contentViews/vps/{$arr[$i]}.json";
	@unlink($path);
	$path = "../{$webconfig->vpsDir}/{$arr[$i]}.html";
	@unlink($path);
	
	$c = new contentSort($arr[$i], "vps_com", "vps");
	$c -> createJson();
}

$sql = "DELETE FROM vps WHERE {$delVps}";
$mysql -> query($sql);
$sql = "DELETE FROM vps_com WHERE {$delVpsCom}";
$mysql -> query($sql);

$l = new ContentLatest("vps");
$l -> create();

echo "ok";





























