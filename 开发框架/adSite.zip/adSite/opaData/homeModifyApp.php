<?php
include "handle.php";

$appId = @$_POST["appId"];
$appName = @$_POST["appName"];
$appClass = @$_POST["appClass"];
$appAdType = @$_POST["appAdType"];
$appSettle = @$_POST["appSettle"];
$appQuery = @$_POST["appQuery"];
$appProType = @$_POST["appProType"];
$appPrice = @$_POST["appPrice"];
$appContent = @$_POST["appContent"];
$appContact = @$_POST["appContact"];

if (!$appId || !$appName || !$appClass || !$appAdType || !$appSettle || !$appQuery || !$appProType || !$appPrice || !$appContent || !$appContact)
	die("数据不全！");

$appName = myUrlencode($appName);
$appClass = myUrlencode($appClass);
$appAdType = myUrlencode($appAdType);
$appSettle = myUrlencode($appSettle);
$appQuery = myUrlencode($appQuery);
$appProType = myUrlencode($appProType);
$appPrice = myUrlencode($appPrice);
$appContent = myUrlencode($appContent);
$appContact = myUrlencode($appContact);

$sql = "UPDATE app SET name='{$appName}',class='{$appClass}',ad_type='{$appAdType}',settle='{$appSettle}',query='{$appQuery}',pro_type='{$appProType}',price='{$appPrice}',content='{$appContent}',contact='{$appContact}' WHERE id={$appId}";
$mysql -> query($sql);

echo "修改一条APP信息成功！";

include "../phpClass/CreateHtmlTask.class.php";
$t = new CreateHtmlTask("app.ini", "{$appId}");
$t -> add();


































