<?php
include "handle.php";

$id = @$_POST["id"];
$title = @$_POST["title"];
$time = @$_POST["time"];
$content = @$_POST["content"];

if (!$id || !$title || !$time || !$content)
	die("数据不全！");

$title = myUrlencode($title);
$time = myUrlencode($time);
$content = myUrlencode($content);

$sql = "UPDATE app_info SET title='{$title}',time='{$time}',content='{$content}' WHERE id={$id}";
$mysql->query($sql);

echo "修改一条APP资讯成功！";