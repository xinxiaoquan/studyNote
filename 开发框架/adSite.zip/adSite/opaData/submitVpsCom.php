<?php

$fastStar = @$_GET["fastStar"];
$priceRatioStar = @$_GET["priceRatioStar"];
$serviceStar = @$_GET["serviceStar"];
$securityStar = @$_GET["securityStar"];
$highSafetyStar = @$_GET["highSafetyStar"];

include "submitCom.php";

$fastStar = myUrlencode($fastStar);
$priceRatioStar = myUrlencode($priceRatioStar);
$serviceStar = myUrlencode($serviceStar);
$securityStar = myUrlencode($securityStar);
$highSafetyStar = myUrlencode($highSafetyStar);

$sql = "INSERT INTO vps_com VALUES(
	null,'{$pId}','{$title}','{$nickname}','{$content}','{$fastStar}','{$priceRatioStar}','{$serviceStar}','{$securityStar}','{$highSafetyStar}','{$time}','{$ip}','{$area}',0
)";
$mysql -> query($sql);

echo "评论提交成功！请等待管理员审核！";