<?php
include "handle.php";

$seoId = @$_POST["seoId"];
$seoName = @$_POST["seoName"];
$seoUrl = @$_POST["seoUrl"];
$seoAdress = @$_POST["seoAdress"];
$seoMobile = @$_POST["seoMobile"];
$seoQQ = @$_POST["seoQQ"];
$seoWX = @$_POST["seoWX"];
$seoRecommend = @$_POST["seoRecommend"];
$seoType = @$_POST["seoType"];
$seoClass = @$_POST["seoClass"];
$seoArea = @$_POST["seoArea"];
$seoQuality = @$_POST["seoQuality"];


if (!$seoId || !$seoName || !$seoUrl || !$seoAdress || !$seoMobile || !$seoQQ || !$seoWX || !$seoRecommend || !$seoType || !$seoClass || !$seoArea || !$seoQuality)
	die("数据不全！");

$seoName = myUrlencode($seoName);
$seoUrl = myUrlencode($seoUrl);
$seoAdress = myUrlencode($seoAdress);
$seoMobile = myUrlencode($seoMobile);
$seoQQ = myUrlencode($seoQQ);
$seoWX = myUrlencode($seoWX);
$seoRecommend = myUrlencode($seoRecommend);
$seoType = myUrlencode($seoType);
$seoClass = myUrlencode($seoClass);
$seoArea = myUrlencode($seoArea);
$seoQuality = myUrlencode($seoQuality);

$sql = "UPDATE seo SET name='{$seoName}',url='{$seoUrl}',adress='{$seoAdress}',mobile='{$seoMobile}',qq='{$seoQQ}',wx='{$seoWX}',recommend='{$seoRecommend}',type='{$seoType}',class='{$seoClass}',area='{$seoArea }',quality='{$seoQuality}' WHERE id={$seoId}";
$mysql -> query($sql);

echo "修改一条SEO服务成功！";

include "../phpClass/CreateHtmlTask.class.php";
$t = new CreateHtmlTask("seo.ini", "{$seoId}");
$t -> add();




















