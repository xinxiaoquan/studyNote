<?php
include "handle.php";

$type = @$_GET["type"];
if (!$type) exit;

if ($type == "ad")
	file_put_contents("../json/createHtml/ad.ini", "");
if ($type == "seo")
	file_put_contents("../json/createHtml/seo.ini", "");
if ($type == "app")
	file_put_contents("../json/createHtml/app.ini", "");
if ($type == "vps")
	file_put_contents("../json/createHtml/vps.ini", "");