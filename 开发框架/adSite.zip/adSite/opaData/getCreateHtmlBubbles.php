<?php
include "handle.php";

if (!is_dir("../json/createHtml/"))
	mkdir("../json/createHtml/", "0777", true);

$adIni = @file_get_contents("../json/createHtml/ad.ini");
$seoIni = @file_get_contents("../json/createHtml/seo.ini");
$vpsIni = @file_get_contents("../json/createHtml/vps.ini");
$appIni = @file_get_contents("../json/createHtml/app.ini");

$arr = [];

if ($adIni)
	$arr["ad"] = substr_count($adIni, "\r\n");
else $arr["ad"] = 0;
if ($seoIni)
	$arr["seo"] = substr_count($seoIni, "\r\n");
else $arr["seo"] = 0;
if ($vpsIni)
	$arr["vps"] = substr_count($vpsIni, "\r\n");
else $arr["vps"] = 0;
if ($appIni)
	$arr["app"] = substr_count($appIni, "\r\n");
else $arr["app"] = 0;

echo json_encode($arr);