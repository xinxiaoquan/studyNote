<?php

$serviceStar = @$_GET["serviceStar"];
$timelyStar = @$_GET["timelyStar"];
$creditStar = @$_GET["creditStar"];
$codeRichStar = @$_GET["codeRichStar"];

if (!$serviceStar || !$timelyStar || !$creditStar || !$codeRichStar)
	die("数据不全！");

include "submitCom.php";

$serviceStar = myUrlencode($serviceStar);
$timelyStar = myUrlencode($timelyStar);
$creditStar = myUrlencode($creditStar);
$codeRichStar = myUrlencode($codeRichStar);

$sql = "INSERT INTO ad_com VALUES(
	null,'{$pId}','{$title}','{$timelyStar}','{$creditStar}','{$serviceStar}','{$codeRichStar}','{$nickname}','{$content}','{$time}','{$ip}','{$area}',0
)";
$mysql -> query($sql);

echo "评论提交成功！请等待管理员审核！";
