<?php

$class = filter(@$_GET["class"]);
$adType = filter(@$_GET["adType"]);
$settle = filter(@$_GET["settle"]);
$priceSelect = filter(@$_GET["priceSelect"]);
$priceQuery = filter(@$_GET["priceQuery"]);
$proType = filter(@$_GET["proType"]);
$sort = filter(@$_GET["sort"]);
$sortRule = filter(@$_GET["sortRule"]);
$query = filter(@$_GET["query"]);
$pageNo = filter(@$_GET["pageNo"]);
$pageNum = filter(@$_GET["pageNum"]);

if ($pageNo == null) $pageNo = 1;
if ($pageNum == null) $pageNum = 50;

if ($query == null) 
	$query = "";
else $query = "name LIKE '%{$query}%' AND";
if (isset($_GET["simple"]))
	$simple = true;
else $simple = false;

function filter($str) {
	if ($str === null) return null;
	$str = rawurlencode($str);
	return preg_replace("/\s/", "", $str);
}

global $databaseInfo;
global $mysql;
$databaseInfo = file_get_contents("../data/databaseInfo.php");
$databaseInfo = preg_replace('/^<\?.+\/\//', "", $databaseInfo);
$databaseInfo = json_decode(urldecode($databaseInfo));
$mysql = new mySQLi(
	$databaseInfo -> dAdress,
	$databaseInfo -> dUser,
	$databaseInfo -> dPwd,
	$databaseInfo -> dName,
	3306
);

if ($simple)
	$sql = "SELECT COUNT(*) FROM app WHERE {$query} is_pass=1";
else {
	$sql = "SELECT COUNT(*) FROM app WHERE {$query} is_pass=1 AND class='{$class}' AND ad_type='{$adType}' AND settle='{$settle}' AND query='{$priceQuery}' AND pro_type='{$proType}'";
	if ($priceSelect == 2) 
		$sql .= " AND price<=1";
	if ($priceSelect == 3) 
		$sql .= " AND price>1 AND price<=2";
	if ($priceSelect == 4) 
		$sql .= " AND price>2 AND price<=5";
	if ($priceSelect == 5) 
		$sql .= " AND price>5 AND price<=10";
	if ($priceSelect == 6) 
		$sql .= " AND price>50";
}
$res = $mysql -> query($sql);
$allNum = $res -> fetch_array()[0];
$allPage = ceil($allNum/$pageNum);

if ($simple)
	$sql = "SELECT id,name,coms FROM app WHERE {$query} is_pass=1 ORDER BY id DESC";
else {
	$sql = "SELECT id,name,coms FROM app WHERE {$query} is_pass=1 AND class='{$class}' AND ad_type='{$adType}' AND settle='{$settle}' AND query='{$priceQuery}' AND pro_type='{$proType}'";
	if ($priceSelect == 2) 
		$sql .= " AND price<=1";
	if ($priceSelect == 3) 
		$sql .= " AND price>1 AND price<=2";
	if ($priceSelect == 4) 
		$sql .= " AND price>2 AND price<=5";
	if ($priceSelect == 5) 
		$sql .= " AND price>5 AND price<=10";
	if ($priceSelect == 6) 
		$sql .= " AND price>50";
	
	if ($sort == "0")
		$sql .= " ORDER BY id";
	if ($sort == "1")
		$sql .= " ORDER BY views";
	if ($sort == "2")
		$sql .= " ORDER BY coms";
	if ($sort == "3")
		$sql .= " ORDER BY timely";
	if ($sort == "4")
		$sql .= " ORDER BY credit";
	if ($sort == "5")
		$sql .= " ORDER BY code_rich";
	if ($sort == "6")
		$sql .= " ORDER BY service";

	if ($sortRule == "1")
		$sql .= " DESC";
	if ($sortRule == "2")
		$sql .= " ASC";
}

$start = ($pageNo-1)*$pageNum;
$sql .= " LIMIT {$start},{$pageNum}";
$res = $mysql -> query($sql);
$rows = $res -> fetch_all();

include "../phpClass/Page.class.php";
$page = new Page($pageNo, $allPage);
$page = $page -> create();

echo json_encode([
	"allNum"=>$allNum,
	"allPage"=>$allPage,
	"page"=>$page,
	"rows"=>$rows
]);
