<?php
include "handle.php";

$arr = [];

$sql = "SELECT count(*) FROM ad WHERE is_pass=0";
$res = $mysql -> query($sql);
if ($res)
$res = $res -> fetch_array();
if ($res) $arr["ad"] = $res[0];

$sql = "SELECT count(*) FROM seo WHERE is_pass=0";
$res = $mysql -> query($sql);
if ($res)
$res = $res -> fetch_array();
if ($res) $arr["seo"] = $res[0];


$sql = "SELECT count(*) FROM vps WHERE is_pass=0";
$res = $mysql -> query($sql);
if ($res)
$res = $res -> fetch_array();
if ($res) $arr["vps"] = $res[0];


$sql = "SELECT count(*) FROM app WHERE is_pass=0";
$res = $mysql -> query($sql);
if ($res)
$res = $res -> fetch_array();
if ($res) $arr["app"] = $res[0];

echo json_encode($arr);