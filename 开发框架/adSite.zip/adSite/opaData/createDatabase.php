<?php

if (file_exists("../data/databaseInfo.php"))
	die("数据库信息已经存在！");

$user = @$_POST["user"];
$pwd = @$_POST["pwd"];
$dAdress = @$_POST["dAdress"];
$dName = @$_POST["dName"];
$dUser = @$_POST["dUser"];
$dPwd = @$_POST["dPwd"];

if (!$user || !$pwd || !$dAdress || !$dName || !$dUser || !$dPwd)
	die("数据不全！");

$mysql = new MySQLi($dAdress, $dUser, $dPwd, $dName, 3306);
if ($mysql->connect_errno != 0) {
	die("数据库连接错误！".$mysql->error);
}

$info = json_encode($_POST);
$info = rawurlencode($info);

file_put_contents("../data/databaseInfo.php", "<?php die(\"<img src='../images/csm.jpg'>\");//".$info);

include "../data/createTables.php";

session_start();
$_SESSION["admin"] = true;

die("数据写入成功！");































