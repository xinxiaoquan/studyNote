<?php

$speedStar = @$_GET["speedStar"];
$stableStar = @$_GET["stableStar"];
$serviceStar = @$_GET["serviceStar"];
$priceRatioStar = @$_GET["priceRatioStar"];

include "submitCom.php";

$speedStar = myUrlencode($speedStar);
$stableStar = myUrlencode($stableStar);
$serviceStar = myUrlencode($serviceStar);
$priceRatioStar = myUrlencode($priceRatioStar);

$sql = "INSERT INTO seo_com VALUES(
	null,'{$pId}','{$title}','{$speedStar}','{$stableStar}','{$serviceStar}','{$priceRatioStar}','{$nickname}','{$content}','{$time}','{$ip}','{$area}',0
)";
$mysql -> query($sql);

echo "评论提交成功！请等待管理员审核！";