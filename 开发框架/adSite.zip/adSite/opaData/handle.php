<?php

@session_start();

if (!isset($_SESSION["admin"])) {
	header("location:../");
	exit;
}

if (!file_exists("../data/databaseInfo.php")) {
	header("location:../");
	exit;
}

global $databaseInfo;
global $mysql;
$databaseInfo = file_get_contents("../data/databaseInfo.php");
$databaseInfo = preg_replace('/^<\?.+\/\//', "", $databaseInfo);
$databaseInfo = json_decode(urldecode($databaseInfo));
$mysql = new mySQLi(
	$databaseInfo -> dAdress,
	$databaseInfo -> dUser,
	$databaseInfo -> dPwd,
	$databaseInfo -> dName,
	3306
);

function myUrlencode($data) {
	$data = urlencode($data);
	$data = str_replace("+", "%20", $data);
	return $data;
}
























