<?php

$databaseInfo = file_get_contents("../data/databaseInfo.php");
$databaseInfo = preg_replace('/^<\?.+\/\//', "", $databaseInfo);
$databaseInfo = json_decode(urldecode($databaseInfo));
$mysql = new mySQLi(
	$databaseInfo -> dAdress,
	$databaseInfo -> dUser,
	$databaseInfo -> dPwd,
	$databaseInfo -> dName,
	3306
);

$nickname = @$_GET["nickname"];
$title = @$_GET["title"];
$content = @$_GET["content"];
$captcha = @$_GET["captcha"];
$time = @$_GET["time"];
$ip = @$_GET["ip"];
$pId = @$_GET["pId"];

if (!$nickname || !$title || !$content || !$captcha || !$time || !$ip || !$pId)
	die("数据不全！");

$sql = "SELECT id FROM ip_blacklist WHERE ip='{$ip}'";
$res = $mysql -> query($sql);
if ($res -> fetch_array()) die("提交失败！你已经被管理员封禁！");

$area = file_get_contents("http://whois.pconline.com.cn/ip.jsp?ip={$ip}");
$area = iconv("GBK", "UTF-8", $area);
$area = preg_replace('/\r\n|\r|\n|[ ].*$/', "", $area);
$area = str_replace('省', "省·", $area);

$nickname = myUrlencode($nickname);
$title = myUrlencode($title);
$content = myUrlencode($content);
$captcha = myUrlencode($captcha);
$time = myUrlencode($time);
$ip = myUrlencode($ip);
$area = myUrlencode($area);
$pId = myUrlencode($pId);

session_start();

if ($_SESSION["captcha"] != strtolower($captcha))
	die("验证码错误！");

if (!file_exists("../data/databaseInfo.php")) {
	header("location:../");
	exit;
}

function myUrlencode($data) {
	$data = htmlspecialchars($data);
	$data = addslashes($data);
	$data = urlencode($data);
	$data = str_replace("+", "%20", $data);
	return $data;
}