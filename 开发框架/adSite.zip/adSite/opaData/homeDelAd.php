<?php
$ids = @$_GET["ids"];
if (!$ids) die("数据不全！");

include "handle.php";
include "../phpClass/CreateHtmlTask.class.php";
include "../phpClass/ContentSort.class.php";
include "../phpClass/ContentLatest.class.php";

$webconfig = @file_get_contents("../json/webconfig.json");
if (!$webconfig) $webconfig = ["adDir"=>"ad"];
else $webconfig = json_decode(urldecode($webconfig));

$arr = explode(",", $ids);
$delAd = "";
$delAdCom = "";
for ($i = 0; $i < count($arr); $i++) {
	$delAd .= "id={$arr[$i]} ";
	$delAdCom .= "pId={$arr[$i]} ";
	if ($i != count($arr)-1) {
		$delAd .= "or ";
		$delAdCom .= "or ";
	}
	
	$t = new CreateHtmlTask("ad.ini", "{$arr[$i]}");
	$t -> del();
	
	$path = "../json/contentScore/ad/{$arr[$i]}.json";
	@unlink($path);
	$path = "../json/contentViews/ad/{$arr[$i]}.json";
	@unlink($path);
	$path = "../{$webconfig->adDir}/{$arr[$i]}.html";
	@unlink($path);
	
	$c = new contentSort($arr[$i], "ad_com", "ad");
	$c -> createJson();
}

$sql = "DELETE FROM ad WHERE {$delAd}";
$mysql -> query($sql);
$sql = "DELETE FROM ad_com WHERE {$delAdCom}";
$mysql -> query($sql);

$l = new ContentLatest("ad");
$l -> create();

echo "ok";

























