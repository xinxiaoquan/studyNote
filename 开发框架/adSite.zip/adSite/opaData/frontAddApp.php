<?php
session_start();

if (!isset($_SESSION["user"])
	&& !isset($_SESSION["admin"]))
	die("你没有登录！");
	
$appName = @$_POST["appName"];
$appClass = @$_POST["appClass"];
$appAdType = @$_POST["appAdType"];
$appSettle = @$_POST["appSettle"];
$appQuery = @$_POST["appQuery"];
$appProType = @$_POST["appProType"];
$appPrice = @$_POST["appPrice"];
$appContent = @$_POST["appContent"];
$appContact = @$_POST["appContact"];

if (!$appName || !$appClass || !$appAdType || !$appSettle || !$appQuery || !$appProType || !$appPrice || !$appContent || !$appContact)
	die("数据不全！");

$appName = rawurlencode($appName);
$appClass = rawurlencode($appClass);
$appAdType = rawurlencode($appAdType);
$appSettle = rawurlencode($appSettle);
$appQuery = rawurlencode($appQuery);
$appProType = rawurlencode($appProType);
$appPrice = rawurlencode($appPrice);
$appContent = rawurlencode($appContent);
$appContact = rawurlencode($appContact);
if (!@$_SESSION["user"])
	$user = rawurlencode("admin");
else $user = rawurlencode(@$_SESSION["user"]);

global $databaseInfo;
global $mysql;
$databaseInfo = file_get_contents("../data/databaseInfo.php");
$databaseInfo = preg_replace('/^<\?.+\/\//', "", $databaseInfo);
$databaseInfo = json_decode(urldecode($databaseInfo));
$mysql = new mySQLi(
	$databaseInfo -> dAdress,
	$databaseInfo -> dUser,
	$databaseInfo -> dPwd,
	$databaseInfo -> dName,
	3306
);

$sql = "INSERT INTO app VALUES(
	null,'{$appName}','{$appClass}','{$appAdType}','{$appSettle}','{$appQuery}','{$appProType}','{$appPrice}','{$appContent}','{$appContact}',0,0,0,0,0,0,0,0,'{$user}'
)";
$mysql -> query($sql);

$id = $mysql->insert_id;
echo "添加一条APP信息成功！\r\n";
echo "新添加APP的ID：{$id}";

































