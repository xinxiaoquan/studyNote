<?php
include "handle.php";

$appName = @$_POST["appName"];
$appClass = @$_POST["appClass"];
$appAdType = @$_POST["appAdType"];
$appSettle = @$_POST["appSettle"];
$appQuery = @$_POST["appQuery"];
$appProType = @$_POST["appProType"];
$appPrice = @$_POST["appPrice"];
$appContent = @$_POST["appContent"];
$appContact = @$_POST["appContact"];
$time = @$_POST["time"];

if (!$appName || !$appClass || !$appAdType || !$appSettle || !$appQuery || !$appProType || !$appPrice || !$appContent || !$appContact || !$time)
	die("数据不全！");

$appName = myUrlencode($appName);
$appClass = myUrlencode($appClass);
$appAdType = myUrlencode($appAdType);
$appSettle = myUrlencode($appSettle);
$appQuery = myUrlencode($appQuery);
$appProType = myUrlencode($appProType);
$appPrice = myUrlencode($appPrice);
$appContent = myUrlencode($appContent);
$appContact = myUrlencode($appContact);
$time = myUrlencode($time);
$user = myUrlencode("admin");

$sql = "INSERT INTO app VALUES(
	null,'{$appName}','{$appClass}','{$appAdType}','{$appSettle}','{$appQuery}','{$appProType}','{$appPrice}','{$appContent}','{$appContact}','{$time}',0,0,0,0,0,0,1,'{$user}'
)";
$mysql -> query($sql);

$id = $mysql->insert_id;
echo "添加一条APP信息成功！\r\n";
echo "新添加APP的ID：{$id}";

include "../phpClass/CreateHtmlTask.class.php";
$t = new CreateHtmlTask("app.ini", "{$id}");
$t -> add();

include "../phpClass/ContentLatest.class.php";
$l = new ContentLatest("app");
$l -> create();




































