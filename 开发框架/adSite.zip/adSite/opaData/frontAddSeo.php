<?php
session_start();

if (!isset($_SESSION["user"])
	&& !isset($_SESSION["admin"]))
	die("你没有登录！");

$seoName = @$_POST["seoName"];
$seoUrl = @$_POST["seoUrl"];
$seoAdress = @$_POST["seoAdress"];
$seoMobile = @$_POST["seoMobile"];
$seoQQ = @$_POST["seoQQ"];
$seoWX = @$_POST["seoWX"];
$seoRecommend = @$_POST["seoRecommend"];
$seoType = @$_POST["seoType"];
$seoClass = @$_POST["seoClass"];
$seoArea = @$_POST["seoArea"];
$seoQuality = @$_POST["seoQuality"];

if (!$seoName || !$seoUrl || !$seoAdress || !$seoMobile || !$seoQQ || !$seoWX || !$seoRecommend || !$seoType || !$seoClass || !$seoArea || !$seoQuality)
	die("数据不全！");

$seoName = rawurlencode($seoName);
$seoUrl = rawurlencode($seoUrl);
$seoAdress = rawurlencode($seoAdress);
$seoMobile = rawurlencode($seoMobile);
$seoQQ = rawurlencode($seoQQ);
$seoWX = rawurlencode($seoWX);
$seoRecommend = rawurlencode($seoRecommend);
$seoType = rawurlencode($seoType);
$seoClass = rawurlencode($seoClass);
$seoArea = rawurlencode($seoArea);
$seoQuality = rawurlencode($seoQuality);
if (!@$_SESSION["user"])
	$user = rawurlencode("admin");
else $user = rawurlencode(@$_SESSION["user"]);

global $databaseInfo;
global $mysql;
$databaseInfo = file_get_contents("../data/databaseInfo.php");
$databaseInfo = preg_replace('/^<\?.+\/\//', "", $databaseInfo);
$databaseInfo = json_decode(urldecode($databaseInfo));
$mysql = new mySQLi(
	$databaseInfo -> dAdress,
	$databaseInfo -> dUser,
	$databaseInfo -> dPwd,
	$databaseInfo -> dName,
	3306
);

$sql = "INSERT INTO seo VALUES(
	null,'{$seoName}','{$seoUrl}','{$seoAdress}','{$seoMobile}','{$seoQQ}','{$seoWX}','{$seoRecommend}','{$seoType}','{$seoClass}','{$seoArea }','{$seoQuality}',0,0,0,0,0,0,0,0,'{$user}'
)";
$mysql -> query($sql);

$id = $mysql -> insert_id;
echo "添加一条SEO服务成功！\r\n";
echo "新添加SEO服务的ID：".$mysql->insert_id;


































