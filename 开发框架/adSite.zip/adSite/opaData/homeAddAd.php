<?php
include "handle.php";

$adName = @$_POST["adName"];
$adUrl = @$_POST["adUrl"];
$adRecommend = @$_POST["adRecommend"];
$adPayCycle = @$_POST["adPayCycle"];
$adStartPay = @$_POST["adStartPay"];
$adType = @$_POST["adType"];
$adDisplay = @$_POST["adDisplay"];
$time = @$_POST["time"];

if (!$adName || !$adUrl || !$adRecommend || !$adPayCycle || !$adStartPay || !$adType || !$adDisplay || !$time)
	die("数据不全！");

$adName = myUrlencode($adName);
$adUrl = myUrlencode($adUrl);
$adRecommend = myUrlencode($adRecommend);
$adPayCycle = myUrlencode($adPayCycle);
$adStartPay = myUrlencode($adStartPay);
$adType = myUrlencode($adType);
$adDisplay = myUrlencode($adDisplay);
$time = myUrlencode($time);
$user = myUrlencode("admin");

$sql = "INSERT INTO ad VALUES(
	null,'{$adName}','{$adUrl}','{$adRecommend}','{$adPayCycle}','{$adStartPay}','{$adType}','{$adDisplay}','{$time}',0,0,0,0,0,0,1,'{$user}'
)";
$mysql -> query($sql);

$id = $mysql->insert_id;
echo "添加一条广告联盟信息成功！\r\n";
echo "新添加联盟的ID：{$id}";

include "../phpClass/CreateHtmlTask.class.php";
$t = new CreateHtmlTask("ad.ini", "{$id}");
$t -> add();

include "../phpClass/ContentLatest.class.php";
$l = new ContentLatest("ad");
$l -> create();


































