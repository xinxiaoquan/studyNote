<?php
include "handle.php";

$vpsId = @$_POST["vpsId"];
$vpsName = @$_POST["vpsName"];
$vpsAdress = @$_POST["vpsAdress"];
$vpsRoom = @$_POST["vpsRoom"];
$vpsLine = @$_POST["vpsLine"];
$vpsClass = @$_POST["vpsClass"];
$vpsType = @$_POST["vpsType"];
$vpsVpsClass = @$_POST["vpsVpsClass"];
$vpsUrl = @$_POST["vpsUrl"];
$vpsRecommend = @$_POST["vpsRecommend"];

if (!$vpsId || !$vpsName || !$vpsAdress || !$vpsRoom || !$vpsLine || !$vpsClass || !$vpsType || !$vpsVpsClass || !$vpsUrl || !$vpsRecommend)
	die("数据不全！");

$vpsName = myUrlencode($vpsName);
$vpsAdress = myUrlencode($vpsAdress);
$vpsRoom = myUrlencode($vpsRoom);
$vpsLine = myUrlencode($vpsLine);
$vpsClass = myUrlencode($vpsClass);
$vpsType = myUrlencode($vpsType);
$vpsVpsClass = myUrlencode($vpsVpsClass);
$vpsUrl = myUrlencode($vpsUrl);
$vpsRecommend = myUrlencode($vpsRecommend);

$sql = "UPDATE vps SET name='{$vpsName}',adress='{$vpsAdress}',room='{$vpsRoom}',line='{$vpsLine}',class='{$vpsClass}',type='{$vpsType}',vps_class='{$vpsVpsClass}',url='{$vpsUrl}',recommend='{$vpsRecommend}' WHERE id={$vpsId}";
$mysql -> query($sql);

echo "修改一条VPS信息成功！";

include "../phpClass/CreateHtmlTask.class.php";
$t = new CreateHtmlTask("vps.ini", "{$vpsId}");
$t -> add();



































