<?php
$ids = @$_GET["ids"];
if (!$ids) die("数据不全！");

include "handle.php";
include "../phpClass/CreateHtmlTask.class.php";
include "../phpClass/ContentSort.class.php";
include "../phpClass/ContentLatest.class.php";

$webconfig = @file_get_contents("../json/webconfig.json");
if (!$webconfig) $webconfig = ["seoDir"=>"seo"];
else $webconfig = json_decode(urldecode($webconfig));

$arr = explode(",", $ids);
$delSeo = "";
$delSeoCom = "";
for ($i = 0; $i < count($arr); $i++) {
	$delSeo .= "id={$arr[$i]} ";
	$delSeoCom .= "pId={$arr[$i]} ";
	if ($i != count($arr)-1) {
		$delSeo .= "or ";
		$delSeoCom .= "or ";
	}
	
	$t = new CreateHtmlTask("seo.ini", "{$arr[$i]}");
	$t -> del();
	
	$path = "../json/contentScore/seo/{$arr[$i]}.json";
	@unlink($path);
	$path = "../json/contentViews/seo/{$arr[$i]}.json";
	@unlink($path);
	$path = "../{$webconfig->seoDir}/{$arr[$i]}.html";
	@unlink($path);
	
	$c = new contentSort($arr[$i], "seo_com", "seo");
	$c -> createJson();
}

$sql = "DELETE FROM seo WHERE {$delSeo}";
$mysql -> query($sql);
$sql = "DELETE FROM seo_com WHERE {$delSeoCom}";
$mysql -> query($sql);

$l = new ContentLatest("seo");
$l -> create();

echo "ok";























