<?php
include "handle.php";

$vpsName = @$_POST["vpsName"];
$vpsAdress = @$_POST["vpsAdress"];
$vpsRoom = @$_POST["vpsRoom"];
$vpsLine = @$_POST["vpsLine"];
$vpsClass = @$_POST["vpsClass"];
$vpsType = @$_POST["vpsType"];
$vpsVpsClass = @$_POST["vpsVpsClass"];
$vpsUrl = @$_POST["vpsUrl"];
$vpsRecommend = @$_POST["vpsRecommend"];
$time = @$_POST["time"];

if (!$vpsName || !$vpsAdress || !$vpsRoom || !$vpsLine || !$vpsClass || !$vpsType || !$vpsVpsClass || !$vpsUrl || !$vpsRecommend || !$time)
	die("数据不全！");

$vpsName = myUrlencode($vpsName);
$vpsAdress = myUrlencode($vpsAdress);
$vpsRoom = myUrlencode($vpsRoom);
$vpsLine = myUrlencode($vpsLine);
$vpsClass = myUrlencode($vpsClass);
$vpsType = myUrlencode($vpsType);
$vpsVpsClass = myUrlencode($vpsVpsClass);
$vpsUrl = myUrlencode($vpsUrl);
$vpsRecommend = myUrlencode($vpsRecommend);
$time = myUrlencode($time);
$user = myUrlencode("admin");

$sql = "INSERT INTO vps VALUES(
	null,'{$vpsName}','{$vpsAdress}','{$vpsRoom}','{$vpsLine}','{$vpsClass}','{$vpsType}','{$vpsVpsClass}','{$vpsUrl}','{$vpsRecommend}','{$time}',0,0,0,0,0,0,0,1,'{$user}'
)";
$mysql -> query($sql);

$id = $mysql->insert_id;
echo "添加一条VPS信息成功！\r\n";
echo "新添加VPS的ID：{$id}";

include "../phpClass/CreateHtmlTask.class.php";
$t = new CreateHtmlTask("vps.ini", "{$id}");
$t -> add();

include "../phpClass/ContentLatest.class.php";
$l = new ContentLatest("vps");
$l -> create();




































