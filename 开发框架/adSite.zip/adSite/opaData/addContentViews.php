<?php
$id = @$_GET["id"];
$type = @$_GET["type"];

if (!$id || !$type) exit;

$id = filter($id);
if (!is_numeric($id))
	exit;
$type = filter($type);
if ($type != "ad" &&
	$type != "seo" &&
	$type != "app" &&
	$type != "vps")
	exit;

function filter($str) {
	if ($str === null) return null;
	return preg_replace("/\s/", "", $str);
}

$vPath = "../json/contentViews/{$type}/";
$vSort = "../json/contentViewsSort/";

if (!is_dir($vPath)) mkdir($vPath, "0777", true);
if (!is_dir($vSort)) mkdir($vSort, "0777", true);

$path = "{$vPath}{$id}.json";
if (!file_exists($path)) {
	$views = 1;
	file_put_contents($path, 1);
} else {
	$views = file_get_contents($path);
	$views++;
	file_put_contents($path, $views);
}

//按人气排序
$time = time();
if (!file_exists($vSort."timestamp.ini")) {
	file_put_contents($vSort."timestamp.ini", $time);
} else {
	$oldTime = file_get_contents($vSort."timestamp.ini");
	if ($time - $oldTime >= 3600) {
		file_put_contents($vSort."timestamp.ini", $time);
		$arr = [];
		$dir = opendir($vPath);
		while ($file = readdir($dir)) {
			if ($file == "." || $file == "..")
				continue;
			$id = str_replace(".json", "", $file);
			$num = file_get_contents($vPath.$file);
			$arr[$id] = $num;
		}
		arsort($arr);
		$newArr = [];
		$index = 0;
		foreach ($arr as $key=>$val) {
			$newArr[] = [
				"id"=>$key,
				"views"=>$val
			];
			if (++$index >= 10) return;
		}
		$json = json_encode($newArr);
		file_put_contents($vSort.$type.".json", $json);
		
		global $databaseInfo;
		global $mysql;
		$databaseInfo = file_get_contents("../data/databaseInfo.php");
		$databaseInfo = preg_replace('/^<\?.+\/\//', "", $databaseInfo);
		$databaseInfo = json_decode(urldecode($databaseInfo));
		$mysql = new mySQLi(
			$databaseInfo -> dAdress,
			$databaseInfo -> dUser,
			$databaseInfo -> dPwd,
			$databaseInfo -> dName,
			3306
		);
		$sql = "UPDATE {$type} SET views={$views} WHERE id={$id}";
		$mysql -> query($sql);
	}
}

































