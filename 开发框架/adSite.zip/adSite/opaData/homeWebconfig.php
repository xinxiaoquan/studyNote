<?php
include "handle.php";

$indexPage = @$_POST["indexPage"];
$webRoot = @$_POST["webRoot"];
$adDir = @$_POST["adDir"];
$adTitle = @$_POST["adTitle"];
$adCopyright = @$_POST["adCopyright"];
$seoDir = @$_POST["seoDir"];
$seoTitle = @$_POST["seoTitle"];
$seoCopyright = @$_POST["seoCopyright"];
$appDir = @$_POST["appDir"];
$appTitle = @$_POST["appTitle"];
$appCopyright = @$_POST["appCopyright"];
$vpsDir = @$_POST["vpsDir"];
$vpsTitle = @$_POST["vpsTitle"];
$vpsCopyright = @$_POST["vpsCopyright"];

if (!$indexPage || !$adDir || !$adTitle || !$adCopyright || !$seoDir || !$seoTitle || !$seoCopyright || !$appDir || !$appTitle || !$appCopyright || !$vpsDir || !$vpsTitle || !$vpsCopyright || !$webRoot) {
	die("数据不全！");
}

$_POST["adCopyright"] = str_replace("\n", "<br/>", $adCopyright);
$_POST["seoCopyright"] = str_replace("\n", "<br/>", $seoCopyright);
$_POST["appCopyright"] = str_replace("\n", "<br/>", $appCopyright);
$_POST["vpsCopyright"] = str_replace("\n", "<br/>", $vpsCopyright);

$webconfig = @file_get_contents("../json/webconfig.json");
if (!$webconfig)
	mkdirs();
else {
	$webconfig = json_decode(urldecode($webconfig));

	@unlink("../com/{$webconfig->adDir}.html");
	@unlink("../com/{$webconfig->seoDir}.html");
	@unlink("../com/{$webconfig->appDir}.html");
	@unlink("../com/{$webconfig->vpsDir}.html");
	@unlink("../info/{$webconfig->adDir}.html");
	@unlink("../info/{$webconfig->seoDir}.html");
	@unlink("../info/{$webconfig->appDir}.html");
	@unlink("../info/{$webconfig->vpsDir}.html");

	if (!is_dir("../{$webconfig->adDir}"))
		mkdir("../{$adDir}");
	else rename("../{$webconfig->adDir}", "../{$adDir}");
	
	if (!is_dir("../{$webconfig->seoDir}"))
		mkdir("../{$seoDir}");
	else rename("../{$webconfig->seoDir}", "../{$seoDir}");
	
	if (!is_dir("../{$webconfig->appDir}"))
		mkdir("../{$appDir}");
	else rename("../{$webconfig->appDir}", "../{$appDir}");
	
	if (!is_dir("../{$webconfig->vpsDir}"))
		mkdir("../{$vpsDir}");
	else rename("../{$webconfig->vpsDir}", "../{$vpsDir}");
}

function mkdirs() {
	mkdir("../{$adDir}");
	mkdir("../{$seoDir}");
	mkdir("../{$appDir}");
	mkdir("../{$vpsDir}");
	mkdir("../com/");
	mkdir("../info/");
}

$data = json_encode($_POST);
$data = myUrlencode($data);
file_put_contents("../json/webconfig.json", $data);

echo "数据写入成功！";



































