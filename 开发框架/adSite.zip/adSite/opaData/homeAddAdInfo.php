<?php
include "handle.php";

$title = @$_POST["title"];
$time = @$_POST["time"];
$content = @$_POST["content"];

if (!$title || !$time || !$content)
	die("数据不全！");

$title = myUrlencode($title);
$time = myUrlencode($time);
$content = myUrlencode($content);

$sql = "INSERT INTO ad_info VALUES(null, '{$title}', '{$time}', '{$content}')";
$mysql->query($sql);

$id = $mysql->insert_id;
echo "添加一条广告联盟资讯成功！\r\n";
echo "新添加资讯的ID：{$id}";
