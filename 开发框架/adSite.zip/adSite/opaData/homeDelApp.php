<?php
$ids = @$_GET["ids"];
if (!$ids) die("数据不全！");

include "handle.php";
include "../phpClass/CreateHtmlTask.class.php";
include "../phpClass/ContentSort.class.php";
include "../phpClass/ContentLatest.class.php";

$webconfig = @file_get_contents("../json/webconfig.json");
if (!$webconfig) $webconfig = ["appDir"=>"app"];
else $webconfig = json_decode(urldecode($webconfig));

$arr = explode(",", $ids);
$delApp = "";
$delAppCom = "";
for ($i = 0; $i < count($arr); $i++) {
	$delApp .= "id={$arr[$i]} ";
	$delAppCom .= "pId={$arr[$i]} ";
	if ($i != count($arr)-1) {
		$delApp .= "or ";
		$delAppCom .= "or ";
	}
	
	$t = new CreateHtmlTask("app.ini", "{$arr[$i]}");
	$t -> del();
	
	$path = "../json/contentScore/app/{$arr[$i]}.json";
	@unlink($path);
	$path = "../json/contentViews/app/{$arr[$i]}.json";
	@unlink($path);
	$path = "../{$webconfig->appDir}/{$arr[$i]}.html";
	@unlink($path);
	
	$c = new contentSort($arr[$i], "app_com", "app");
	$c -> createJson();
}

$sql = "DELETE FROM app WHERE {$delApp}";
$mysql -> query($sql);
$sql = "DELETE FROM app_com WHERE {$delAppCom}";
$mysql -> query($sql);

$l = new ContentLatest("app");
$l -> create();

echo "ok";





























