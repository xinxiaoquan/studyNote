<?php
include "handle.php";

$arr = [];

$sql = "SELECT count(*) FROM ad_com WHERE is_pass=0";
$res = $mysql -> query($sql);
$res = $res -> fetch_array();
if ($res) $arr["ad"] = $res[0];

$sql = "SELECT count(*) FROM seo_com WHERE is_pass=0";
$res = $mysql -> query($sql);
$res = $res -> fetch_array();
if ($res) $arr["seo"] = $res[0];


$sql = "SELECT count(*) FROM vps_com WHERE is_pass=0";
$res = $mysql -> query($sql);
$res = $res -> fetch_array();
if ($res) $arr["vps"] = $res[0];


$sql = "SELECT count(*) FROM app_com WHERE is_pass=0";
$res = $mysql -> query($sql);
$res = $res -> fetch_array();
if ($res) $arr["app"] = $res[0];


echo json_encode($arr);

















