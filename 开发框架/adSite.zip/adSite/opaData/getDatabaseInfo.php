<?php
include "handle.php";

echo json_encode($databaseInfo);