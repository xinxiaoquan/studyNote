<?php
session_start();

if (!isset($_SESSION["user"])
	&& !isset($_SESSION["admin"]))
	die("你没有登录！");
	
$vpsName = @$_POST["vpsName"];
$vpsAdress = @$_POST["vpsAdress"];
$vpsRoom = @$_POST["vpsRoom"];
$vpsLine = @$_POST["vpsLine"];
$vpsClass = @$_POST["vpsClass"];
$vpsType = @$_POST["vpsType"];
$vpsVpsClass = @$_POST["vpsVpsClass"];
$vpsUrl = @$_POST["vpsUrl"];
$vpsRecommend = @$_POST["vpsRecommend"];
$captcha = @$_POST["captcha"];

if (!$vpsName || !$vpsAdress || !$vpsRoom || !$vpsLine || !$vpsClass || !$vpsType || !$vpsVpsClass || !$vpsUrl || !$vpsRecommend || !$captcha)
	die("数据不全！");

if (@$_SESSION["captcha"] != strtolower($captcha))
	die("验证码错误！");

$vpsName = rawurlencode($vpsName);
$vpsAdress = rawurlencode($vpsAdress);
$vpsRoom = rawurlencode($vpsRoom);
$vpsLine = rawurlencode($vpsLine);
$vpsClass = rawurlencode($vpsClass);
$vpsType = rawurlencode($vpsType);
$vpsVpsClass = rawurlencode($vpsVpsClass);
$vpsUrl = rawurlencode($vpsUrl);
$vpsRecommend = rawurlencode($vpsRecommend);
if (!@$_SESSION["user"])
	$user = rawurlencode("admin");
else $user = rawurlencode(@$_SESSION["user"]);

global $databaseInfo;
global $mysql;
$databaseInfo = file_get_contents("../data/databaseInfo.php");
$databaseInfo = preg_replace('/^<\?.+\/\//', "", $databaseInfo);
$databaseInfo = json_decode(urldecode($databaseInfo));
$mysql = new mySQLi(
	$databaseInfo -> dAdress,
	$databaseInfo -> dUser,
	$databaseInfo -> dPwd,
	$databaseInfo -> dName,
	3306
);

$sql = "INSERT INTO vps VALUES(
	null,'{$vpsName}','{$vpsAdress}','{$vpsRoom}','{$vpsLine}','{$vpsClass}','{$vpsType}','{$vpsVpsClass}','{$vpsUrl}','{$vpsRecommend}',0,0,0,0,0,0,0,0,0,'{$user}'
)";
$mysql -> query($sql);

$id = $mysql->insert_id;
echo "添加一条VPS信息成功！\r\n";
echo "新添加VPS的ID：{$id}";


























