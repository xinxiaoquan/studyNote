<?php
include "handle.php";

$id = @$_GET["id"];
$table = @$_GET["table"];
$id = filter($id);
$table = filter($table);

if (!$id || !$table)
	die("数据不全！");

function filter($str) {
	if ($str === null) return null;
	return preg_replace("/\s/", "", $str);
}

if (isset($_GET["allData"])) {
	$pass = "";
} else $pass = " AND is_pass=1";

$sql = "SELECT * FROM {$table} WHERE id={$id} {$pass}";
$res = $mysql -> query($sql);
$arr = $res -> fetch_object();

echo myUrlencode(json_encode($arr));



























