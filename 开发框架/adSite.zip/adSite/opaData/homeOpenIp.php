<?php
include "handle.php";

$ids = @$_GET["ids"];
if (!$ids) die("数据不全！");

$arr = explode(",", $ids);
$str = "";
for ($i = 0; $i < count($arr); $i++) {
	$str .= "id={$arr[$i]} ";
	if ($i != count($arr)-1) $str .= "or ";
}

$sql = "DELETE FROM ip_blacklist WHERE {$str}";
$mysql -> query($sql);

echo "ok";