<?php
session_start();

if (!isset($_SESSION["user"])
	&& !isset($_SESSION["admin"]))
	die("你没有登录！");

$adName = @$_POST["adName"];
$adUrl = @$_POST["adUrl"];
$adRecommend = @$_POST["adRecommend"];
$adPayCycle = @$_POST["adPayCycle"];
$adStartPay = @$_POST["adStartPay"];
$adType = @$_POST["adType"];
$adDisplay = @$_POST["adDisplay"];
$captcha = @$_POST["captcha"];

if (!$adName || !$adUrl || !$adRecommend || !$adPayCycle || !$adStartPay || !$adType || !$adDisplay || !$captcha)
	die("数据不全！");

if (@$_SESSION["captcha"] != strtolower($captcha))
	die("验证码错误！");

$adName = rawurlencode($adName);
$adUrl = rawurlencode($adUrl);
$adRecommend = rawurlencode($adRecommend);
$adPayCycle = rawurlencode($adPayCycle);
$adStartPay = rawurlencode($adStartPay);
$adType = rawurlencode($adType);
$adDisplay = rawurlencode($adDisplay);
if (!@$_SESSION["user"])
	$user = rawurlencode("admin");
else $user = rawurlencode(@$_SESSION["user"]);

global $databaseInfo;
global $mysql;
$databaseInfo = file_get_contents("../data/databaseInfo.php");
$databaseInfo = preg_replace('/^<\?.+\/\//', "", $databaseInfo);
$databaseInfo = json_decode(urldecode($databaseInfo));
$mysql = new mySQLi(
	$databaseInfo -> dAdress,
	$databaseInfo -> dUser,
	$databaseInfo -> dPwd,
	$databaseInfo -> dName,
	3306
);

$sql = "INSERT INTO ad VALUES(
	null,'{$adName}','{$adUrl}','{$adRecommend}','{$adPayCycle}','{$adStartPay}','{$adType}','{$adDisplay}',0,0,0,0,0,0,0,0,'{$user}'
)";
$mysql -> query($sql);

$id = $mysql->insert_id;
echo "添加一条广告联盟信息成功！请等待管理员审核！\r\n";
echo "新添加联盟的ID：{$id}";




































