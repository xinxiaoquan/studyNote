<?php
include "handle.php";

$type = @$_GET["type"];
if (!$type) exit;

$task = "";
if ($type == "ad")
	if (file_exists("../json/createHtml/ad.ini"))
		$task = file_get_contents("../json/createHtml/ad.ini");
if ($type == "seo")
	if (file_exists("../json/createHtml/seo.ini"))
		$task = file_get_contents("../json/createHtml/seo.ini");
if ($type == "app")
	if (file_exists("../json/createHtml/app.ini"))
		$task = file_get_contents("../json/createHtml/app.ini");
if ($type == "vps")
	if (file_exists("../json/createHtml/vps.ini"))
		$task = file_get_contents("../json/createHtml/vps.ini");

echo $task;





































