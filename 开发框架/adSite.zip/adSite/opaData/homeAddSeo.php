<?php
include "handle.php";

$seoName = @$_POST["seoName"];
$seoUrl = @$_POST["seoUrl"];
$seoAdress = @$_POST["seoAdress"];
$seoMobile = @$_POST["seoMobile"];
$seoQQ = @$_POST["seoQQ"];
$seoWX = @$_POST["seoWX"];
$seoRecommend = @$_POST["seoRecommend"];
$seoType = @$_POST["seoType"];
$seoClass = @$_POST["seoClass"];
$seoArea = @$_POST["seoArea"];
$seoQuality = @$_POST["seoQuality"];
$time = @$_POST["time"];


if (!$seoName || !$seoUrl || !$seoAdress || !$seoMobile || !$seoQQ || !$seoWX || !$seoRecommend || !$seoType || !$seoClass || !$seoArea || !$seoQuality || !$time)
	die("数据不全！");

$seoName = myUrlencode($seoName);
$seoUrl = myUrlencode($seoUrl);
$seoAdress = myUrlencode($seoAdress);
$seoMobile = myUrlencode($seoMobile);
$seoQQ = myUrlencode($seoQQ);
$seoWX = myUrlencode($seoWX);
$seoRecommend = myUrlencode($seoRecommend);
$seoType = myUrlencode($seoType);
$seoClass = myUrlencode($seoClass);
$seoArea = myUrlencode($seoArea);
$seoQuality = myUrlencode($seoQuality);
$time = myUrlencode($time);
$user = myUrlencode("admin");

$sql = "INSERT INTO seo VALUES(
	null,'{$seoName}','{$seoUrl}','{$seoAdress}','{$seoMobile}','{$seoQQ}','{$seoWX}','{$seoRecommend}','{$seoType}','{$seoClass}','{$seoArea }','{$seoQuality}','{$time}',0,0,0,0,0,0,1,'{$user}'
)";
$mysql -> query($sql);

$id = $mysql -> insert_id;
echo "添加一条SEO服务成功！\r\n";
echo "新添加SEO服务的ID：".$mysql->insert_id;

include "../phpClass/CreateHtmlTask.class.php";
$t = new CreateHtmlTask("seo.ini", "{$id}");
$t -> add();

include "../phpClass/ContentLatest.class.php";
$l = new ContentLatest("seo");
$l -> create();






