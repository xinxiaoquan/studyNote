<?php
include "handle.php";

$adId = @$_POST["adId"];
$adName = @$_POST["adName"];
$adUrl = @$_POST["adUrl"];
$adRecommend = @$_POST["adRecommend"];
$adPayCycle = @$_POST["adPayCycle"];
$adStartPay = @$_POST["adStartPay"];
$adType = @$_POST["adType"];
$adDisplay = @$_POST["adDisplay"];

if (!$adId || !$adName || !$adUrl || !$adRecommend || !$adPayCycle || !$adStartPay || !$adType || !$adDisplay)
	die("数据不全！");

$adName = myUrlencode($adName);
$adUrl = myUrlencode($adUrl);
$adRecommend = myUrlencode($adRecommend);
$adPayCycle = myUrlencode($adPayCycle);
$adStartPay = myUrlencode($adStartPay);
$adType = myUrlencode($adType);
$adDisplay = myUrlencode($adDisplay);

$sql = "UPDATE ad SET name='{$adName}',url='{$adUrl}',recommend='{$adRecommend}',pay_cycle='{$adPayCycle}',start_pay='{$adStartPay}',type='{$adType}',display='{$adDisplay}' WHERE id={$adId}";
$mysql -> query($sql);

echo "修改一条广告联盟信息成功！";

include "../phpClass/CreateHtmlTask.class.php";
$t = new CreateHtmlTask("ad.ini", "{$adId}");
$t -> add();





































