<?php
include "handle.php";

$link = @$_POST["link"];

if (!$link)
	die("数据不全！");

if (!$_FILES) die("图片没有上传！");
if ($_FILES["img"]["size"] >= 1024*1024)
	die("图片大小不要超过1M！");
$imgName = preg_replace('/\..*?$/', '', $_FILES["img"]["name"]);
$type = str_replace('image/', '', $_FILES["img"]["type"]);
$imgName = $imgName."_".time().".".$type;
$imgPath = "../images/siteImg/";
if (!is_dir($imgPath)) mkdir($imgPath);
$dir = opendir($imgPath);
while ($file = readdir($dir)) {
	if ($file != "." && $file != "..")
		unlink($imgPath.$file);
}
closedir($dir);
move_uploaded_file($_FILES["img"]["tmp_name"], $imgPath.$imgName);

$json = myUrlencode("{\"img\":\"{$imgName}\",\"link\":\"{$link}\"}");
file_put_contents("../json/siteImgAd.json", $json);

echo "全站图文广告添加成功！";






























