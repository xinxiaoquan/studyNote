<?php
include "handle.php";

$select = @$_POST["select"];
$position = @$_POST["position"];
if (!$select || $position === null)
	die("数据不全");

$subs = explode(" ", $position);

$imgPath = null;
if ($select == "text")
	$json = @file_get_contents("../json/appTextAd.json");
else if ($select == "img") {
	$imgPath = "../images/appImg/";
	$json = @file_get_contents("../json/appImgAd.json");
} else if ($select == "contentImg") {
	$imgPath = "../images/appContentImg/";
	$json = @file_get_contents("../json/appContentImgAd.json");
} else die("参数错误！");
if (!$json) die("数据为空，无法删除！");
else $json = urldecode($json);
$data = json_decode($json);

$dataLength = count($data);
if ($dataLength == 0)
	die("数据为空，无法删除！");
$subLength = count($subs);
$newData = [];
for ($i = 0; $i < $dataLength; $i++) {
	for ($j = 0; $j < $subLength; $j++) {
		$sub = $subs[$j]-1;
		if ($sub < 0) $sub = 0;
		if ($sub >= $dataLength) $sub = $dataLength-1;
		if ($sub == $i) {
			if ($select == "img" || $select == "contentImg") {
				$imgName = $data[$sub][0];
				if ($imgPath && file_exists($imgPath.$imgName))
					unlink($imgPath.$imgName);
			}
			break;
		}
	}
	if ($j == $subLength)
		$newData[] = $data[$i];
}

$json = myUrlencode(json_encode($newData));
if ($select == "text")
	file_put_contents("../json/appTextAd.json", $json);
if ($select == "img")
	file_put_contents("../json/appImgAd.json", $json);
if ($select == "contentImg")
	file_put_contents("../json/appContentImgAd.json", $json);

echo "{$position} 条数据删除完成！";



























