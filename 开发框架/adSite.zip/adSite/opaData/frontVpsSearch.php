<?php

$adress = filter(@$_GET["adress"]);
$room = filter(@$_GET["room"]);
$line = filter(@$_GET["line"]);
$class = filter(@$_GET["class"]);
$type = filter(@$_GET["type"]);
$vpsClass = filter(@$_GET["vpsClass"]);
$sort = filter(@$_GET["sort"]);
$sortRule = filter(@$_GET["sortRule"]);
$query = filter(@$_GET["query"]);
$pageNo = filter(@$_GET["pageNo"]);
$pageNum = filter(@$_GET["pageNum"]);

if ($pageNo == null) $pageNo = 1;
if ($pageNum == null) $pageNum = 50;

if ($query == null)
	$query = "";
else $query = "name LIKE '%{$query}%' AND";
if (isset($_GET["simple"]))
	$simple = true;
else $simple = false;

function filter($str) {
	if ($str === null) return null;
	$str = rawurlencode($str);
	return preg_replace("/\s/", "", $str);
}

global $databaseInfo;
global $mysql;
$databaseInfo = file_get_contents("../data/databaseInfo.php");
$databaseInfo = preg_replace('/^<\?.+\/\//', "", $databaseInfo);
$databaseInfo = json_decode(urldecode($databaseInfo));
$mysql = new mySQLi(
	$databaseInfo -> dAdress,
	$databaseInfo -> dUser,
	$databaseInfo -> dPwd,
	$databaseInfo -> dName,
	3306
);

if ($simple)
	$sql = "SELECT COUNT(*) FROM vps WHERE {$query} is_pass=1";
else
	$sql = "SELECT COUNT(*) FROM vps WHERE {$query} is_pass=1 AND adress='{$adress}' AND room='{$room}' AND line='{$line}' AND class='{$class}' AND type='{$type}' AND vps_class='{$vpsClass}'";
$res = $mysql -> query($sql);

$allNum = $res -> fetch_array()[0];
$allPage = ceil($allNum/$pageNum);

if ($simple)
	$sql = "SELECT id,name,coms FROM vps WHERE {$query} is_pass=1 ORDER BY id DESC";
else {
	$sql = "SELECT COUNT(*) FROM vps WHERE {$query} is_pass=1 AND adress='{$adress}' AND room='{$room}' AND line='{$line}' AND class='{$class}' AND type='{$type}' AND vps_class='{$vpsClass}'";
	
	if ($sort == "0")
		$sql .= " ORDER BY id";
	if ($sort == "1")
		$sql .= " ORDER BY views";
	if ($sort == "2")
		$sql .= " ORDER BY coms";
	if ($sort == "3")
		$sql .= " ORDER BY fast";
	if ($sort == "4")
		$sql .= " ORDER BY service";
	if ($sort == "5")
		$sql .= " ORDER BY security";
	if ($sort == "6")
		$sql .= " ORDER BY high_safety";

	if ($sortRule == "1")
		$sql .= " DESC";
	if ($sortRule == "2")
		$sql .= " ASC";
}

$start = ($pageNo-1)*$pageNum;
$sql .= " LIMIT {$start},{$pageNum}";

$res = $mysql -> query($sql);
$rows = $res -> fetch_all();

include "../phpClass/Page.class.php";
$page = new Page($pageNo, $allPage);
$page = $page -> create();

echo json_encode([
	"allNum"=>$allNum,
	"allPage"=>$allPage,
	"page"=>$page,
	"rows"=>$rows
]);




























