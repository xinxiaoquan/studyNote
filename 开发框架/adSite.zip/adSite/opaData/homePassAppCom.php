<?php
include "handle.php";
include "../phpClass/ContentSort.class.php";

$ids = @$_GET["ids"];

$arr = explode(",", $ids);
for ($i = 0; $i < count($arr); $i++) {
	$sql = "UPDATE app_com SET is_pass=1 WHERE id={$arr[$i]}";
	$mysql -> query($sql);
	
	$sql = "SELECT pId FROM app_com WHERE id='{$arr[$i]}'";
	$res = $mysql -> query($sql);
	$res = $res -> fetch_array();
	$pId = $res[0];
	
	$c = new ContentSort($pId,"app_com","app");
	$c -> avg();
	$c -> createJson();
	$c -> writeComNum();
}

echo "ok";
