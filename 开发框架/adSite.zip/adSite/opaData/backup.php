<?php
include "handle.php";

$get = @$_GET["get"];
$backup = @$_GET["backup"];
$goBack = @$_GET["goBack"];
$del = @$_GET["del"];
$file = @$_FILES["sql"];

if ($file) {
	//上传SQl备份文件
	$size = $file["size"];
	if ($size == 0)
		die("数据文件大小为空！");
	if (pathinfo($file["name"])["extension"] != "sql")
		die("上传的文件不是SQL文件！");
	if (file_exists("../json/backup/{$file['name']}"))
		die("备份文件已经存在，请删除后重新上传！");
	move_uploaded_file($file['tmp_name'], "../json/backup/{$file['name']}");
	echo "{$file['name']} -- 上传成功！";
	exit;
}

if ($get) {
	if (!is_dir("../json/backup/"))
		mkdir("../json/backup/", "0777", true);
	//获取备份数据列表
	$files = [];
	$dir = opendir("../json/backup/");
	while ($file = readdir($dir)) {
		if ($file != "." && $file != "..") {
			if (is_dir($file)) continue;
			$size = filesize("../json/backup/{$file}");
			$files[] = ["{$file}","{$size}"];
		}
	}
	closedir($dir);
	echo json_encode($files);
	exit;
}


if ($backup) {
	//备份数据
	include "../phpClass/Backup.class.php";
	$backupName = date("Y-m-d").".sql";
	if (file_exists("../json/backup/{$backupName}"))
		die("备份失败！今日的备份文件（{$backupName}）已存在！请先删除！");
	if (!is_dir("../json/backup/"))
		mkdir("../json/backup/", "0777", true);
	$b = new Backup();
	$b -> save("../json/backup/{$backupName}", $databaseInfo->dName);
	if (!file_exists("../json/backup/{$backupName}"))
		die("备份失败！因为各表数据都为空！");
	$size = filesize("../json/backup/{$backupName}");
	echo "[\"{$backupName}\",\"{$size}\"]";
	exit;
}

function dropDir($path) {
	$dir = opendir($path);
	while ($file = readdir($dir)) {
		if ($file == "." || $file == "..")
			continue;
		if (is_dir("{$path}{$file}"))
			dropDir("{$path}{$file}/");
		else @unlink("{$path}{$file}");
	}
	closedir($dir);
	rmdir($path);
}

if ($goBack) {
	$mysql = $GLOBALS["mysql"];
	//还原数据库
	$file = $goBack;
	if (!file_exists("../json/backup/{$file}"))
		echo "还原失败，文件不存在！";
	$data = file_get_contents("../json/backup/{$file}");
	$sqls = explode(";\r\n", $data);
	$length = count($sqls);
	for ($i = 0; $i < $length; $i++) {
		if (!$sqls[$i]) continue;
		$mysql -> query($sqls[$i]);
	}
	echo "{$file} -- 数据还原成功！";
	
	if (is_dir("../json/createHtml/"))
		dropDir("../json/createHtml/");
	if (is_dir("../json/contentViews/"))
		dropDir("../json/contentViews/");
	if (is_dir("../json/contentViewsSort/"))
		dropDir("../json/contentViewsSort/");
	if (is_dir("../json/contentScore/"))
		dropDir("../json/contentScore/");
	if (is_dir("../json/contentSort/"))
		dropDir("../json/contentSort/");
	if (is_dir("../json/contentLatest/"))
		dropDir("../json/contentLatest/");
	
	$webconfig = @file_get_contents("../json/webconfig.json");
	if ($webconfig) {
		$webconfig = json_decode(urldecode($webconfig));
		if (is_dir("../{$webconfig->adDir}/"))
			dropDir("../{$webconfig->adDir}/");
		if (is_dir("../{$webconfig->seoDir}/"))
			dropDir("../{$webconfig->seoDir}/");
		if (is_dir("../{$webconfig->appDir}/"))
			dropDir("../{$webconfig->appDir}/");
		if (is_dir("../{$webconfig->vpsDir}/"))
			dropDir("../{$webconfig->vpsDir}/");
	}
	if (is_dir("../com/"))
			dropDir("../com/");
	if (is_dir("../info/"))
			dropDir("../info/");
	
	include "../phpClass/ContentLatest.class.php";
	$l = new ContentLatest("ad");
	$l -> create();
	$l = new ContentLatest("seo");
	$l -> create();
	$l = new ContentLatest("app");
	$l -> create();
	$l = new ContentLatest("vps");
	$l -> create();
	
	include "../phpClass/ContentSort.class.php";
	$sql = "SELECT id,views FROM ad";
	$res = $mysql -> query($sql);
	mkdir("../json/contentViews/ad/", "0777", true);
	while ($row = $res->fetch_array()) {
		$id = $row[0];
		$views = $row[1];
		if (!$views) $views = 0;
		$s = new ContentSort($id, "ad_com", "ad");
		$s -> avg();
		$s -> createJson();
		file_put_contents("../json/contentViews/ad/{$id}.json", $views);
	}
	$sql = "SELECT id,views FROM seo";
	$res = $mysql -> query($sql);
	mkdir("../json/contentViews/seo/", "0777", true);
	while ($row = $res->fetch_array()) {
		$id = $row[0];
		$views = $row[1];
		if (!$views) $views = 0;
		$s = new ContentSort($id, "seo_com", "seo");
		$s -> avg();
		$s -> createJson();
		file_put_contents("../json/contentViews/seo/{$id}.json", $views);
	}
	$sql = "SELECT id,views FROM app";
	$res = $mysql -> query($sql);
	mkdir("../json/contentViews/app/", "0777", true);
	while ($row = $res->fetch_array()) {
		$id = $row[0];
		$views = $row[1];
		if (!$views) $views = 0;
		$s = new ContentSort($id, "app_com", "app");
		$s -> avg();
		$s -> createJson();
		file_put_contents("../json/contentViews/app/{$id}.json", $views);
	}
	$sql = "SELECT id,views FROM vps";
	$res = $mysql -> query($sql);
	mkdir("../json/contentViews/vps/", "0777", true);
	while ($row = $res->fetch_array()) {
		$id = $row[0];
		$views = $row[1];
		if (!$views) $views = 0;
		$s = new ContentSort($id, "vps_com", "vps");
		$s -> avg();
		$s -> createJson();
		file_put_contents("../json/contentViews/vps/{$id}.json", $views);
	}
	
	exit;
}

if ($del) {
	//删除备份文件
	$file = $del;
	if (file_exists("../json/backup/{$file}")) {
		unlink("../json/backup/{$file}");
		echo "ok";
	} else echo "err";
	exit;
}































