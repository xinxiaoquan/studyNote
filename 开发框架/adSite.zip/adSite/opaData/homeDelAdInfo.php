<?php
$ids = @$_GET["ids"];
if (!$ids) die("数据不全！");

include "handle.php";

$arr = explode(",", $ids);
$where = "";
for ($i = 0; $i < count($arr); $i++) {
	$where .= "id={$arr[$i]} ";
	if ($i != count($arr)-1) $where .= "or ";
}

$sql = "DELETE FROM ad_info WHERE {$where}";
$mysql -> query($sql);

echo "ok";
