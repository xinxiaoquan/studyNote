<?php
include "handle.php";

$link = @$_POST["link"];
$position = @$_POST["position"];

if (!$link || $position === null)
	die("数据不全！");

if (!$_FILES) die("图片没有上传！");
if ($_FILES["img"]["size"] >= 1024*1024)
	die("图片大小不要超过1M！");
$imgName = preg_replace('/\..*?$/', '', $_FILES["img"]["name"]);
$type = str_replace('image/', '', $_FILES["img"]["type"]);
$imgName = $imgName."_".time().".".$type;
$imgPath = "../images/seoImg/";
if (!is_dir($imgPath)) mkdir($imgPath);
move_uploaded_file($_FILES["img"]["tmp_name"], $imgPath.$imgName);

$path = "../json/seoImgAd.json";
if (!file_exists($path))
	$json = "[]";
else $json = urldecode(file_get_contents($path));

$data = json_decode($json);
$length = count($data);
if ($position < 0) $position = 0;
if ($position > $length) $position = $length;
for ($i = $length; $i >= $position; $i--) {
	if ($i-1 >= 0)
		$data[$i] = $data[$i-1];
	if ($i == $position) {
		$data[$i] = [$imgName, $link];
	}
}

$json = myUrlencode(json_encode($data));
file_put_contents($path, $json);

echo "图文广告添加成功！添加到了第{$position}条的后面";






























