<?php
include "handle.php";

function dropDir($path) {
	$dir = opendir($path);
	while ($file = readdir($dir)) {
		if ($file == "." || $file == "..")
			continue;
		if (is_dir("{$path}{$file}"))
			dropDir("{$path}{$file}/");
		else @unlink("{$path}{$file}");
	}
	closedir($dir);
	rmdir($path);
}

if (is_dir("../json/createHtml/"))
	dropDir("../json/createHtml/");
	mkdir("../json/createHtml/");
if (is_dir("../json/contentViews/"))
	dropDir("../json/contentViews/");
	mkdir("../json/contentViews/");
if (is_dir("../json/contentViewsSort/"))
	dropDir("../json/contentViewsSort/");
	mkdir("../json/contentViewsSort/");
if (is_dir("../json/contentScore/"))
	dropDir("../json/contentScore/");
	mkdir("../json/contentScore/");
if (is_dir("../json/contentSort/"))
	dropDir("../json/contentSort/");
	mkdir("../json/contentSort/");
if (is_dir("../json/contentLatest/"))
	dropDir("../json/contentLatest/");
	mkdir("../json/contentLatest/");

$webconfig = @file_get_contents("../json/webconfig.json");
if ($webconfig) {
	$webconfig = json_decode(urldecode($webconfig));
	if (is_dir("../{$webconfig->adDir}/"))
		dropDir("../{$webconfig->adDir}/");
	if (is_dir("../{$webconfig->seoDir}/"))
		dropDir("../{$webconfig->seoDir}/");
	if (is_dir("../{$webconfig->appDir}/"))
		dropDir("../{$webconfig->appDir}/");
	if (is_dir("../{$webconfig->vpsDir}/"))
		dropDir("../{$webconfig->vpsDir}/");
}
if (is_dir("../com/"))
		dropDir("../com/");
if (is_dir("../info/"))
		dropDir("../info/");
	
	
	
	
	
	
	
	