<?php

$timelyStar = @$_GET["timelyStar"];
$creditStar = @$_GET["creditStar"];
$serviceStar = @$_GET["serviceStar"];
$codeRichStar = @$_GET["codeRichStar"];

include "submitCom.php";

$timelyStar = rawurlencode($timelyStar);
$creditStar = rawurlencode($creditStar);
$serviceStar = rawurlencode($serviceStar);
$codeRichStar = rawurlencode($codeRichStar);

$sql = "INSERT INTO app_com VALUES(
	null,'{$pId}','{$title}','{$timelyStar}','{$creditStar}','{$serviceStar}','{$codeRichStar}','{$nickname}','{$content}','{$time}','{$ip}','{$area}',0
)";
$mysql -> query($sql);

echo "评论提交成功！请等待管理员审核！";