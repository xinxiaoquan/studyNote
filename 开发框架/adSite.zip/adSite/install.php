<?php
session_start();

if (!file_exists("data/databaseInfo.php")) {
	header("location:opaData/createDatabase.html");
	exit;
}

if (isset($_SESSION["admin"])) {
	header("location:home");
	exit;
}

header("location:users/sign.html");