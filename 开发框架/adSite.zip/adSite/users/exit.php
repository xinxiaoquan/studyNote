<?php
session_start();
$_SESSION = [];
session_destroy();
setcookie(session_name(), '', time()-1, '/');
header("location:../");