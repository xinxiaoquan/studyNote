<?php
session_start();

if (isset($_SESSION["user"]))
	die($_SESSION["user"]);

if (isset($_SESSION["admin"]))
	die("admin");

die("@err@");