<?php
if (!file_exists("../data/databaseInfo.php")) {
	header("location:../");
	exit;
}

session_start();

$nickname = @$_POST["nickname"];
$mobile = @$_POST["mobile"];
$pwd = @$_POST["pwd"];
$captcha = @$_POST["captcha"];

if (!$nickname || !$mobile || !$pwd || !$nickname || !$captcha)
	die("数据不全！");

if (@$_SESSION["captcha"] != strtolower($captcha))
	die("验证码错误！");

$nickname = htmlspecialchars($nickname);
$nickname = rawurlencode($nickname);
$mobile = htmlspecialchars($mobile);
$mobile = rawurlencode($mobile);
$pwd = md5($pwd);

$databaseInfo = file_get_contents("../data/databaseInfo.php");
$databaseInfo = preg_replace('/^<\?.+\/\//', "", $databaseInfo);
$databaseInfo = json_decode(urldecode($databaseInfo));
if ($databaseInfo->user == $mobile) die("用户名已经存在！");

$mysql = new mySQLi(
	$databaseInfo -> dAdress,
	$databaseInfo -> dUser,
	$databaseInfo -> dPwd,
	$databaseInfo -> dName,
	3306
);
$res = $mysql -> query("SELECT id FROM users WHERE moblie='{$mobile}' or nickname='{$nickname}'");
$res = $res -> fetch_all();
if ($res) die("用户名已经存在！");

$mysql -> query("INSERT INTO users VALUES(null, '{$mobile}', '{$nickname}', '{$pwd}')");

session_start();
$_SESSION["admin"] = $nickname;
die("注册成功！");










































