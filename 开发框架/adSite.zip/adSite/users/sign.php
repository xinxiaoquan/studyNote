<?php
if (!file_exists("../data/databaseInfo.php")) {
	header("location:../");
	exit;
}

session_start();

if (isset($_SESSION["admin"]))
	die("超级管理员已经登录！");
if (isset($_SESSION["user"]))
	die("您已经登录！");

$mobile = @$_POST["mobile"];
$pwd = @$_POST["pwd"];

if (!$mobile || !$pwd)
	die("数据不全！");

$mobile = htmlspecialchars($mobile);
$mobile = rawurlencode($mobile);
$pwd = md5($pwd);

$databaseInfo = file_get_contents("../data/databaseInfo.php");
$databaseInfo = preg_replace('/^<\?.+\/\//', "", $databaseInfo);
$databaseInfo = json_decode(urldecode($databaseInfo));

if ($databaseInfo->user == $mobile) {
	if (md5($databaseInfo->pwd) == $pwd) {
		$_SESSION["admin"] = true;
		die("您就是超级管理员吗？登录成功了！");
	} else die("密码错误！");
}

$mysql = new mySQLi(
	$databaseInfo -> dAdress,
	$databaseInfo -> dUser,
	$databaseInfo -> dPwd,
	$databaseInfo -> dName,
	3306
);
$res = $mysql -> query("SELECT id FROM users WHERE mobile='{$mobile}' and pwd='{$pwd}'");
$res = $res -> fetch_all();
if (!$res) die("没有此用户！");

$_SESSION["user"] = $mobile;
die("登录成功！");























