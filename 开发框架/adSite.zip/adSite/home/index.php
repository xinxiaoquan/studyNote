<?php
	session_start();
	if (!isset($_SESSION["admin"]) ||
		!file_exists("../data/databaseInfo.php")) {
		header("location:../install.php");
		exit;
	}
?>
<!doctype html>
<html>
	<head>
		<title>后台管理</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="../style/homeBase.css" />
		<link rel="stylesheet" href="../style/homeForm.css" />
		<link rel="stylesheet" href="../style/homeIndex.css" />
		<link rel="stylesheet" href="../style/homePage.css" />
	</head>
	<body>
		<div id="left">
			<ul>
				<li class="modifyDB">修改数据库信息</li>
				<li class="webconfig">修改网站配置</li>
				<li class="backup">数据库备份/还原</li>
				<li class="index">网站主页</li>
				<li class="home">后台多开</li>
				<li class="parent ad">※ 广告联盟操作</li>
				<li class="child reviewAd">审核联盟</li>
				<li class="child reviewAdCom">审核/查看评论</li>
				<li class="child createAdHtml">生成HTML</li>
				<li class="child addAd">增加</li>
				<li class="child modifyAd">修改</li>
				<li class="child delAd">删除</li>
				<li class="child addAdInfo">增加资讯</li>
				<li class="child modifyAdInfo">修改资讯</li>
				<li class="child delAdInfo">删除资讯</li>
				<li class="child addAdTextAd">增加文字广告</li>
				<li class="child addAdImgAd">增加图文广告</li>
				<li class="child addAdContentImgAd">内页3个广告</li>
				<li class="child delAdAd">删除广告</li>
				<li class="parent seo">※ SEO服务操作</li>
				<li class="child reviewSeo">审核SEO</li>
				<li class="child reviewSeoCom">审核/查看评论</li>
				<li class="child createSeoHtml">生成HTML</li>
				<li class="child addSeo">增加</li>
				<li class="child modifySeo">修改</li>
				<li class="child delSeo">删除</li>
				<li class="child addSeoInfo">增加资讯</li>
				<li class="child modifySeoInfo">修改资讯</li>
				<li class="child delSeoInfo">删除资讯</li>
				<li class="child addSeoTextAd">增加文字广告</li>
				<li class="child addSeoImgAd">增加图文广告</li>
				<li class="child addSeoContentImgAd">内页3个广告</li>
				<li class="child delSeoAd">删除广告</li>
				<li class="parent app">※ APP推广操作</li>
				<li class="child reviewApp">审核联盟</li>
				<li class="child reviewAppCom">审核/查看评论</li>
				<li class="child createAppHtml">生成HTML</li>
				<li class="child addApp">增加</li>
				<li class="child modifyApp">修改</li>
				<li class="child delApp">删除</li>
				<li class="child addAppInfo">增加资讯</li>
				<li class="child modifyAppInfo">修改资讯</li>
				<li class="child delAppInfo">删除资讯</li>
				<li class="child addAppTextAd">增加文字广告</li>
				<li class="child addAppImgAd">增加图文广告</li>
				<li class="child addAppContentImgAd">内页3个广告</li>
				<li class="child delAppAd">删除广告</li>
				<li class="parent vps">※ VPS主机操作</li>
				<li class="child reviewVps">审核联盟</li>
				<li class="child reviewVpsCom">审核/查看评论</li>
				<li class="child createVpsHtml">生成HTML</li>
				<li class="child addVps">增加</li>
				<li class="child modifyVps">修改</li>
				<li class="child delVps">删除</li>
				<li class="child addVpsInfo">增加资讯</li>
				<li class="child modifyVpsInfo">修改资讯</li>
				<li class="child delVpsInfo">删除资讯</li>
				<li class="child addVpsTextAd">增加文字广告</li>
				<li class="child addVpsImgAd">增加图文广告</li>
				<li class="child addVpsContentImgAd">内页3个广告</li>
				<li class="child delVpsAd">删除广告</li>
				<li class="siteImgAd">设置全站广告</li>
				<li class="opaUsers">管理用户</li>
				<li class="ipBlackList">管理IP黑名单</li>
				<li class="rollBack">恢复出厂设置</li>
				<li class="exit">退出登录</li>
			</ul>
		</div>
		<div id="right"></div>
	</body>
	<script src="../script/base.js"></script>
	<script src="../script/homeIndex.js"></script>
</html>


























