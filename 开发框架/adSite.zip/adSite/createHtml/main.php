<?php
include_once "../opaData/handle.php";

//哪个模块
$type = @$_GET["type"];
/*
生成哪个页面
index 代表主页
com 代表评论
info 代表资讯
submit 代表提交信息页面
数字 代表生成某个特定的内容页
*/
$who = @$_GET["who"];

if (!$type || !$who) {
	die("数据不全！");
}

if (!file_exists("../json/webconfig.json"))
	die("网站数据配置文件找不到！请先设置网站配置！");
$config = file_get_contents("../json/webconfig.json");
$config = json_decode(urldecode($config));

$indexPage = $config->indexPage;
$indexFile = "";
if ($type == "ad")
	$indexFile = "createAdIndex.php";
if ($type == "seo")
	$indexFile = "createSeoIndex.php";
if ($type == "app")
	$indexFile = "createAppIndex.php";
if ($type == "vps")
	$indexFile = "createVpsIndex.php";
$dir = "";
if ($type == "ad") $dir = $config->adDir;
if ($type == "seo") $dir = $config->seoDir;
if ($type == "app") $dir = $config->appDir;
if ($type == "vps") $dir = $config->vpsDir;
$comFile = $dir.".html";
$infoFile = $dir.".html";

$html = "";
$php = "";
if ($who == "index") {
	$php = $indexFile;
	if ($type == "ad" && $indexPage != 1 ||
		$type == "seo" && $indexPage != 2 ||
		$type == "app" && $indexPage != 3 ||
		$type == "vps" && $indexPage != 4 ) {
			if (!is_dir("../{$dir}"))
				mkdir("../{$dir}", "0777", true);
			$html = "../{$dir}/index.html";
		} else $html = "../index.html";
}
if ($who == "com") {
	if ($type == "ad")
		$php = "createAdCom.php";
	if ($type == "seo")
		$php = "createSeoCom.php";
	if ($type == "app")
		$php = "createAppCom.php";
	if ($type == "vps")
		$php = "createVpsCom.php";
	if (!is_dir("../com/"))
		mkdir("../com/");
	$html = "../com/{$comFile}";
}
if ($who == "info") {
	if ($type == "ad")
		$php = "createAdInfo.php";
	if ($type == "seo")
		$php = "createSeoInfo.php";
	if ($type == "app")
		$php = "createAppInfo.php";
	if ($type == "vps")
		$php = "createVpsInfo.php";
	if (!is_dir("../info/"))
		mkdir("../info/");
	$html = "../info/{$comFile}";
}
if ($who == "submit") {
	if ($type == "ad")
		$php = "createAdSubmit.php";
	if ($type == "seo")
		$php = "createSeoSubmit.php";
	if ($type == "app")
		$php = "createAppSubmit.php";
	if ($type == "vps")
		$php = "createVpsSubmit.php";
	if (!is_dir("../submit/"))
		mkdir("../submit/");
	$html = "../submit/{$dir}.html";
}
if (is_numeric($who)) {
	include "../phpClass/CreateHtmlTask.class.php";
	if ($type == "ad") {
		$c = new CreateHtmlTask("ad.ini", $who);
		$c->del();
		$php = "createAdContent.php";
	}
	if ($type == "seo") {
		$c = new CreateHtmlTask("seo.ini", $who);
		$c->del();
		$php = "createSeoContent.php";
	}
	if ($type == "app") {
		$c = new CreateHtmlTask("app.ini", $who);
		$c->del();
		$php = "createAppContent.php";
	}
	if ($type == "vps") {
		$c = new CreateHtmlTask("vps.ini", $who);
		$c->del();
		$php = "createVpsContent.php";
	}
	if (!is_dir("../{$dir}"))
		mkdir("../{$dir}");
	$html = "../{$dir}/{$who}.html";
	$config->id = $who;
}

if (!$html || !$php)
	die("生成失败！");

include "../phpClass/CreateHtml.class.php";
$ch = new createHtml($php, $html, $config);
$ch->create();

echo "{$html}";






















































