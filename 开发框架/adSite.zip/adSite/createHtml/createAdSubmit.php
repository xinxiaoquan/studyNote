<?php
if (!isset($DATA)) die("数据错误！生成失败！");

$DATA = (object)$DATA;

$cssJsPos = "../";

?>
<!doctype html>
<html>
	<head>
		<title>广告联盟提交 - <?php echo $DATA->adTitle?></title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontBase.css" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontSubmit.css" />
		<script>
			var webRoot = "<?php echo $DATA->webRoot?>";
			var cssJsPos = "../";
			var DIR = "<?php echo $DATA->adDir?>";
			var TYPE = "ad";
		</script>
	</head>
	<body>
		<div id="top">
			<div class="logo"></div>
		</div>
		<div id="nav">
			<div class="box">
				<?php
					$navArr = [
						["广告联盟", $DATA->webRoot.$DATA->adDir],
						["SEO服务", $DATA->webRoot.$DATA->seoDir],
						["APP推广", $DATA->webRoot.$DATA->appDir],
						["VPS主机", $DATA->webRoot.$DATA->vpsDir]
					];
					function exSub($arr, $a, $b) {
						$tmp = $arr[$a];
						$arr[$a] = $arr[$b];
						$arr[$b] = $tmp;
						return $arr;
					}
					if ($DATA->indexPage == 2)
						$navArr = exSub($navArr, 0, 1);
					if ($DATA->indexPage == 3)
						$navArr = exSub($navArr, 0, 2);
					if ($DATA->indexPage == 4)
						$navArr = exSub($navArr, 0, 3);
					for ($i = 0; $i < count($navArr); $i++) {
						if ($i == 0) {
							echo "<a href=\"{$DATA->webRoot}\" class=\"option\">{$navArr[$i][0]}</a>";
							continue;
						}
						echo "<a href=\"{$navArr[$i][1]}\" class=\"option\">{$navArr[$i][0]}</a>";
					}
				?>
				<a href="<?php echo $DATA->webRoot?>users/sign.html" class="option active sign">登录</a>
			</div>
		</div>
		<div id="imgAd" class="hidden"></div>
		<div id="textAd" class="hidden">
			<div class="box"></div>
		</div>
		<div id="content">
		<div id="contentLeft">
			<form action="../opaData/frontAddAd.php" method="post" />
				<p>输入联盟名称</p>
				<input name="adName" type="text" placeholder="输入联盟名称" />
				<span class="adName"></span>
				<p>输入联盟网址</p>
				<input name="adUrl" type="text" placeholder="输入联盟网址" />
				<span class="adUrl"></span>
				<p>输入联盟介绍</p>
				<textarea name="adRecommend" placeholder="输入联盟介绍"></textarea>
				<span class="textarea adRecommend"></span>
				<p>选择支付周期</p>
				<select name="adPayCycle">
					<option value="全部">全部</option>
					<option value="1">日付</option>
					<option value="2">周付</option>
					<option value="3">月付</option>
					<option value="4">季付</option>
				</select>
				<p>输入起付金额</p>
				<select name="adStartPay">
					<option value="全部">全部</option>
					<option value="1">1元起付</option>
					<option value="10">10元起付</option>
					<option value="20">20元起付</option>
					<option value="30">30元起付</option>
					<option value="50">50元起付</option>
					<option value="100">100元起付</option>
				</select>
				<p>输入广告类型</p>
				<div class="labelBox">
					<label>全部：<input value="全部" type="checkbox" name="adType" /></label>
					<label>cpc(点击)：<input value="cpc(点击)" type="checkbox" name="adType" /></label>
					<label>cpm(展示)：<input value="cpm(展示)" type="checkbox" name="adType" /></label>
					<label>cps(分成)：<input value="cps(分成)" type="checkbox" name="adType" /></label>
					<label>cpa(引导)：<input value="cpa(引导)" type="checkbox" name="adType" /></label>
					<label>cpv(媒体)：<input value="cpv(媒体)" type="checkbox" name="adType" /></label>
					<label>cpt(时长)：<input value="cpt(时长)" type="checkbox" name="adType" /></label>
					<label>cpl(有效注册)：<input value="cpl(有效注册)" type="checkbox" name="adType" /></label>
					<label>其他：<input value="其他" type="checkbox" name="adType" /></label>
				</div>
				<p>选择平台展示</p>
				<select name="adDisplay">
					<option value="1">电脑</option>
					<option value="2">苹果</option>
					<option value="3">安卓</option>
				</select>
				<div class="captcha">
					<p>输入验证码</p>
					<input name="captcha" type="text" placeholder="输入验证码" />
					<img src="../images/captcha.php" />
				</div>
				<input type="submit" />
				<input type="reset" />
			</form>
		</div>
		<div id="contentRight">
			<div id="suggest">
				<div class="text">推荐联盟<span class=red>（顺序不分先后）</span></div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="rand">
				<div class="text">广告联盟随机排序</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="info">
				<div class="text">联盟资讯<span class="more">更多>></span></div>
				<ul class="list"></ul>
			</div>
		</div>
		</div>
		<div id="bottom">
			<div class="copyright"><?php echo $DATA->adCopyright?></div>
		</div>
		<script src="<?php echo $cssJsPos?>script/base.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontBase.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontForm.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontAdSubmit.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontAds.js"></script>
	</body>
</html>








































