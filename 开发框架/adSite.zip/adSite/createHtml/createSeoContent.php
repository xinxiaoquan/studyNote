<?php
if (!isset($DATA)) die("数据错误！生成失败！");

$DATA = (object)$DATA;

$cssJsPos = "../";

$id = $DATA->id;

?>
<!doctype html>
<html>
	<?php
		$sql = "SELECT name,url,adress,mobile,qq,wx,recommend,type,class,area,quality FROM seo WHERE id={$id}";
		$res = $mysql -> query($sql);
		$row = $res->fetch_array();
		$name = urldecode($row[0]);
		$url = urldecode($row[1]);
		$adress = urldecode($row[2]);
		$mobile = urldecode($row[3]);
		$qq = urldecode($row[4]);
		$wx = urldecode($row[5]);
		$recommend = urldecode($row[6]);
		$type = urldecode($row[7]);
		$_class = urldecode($row[8]);
		$area = urldecode($row[9]);
		$quality = urldecode($row[10]);
	?>
	<head>
		<title><?php echo "{$name} - {$DATA->seoTitle}"?></title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontBase.css" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontContent.css" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontSeo.css" />
		<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
		<script>
			var cssJsPos = "<?php echo $cssJsPos?>";
			var webRoot = "<?php echo $DATA->webRoot?>";
			var DIR = "<?php echo $DATA->seoDir?>";
			var ID = "<?php echo $id?>";
			var TYPE = "seo";
		</script>
	</head>
	<body>
		<div id="top">
			<div class="logo"></div>
		</div>
		<div id="nav">
			<div class="box">
			<?php
				$navArr = [
						["广告联盟", $DATA->webRoot.$DATA->adDir],
						["SEO服务", $DATA->webRoot.$DATA->seoDir],
						["APP推广", $DATA->webRoot.$DATA->appDir],
						["VPS主机", $DATA->webRoot.$DATA->vpsDir]
					];
					function exSub($arr, $a, $b) {
						$tmp = $arr[$a];
						$arr[$a] = $arr[$b];
						$arr[$b] = $tmp;
						return $arr;
					}
					if ($DATA->indexPage == 2)
						$navArr = exSub($navArr, 0, 1);
					if ($DATA->indexPage == 3)
						$navArr = exSub($navArr, 0, 2);
					if ($DATA->indexPage == 4)
						$navArr = exSub($navArr, 0, 3);
					for ($i = 0; $i < count($navArr); $i++) {
						if ($navArr[$i][0] == "SEO服务") 
							$class = "class=\"option active\"";
						else $class = "class=\"option\"";
						if ($i == 0) {
							echo "<a href=\"{$DATA->webRoot}\" {$class}>{$navArr[$i][0]}</a>";
							continue;
						}
						echo "<a href=\"{$navArr[$i][1]}\" {$class}>{$navArr[$i][0]}</a>";
					}
				?>
				<a href="<?php echo $DATA->webRoot?>users/sign.html" class="option sign">登录</a>
			</div>
		</div>
		<div id="imgAd" class="hidden"></div>
		<div id="textAd" class="hidden">
			<div class="box"></div>
		</div>
		<div id="content">
		<div id="contentLeft">
			<div id="data">
				<div class="text">SEO服务信息</div>
				<div class="detailed">
					<?php
					$type = mapping("type", $type);
					$_class = mapping("class", $_class);
					$area = mapping("area", $area);
					$quality = mapping("quality", $quality);

					echo 
				"<div class=\"name\">{$name}</div>
						<div class=\"url\"><a target=\"_blank\" href=\"{$url}\">{$url}</a></div>
						<div class=\"adress\">{$adress}</div>
						<div class=\"mobile\">{$mobile}</div>
						<div class=\"qq\">{$qq}</div>
						<div class=\"wx\">{$wx}</div>
						<div class=\"recommend\" title=\"{$recommend}\">{$recommend}</div>
						<div class=\"type\">{$type}</div>
						<div class=\"class\">{$_class}</div>
						<div class=\"area\">{$area}</div>
						<div class=\"quality\">{$quality}</div>";
						
					function mapping($type, $num) {
						if ($type == "type") {
							if ($num == 1) return "PC";
							if ($num == 2) return "移动";
						}
						if ($type == "class") {
							if ($num == 1) return "百度";
							if ($num == 2) return "360";
							if ($num == 3) return "搜狗";
						}
						if ($type == "area") {
							if($num ==	1) return "北京";
							if($num ==	2) return "上海";
							if($num ==	3) return "广东";
							if($num ==	4) return "福建";
							if($num ==	5) return "浙江";
							if($num ==	6) return "山东";
							if($num ==	7) return "山西";
							if($num ==	8) return "辽宁";
							if($num ==	9) return "湖北";
							if($num ==	10) return "河北";
							if($num ==	11) return "重庆";
							if($num ==	12) return "陕西";
							if($num ==	13) return "河南";
							if($num ==	14) return "四川";
							if($num ==	15) return "湖南";
							if($num ==	16) return "江西";
							if($num ==	17) return "天津";
							if($num ==	18) return "江苏";
							if($num ==	19) return "广西";
							if($num ==	20) return "安徽";
							if($num ==	21) return "吉林";
							if($num ==	22) return "黑龙江";
							if($num ==	23) return "海南";
							if($num ==	24) return "贵州";
							if($num ==	25) return "云南";
							if($num ==	26) return "甘肃";
							if($num ==	27) return "青海";
							if($num ==	28) return "内蒙古";
							if($num ==	29) return "西藏";
							if($num ==	30) return "宁夏";
							if($num ==	31) return "新疆";
							if($num ==	32) return "香港";
							if($num ==	33) return "澳门";
							if($num ==	34) return "台湾";
						}
						if ($type == "quality") {
							if ($num == 1) return "个人";
							if ($num == 2) return "公司";
							if ($num == 3) return "团队";
						}
					}
					?>
					<div class="share">
						<div class="bshare-custom icon-medium"><a title="分享到微信" class="bshare-weixin"></a><a title="分享到QQ好友" class="bshare-qqim"></a><a title="分享到新浪微博" class="bshare-sinaminiblog"></a><a title="分享到人人网" class="bshare-renren"></a><a title="分享到QQ空间" class="bshare-qzone"></a><a title="分享到百度搜藏" class="bshare-baiducang"></a><a title="更多平台" class="bshare-more bshare-more-icon more-style-addthis"></a><span class="BSHARE_COUNT bshare-share-count">0</span></div><script type="text/javascript" charset="utf-8" src="https://static.bshare.cn/b/buttonLite.js#style=-1&amp;uuid=&amp;pophcol=1&amp;lang=zh"></script><script type="text/javascript" charset="utf-8" src="https://static.bshare.cn/b/bshareC0.js"></script>
					</div>				
				</div>
				<div class="histogram">
					<div class="frame">
						<span></span>
						<span></span>
						<span></span>
						<span></span>
					</div>
					<div class="column">
						<span><i>0</i></span>
						<span><i>0</i></span>
						<span><i>0</i></span>
						<span><i>0</i></span>
					</div>
					<div class="parameter">
						<span>完成速度</span>
						<span>排名稳定</span>
						<span>服务质量</span>
						<span>性价比</span>
					</div>
				</div>
			</div>
			<div id="middenAd"></div>
			<div id="com">
				<div class="text">网友点评</div>
				<?php
					$sql = "SELECT title,content,nickname,time,area,pId,speed,stable,service,price_ratio FROM seo_com WHERE is_pass=1 ORDER BY RAND() LIMIT 20";
					$res = $mysql -> query($sql);
					$rows = [];
					while ($row = $res->fetch_array())
						$rows[] = $row;
					$length = count($rows);
					for ($i = 0; $i < $length; $i++) {
						$object = urldecode($rows[$i][0]);
						$des = urldecode($rows[$i][1]);
						$user = urldecode($rows[$i][2]);
						$time = urldecode($rows[$i][3]);
						$area = urldecode($rows[$i][4]);
						$pId = urldecode($rows[$i][5]);
						$speed = urldecode($rows[$i][6]);
						$stable = urldecode($rows[$i][7]);
						$service = urldecode($rows[$i][8]);
						$priceRatio = urldecode($rows[$i][9]);
						echo 	
			"<div class=\"option\" pId=\"{$pId}\">
					<div class=\"object\"><a target=\"_blank\" href=\"{$DATA->webRoot}{$DATA->seoDir}/{$pId}.html\">{$object}</a></div>
					<div class=\"des\" title=\"{$des}\">{$des}</div>
					<div class=\"user\">{$user}</div>
					<div class=\"time\">{$time}</div>
					<div class=\"area\">{$area}</div>
					<div class=\"score\">
						<div class=\"speed\">{$speed}</div>
						<div class=\"stable\">{$stable}</div>
						<div class=\"service\">{$service}</div>
						<div class=\"priceRatio\">{$priceRatio}</div>
					</div>
					<div class=\"me\">我也要点评>></div>
				</div>\r\n\t\t\t\t";
					}
				?>
				<div class="pageNav">
					<div class="dataTotal">0</div>
					<div class="pageGo"><</div>
					<ul class="pageBar"></ul>
					<div class="pageBack">></div>
					<div class="pageTotal">0</div>
				</div>
			</div>
			<div id="writeCom">
				<div class="text">我要点评<span class="red">（您对这个SEO服务有什么想说的吗，期待您的宝贵意见！谢谢！）</span></div>
				<form action="../opaData/submitSeoCom.php" method="get">
					<input type="hidden" name="time" />
					<input type="hidden" name="ip" />
					<input type="hidden" name="pId" value="<?php echo $id?>" />
					<label class="speed star">
						<span>完成速度评分：</span>
						<ul>
							<li num=1></li>
							<li num=2></li>
							<li num=3></li>
							<li num=4></li>
							<li num=5></li>
						</ul>
						<span></span>
					</label>
					<label class="stable star">
						<span>排名稳定评分：</span>
						<ul>
							<li num=1></li>
							<li num=2></li>
							<li num=3></li>
							<li num=4></li>
							<li num=5></li>
						</ul>
						<span></span>
					</label>
					<label class="service star">
						<span>服务质量评分：</span>
						<ul>
							<li num=1></li>
							<li num=2></li>
							<li num=3></li>
							<li num=4></li>
							<li num=5></li>
						</ul>
						<span></span>
					</label>
					<label class="priceRatio star">
						<span>性价比评分：</span>
						<ul>
							<li num=1></li>
							<li num=2></li>
							<li num=3></li>
							<li num=4></li>
							<li num=5></li>
						</ul>
						<span></span>
					</label>
					<label>
						<span>昵称：</span><input name="nickname" value="匿名" type="text" />
					</label>
					<label>
						<span>点评：</span><input name="title" disabled=disabled type="text" />
					</label>
					<label>
						<span>内容：</span><textarea name="content"></textarea>
					</label>
					<label>
						<span>验证码：</span><input name="captcha" type="text" />
					</label>
					<input type="submit" />
					<div class="captcha"><img src="../images/captcha.php" /></div>
					<div class="updateC">看不清，点一点</div>
					<div class="mind">恶意评论和灌水经本站查明后管理员会将其删除，请网友注意评论者IP，以防被骗。</div>
				</form>
			</div>
		</div>
		<div id="contentRight">
			<div id="suggest">
				<div class="text">推荐SEO服务<span class=red>（顺序不分先后）</span></div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="rand">
				<div class="text">SEO服务随机排序</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="info">
				<div class="text">SEO资讯<span class="more">更多>></span></div>
				<ul class="list"></ul>
			</div>
		</div>
		</div>
		<div id="bottom">
			<div class="copyright"><?php echo $DATA->seoCopyright?></div>
		</div>
		<script src="https://pv.sohu.com/cityjson?ie=utf-8"></script>
		<script src="<?php echo $cssJsPos?>script/base.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontForm.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontBase.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontSeoContent.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontAds.js"></script>
	</body>
</html>