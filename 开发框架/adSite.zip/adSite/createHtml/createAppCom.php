<?php
if (!isset($DATA)) die("数据错误！生成失败！");

$DATA = (object)$DATA;

$cssJsPos = "../";

?>
<!doctype html>
<html>
	<head>
		<title>APP推广评论 - <?php echo $DATA->appTitle?></title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontBase.css" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontContent.css" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontApp.css" />
		<script>
			var cssJsPos = "<?php echo $cssJsPos?>";
			var webRoot = "<?php echo $DATA->webRoot?>";
			var DIR = "<?php echo $DATA->appDir?>";
			var TYPE = "app";
		</script>
	</head>
	<body>
		<div id="top">
			<div class="logo"></div>
		</div>
		<div id="nav">
			<div class="box">
			<?php
				$navArr = [
						["广告联盟", $DATA->webRoot.$DATA->adDir],
						["SEO服务", $DATA->webRoot.$DATA->seoDir],
						["APP推广", $DATA->webRoot.$DATA->appDir],
						["VPS主机", $DATA->webRoot.$DATA->vpsDir]
					];
					function exSub($arr, $a, $b) {
						$tmp = $arr[$a];
						$arr[$a] = $arr[$b];
						$arr[$b] = $tmp;
						return $arr;
					}
					if ($DATA->indexPage == 2)
						$navArr = exSub($navArr, 0, 1);
					if ($DATA->indexPage == 3)
						$navArr = exSub($navArr, 0, 2);
					if ($DATA->indexPage == 4)
						$navArr = exSub($navArr, 0, 3);
					for ($i = 0; $i < count($navArr); $i++) {
						if ($navArr[$i][0] == "APP推广") 
							$class = "class=\"option active\"";
						else $class = "class=\"option\"";
						if ($i == 0) {
							echo "<a href=\"{$DATA->webRoot}\" {$class}>{$navArr[$i][0]}</a>";
							continue;
						}
						echo "<a href=\"{$navArr[$i][1]}\" {$class}>{$navArr[$i][0]}</a>";
					}
				?>
				<a href="<?php echo $DATA->webRoot?>users/sign.html" class="option sign">登录</a>
			</div>
		</div>
		<div id="imgAd" class="hidden"></div>
		<div id="textAd" class="hidden">
			<div class="box"></div>
		</div>
		<div id="content">
		<div id="contentLeft">
			<div id="com">
				<div class="text">APP推广评论</div>
				<?php
					$sql = "SELECT title,content,nickname,time,area,pId,credit,timely,service,code_rich FROM app_com WHERE is_pass=1 ORDER BY RAND() LIMIT 50";
					$res = $mysql -> query($sql);
					$rows = [];
					while ($row = $res->fetch_array())
						$rows[] = $row;
					$length = count($rows);
					for ($i = 0; $i < $length; $i++) {
						$object = urldecode($rows[$i][0]);
						$des = urldecode($rows[$i][1]);
						$user = urldecode($rows[$i][2]);
						$time = urldecode($rows[$i][3]);
						$area = urldecode($rows[$i][4]);
						$pId = urldecode($rows[$i][5]);
						$credit = urldecode($rows[$i][6]);
						$timely = urldecode($rows[$i][7]);
						$service = urldecode($rows[$i][8]);
						$codeRich = urldecode($rows[$i][9]);
						echo 	
				"<div class=\"option\" pId=\"{$pId}\">
					<div class=\"object\"><a target=\"_blank\" href=\"{$DATA->webRoot}{$DATA->appDir}/{$pId}.html\">{$object}</a></div>
					<div class=\"des\" title=\"{$des}\">{$des}</div>
					<div class=\"user\">{$user}</div>
					<div class=\"time\">{$time}</div>
					<div class=\"area\">{$area}</div>
					<div class=\"score\">
						<div class=\"timely\">{$timely}</div>
						<div class=\"credit\">{$credit}</div>
						<div class=\"codeRich\">{$codeRich}</div>
						<div class=\"service\">{$service}</div>
					</div>
				</div>\r\n\t\t\t\t";
					}
				?>
				<div class="pageNav">
					<div class="dataTotal">0</div>
					<div class="pageGo"><</div>
					<ul class="pageBar"></ul>
					<div class="pageBack">></div>
					<div class="pageTotal">0</div>
				</div>
			</div>
			<div id="middenAd"></div>
		</div>
		<div id="contentRight">
			<div id="suggest">
				<div class="text">推荐APP推广<span class=red>（顺序不分先后）</span></div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="rand">
				<div class="text">APP推广随机排序</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="info">
				<div class="text">APP推广资讯<span class="more">更多>></span></div>
				<ul class="list"></ul>
			</div>
		</div>
		</div>
		<div id="bottom">
			<div class="copyright"><?php echo $DATA->appCopyright?></div>
		</div>
		<script src="http://pv.sohu.com/cityjson?ie=utf-8"></script>
		<script src="<?php echo $cssJsPos?>script/base.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontBase.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontAdCom.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontAds.js"></script>
	</body>
</html>