<?php
if (!isset($DATA)) die("数据错误！生成失败！");

$DATA = (object)$DATA;

if ($DATA->indexPage != 3) {
	$cssJsPos = "../";
} else {
	$cssJsPos = "";
}

?>
<!doctype html>
<html>
	<head>
		<title><?php echo $DATA->appTitle?></title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontBase.css" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontIndex.css" />
		<script>
			var cssJsPos = "<?php echo $cssJsPos?>";
			var webRoot = "<?php echo $DATA->webRoot?>";
			var DIR = "<?php echo $DATA->appDir?>";
			var TYPE = "app";
		</script>
	</head>
	<body>
		<div id="top">
			<div class="logo"></div>
		</div>
		<div id="nav">
			<div class="box">
				<?php
					$navArr = [
						["广告联盟", $DATA->webRoot.$DATA->adDir],
						["SEO服务", $DATA->webRoot.$DATA->seoDir],
						["APP推广", $DATA->webRoot.$DATA->appDir],
						["VPS主机", $DATA->webRoot.$DATA->vpsDir]
					];
					function exSub($arr, $a, $b) {
						$tmp = $arr[$a];
						$arr[$a] = $arr[$b];
						$arr[$b] = $tmp;
						return $arr;
					}
					if ($DATA->indexPage == 2)
						$navArr = exSub($navArr, 0, 1);
					if ($DATA->indexPage == 3)
						$navArr = exSub($navArr, 0, 2);
					if ($DATA->indexPage == 4)
						$navArr = exSub($navArr, 0, 3);
					for ($i = 0; $i < count($navArr); $i++) {
						if ($navArr[$i][0] == "APP推广") 
							$class = "class=\"option active\"";
						else $class = "class=\"option\"";
						if ($i == 0) {
							echo "<a href=\"{$DATA->webRoot}\" {$class}>{$navArr[$i][0]}</a>";
							continue;
						}
						echo "<a href=\"{$navArr[$i][1]}\" {$class}>{$navArr[$i][0]}</a>";
					}
				?>
				<a href="<?php echo $DATA->webRoot?>users/sign.html" class="option sign">登录</a>
			</div>
		</div>
		<div id="imgAd" class="hidden"></div>
		<div id="textAd" class="hidden">
			<div class="box"></div>
		</div>
		<div id="content">
		<div id="contentLeft">
			<div id="search">
				<div id="input">
					<input type="text" />
					<button>搜索</button>
					<span>高级搜索</span>
				</div>
				<div id="query">
					<div class="option">
						<i>平台类型：</i>
						<select class="class">
							<option value=1>不限</option>
							<option value=2>安卓</option>
							<option value=3>苹果</option>
							<option value=4>PC</option>
						</select>
					</div>
					<div class="option">
						<i>广告类型：</i>
						<select class="adType">
							<option value=1>不限</option>
							<option value=2>cpa</option>
							<option value=3>cps</option>
							<option value=4>cpm</option>
							<option value=5>换量</option>
							<option value=6>分销代理</option>
						</select>
					</div>
					<div class="option">
						<i>结算方式：</i>
						<select class="settle">
							<option value=1>不限</option>
							<option value=2>日结</option>
							<option value=3>月结</option>
							<option value=4>季度结</option>
							<option value=5>预付</option>
						</select>
					</div>
					<div class="option">
						<i>价格筛选：</i>
						<select class="priceSelect">
							<option value=1>不限</option>
							<option value=2>1元以下</option>
							<option value=3>1-2元</option>
							<option value=4>2-5元</option>
							<option value=5>5-10元</option>
							<option value=6>50元以上</option>
						</select>
					</div>
					<div class="option">
						<i>收入查询：</i>
						<select class="priceQuery">
							<option value=1>不限</option>
							<option value=2>后台</option>
							<option value=3>截图</option>
						</select>
					</div>
					<div class="option">
						<i>产品类型：</i>
						<select class="proType">
							<option value=1>不限</option>
							<option value=2>IT/互联网</option>
							<option value=3>游戏</option>
							<option value=4>金融服务</option>
							<option value=5>视频/直播</option>
							<option value=6>棋牌</option>
							<option value=7>影视/动漫</option>
							<option value=8>亲子/母婴</option>
							<option value=9>教育/培训</option>
							<option value=10>汽车</option>
							<option value=11>化妆品/美容美体</option>
							<option value=12>旅游</option>
							<option value=13>婚庆</option>
							<option value=14>房产</option>
							<option value=15>餐饮</option>
							<option value=16>快消/食品饮料</option>
							<option value=17>办公用品/生活用品</option>
							<option value=18>家居建材</option>
							<option value=19>家政服务</option>
							<option value=20>娱乐/休闲</option>
							<option value=21>媒体</option>
							<option value=22>广告/公关/展览</option>
							<option value=23>医药/医疗/健康/保健</option>
							<option value=24>投融资</option>
							<option value=25>智能产业</option>
							<option value=26>服装/服饰</option>
							<option value=27>家电/数码/手机</option>
							<option value=28>企业服务</option>
							<option value=29>通讯</option>
							<option value=30>能源/制造</option>
							<option value=31>其他</option>
						</select>
					</div>
					<div class="option">
						<i>排序规则：</i>
						<select class="sort">
							<option value="0">默认</option>
							<option value="1">总浏览量</option>
							<option value="2">点评数量</option>
							<option value="3">结算速度</option>
							<option value="4">APP推广信誉</option>
							<option value="5">代码丰富</option>
							<option value="6">服务质量</option>
						</select>
						<select class="sortRule">
							<option value="1">降序(从大到小)</option>
							<option value="2">升序(从小到大)</option>
						</select>
					</div>
				</div>
			</div>
			<div id="result">
				<div class="text">搜索结果</div>
			<?php
				$sql = "SELECT id,name,coms FROM app ORDER BY RAND() LIMIT 50";
				$res = $mysql -> query($sql);
				$rows = [];
				while ($row = $res->fetch_array())
					$rows[] = $row;
				$length = count($rows);
				for ($i = 0; $i < $length; $i++) {
					$id = urldecode($rows[$i][0]);
					$name = urldecode($rows[$i][1]);
					$coms = urldecode($rows[$i][2]);
					echo
				"<div class=\"option\" pId=\"{$id}\">
					<div class=\"name\"><a target=\"_blank\" href=\"{$DATA->webRoot}{$DATA->appDir}/{$id}.html\">{$name}</a></div>
					<div class=\"score\">
						<div class=\"credit\">0</div>
						<div class=\"timely\">0</div>
						<div class=\"service\">0</div>
						<div class=\"codeRich\">0</div>
					</div>
					<div class=\"latestCom\"></div>
					<div class=\"comNum\">{$coms}</div>
				</div>\r\n\t\t\t\t";
				}
			?>
				<div class="pageNav">
					<div class="dataTotal">0</div>
					<div class="pageGo"><</div>
					<ul class="pageBar"></ul>
					<div class="pageBack">></div>
					<div class="pageTotal">0</div>
				</div>
			</div>
		</div>
		<div id="contentRight">
			<div id="lately">
				<div class="text">最近收录</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="timely">
				<div class="text">结账及时性排行</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="credit">
				<div class="text">信誉度排行</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="service">
				<div class="text">客户服务质量</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="codeRich">
				<div class="text">代码丰富度</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="popularity">
				<div class="text">人气排行</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="info">
				<div class="text">APP推广资讯<span class="more">更多>></span></div>
				<ul class="list"></ul>
			</div>
			<div id="com">
				<div class="text">更多点评<span class="more">更多>>></span></div>
				<ul class="list">
				<?php
					$sql = "SELECT title,content FROM app_com ORDER BY RAND() LIMIT 10";
					$res = $mysql -> query($sql);
					while ($row = $res->fetch_array()) {
						$title = urldecode($row[0]);
						$content = urldecode($row[1]);
						echo "<li><div>{$title}</div><div>{$content}</div></li>";
					}
				?>
				</ul>
			</div>
		</div>
		</div>
		<div id="bottom">
			<div class="copyright"><?php echo $DATA->appCopyright?></div>
		</div>
		<script src="<?php echo $cssJsPos?>script/base.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontBase.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontAppIndex.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontAds.js"></script>
	</body>
</html>