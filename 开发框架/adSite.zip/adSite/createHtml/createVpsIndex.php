<?php
if (!isset($DATA)) die("数据错误！生成失败！");

$DATA = (object)$DATA;

if ($DATA->indexPage != 4) {
	$cssJsPos = "../";
} else {
	$cssJsPos = "";
}

?>
<!doctype html>
<html>
	<head>
		<title><?php echo $DATA->vpsTitle?></title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontBase.css" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontIndex.css" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontVps.css" />
		<script>
			var cssJsPos = "<?php echo $cssJsPos?>";
			var webRoot = "<?php echo $DATA->webRoot?>";
			var DIR = "<?php echo $DATA->vpsDir?>";
			var TYPE = "vps";
		</script>
	</head>
	<body>
		<div id="top">
			<div class="logo"></div>
		</div>
		<div id="nav">
			<div class="box">
				<?php
					$navArr = [
						["广告联盟", $DATA->webRoot.$DATA->adDir],
						["SEO服务", $DATA->webRoot.$DATA->seoDir],
						["APP推广", $DATA->webRoot.$DATA->appDir],
						["VPS主机", $DATA->webRoot.$DATA->vpsDir]
					];
					function exSub($arr, $a, $b) {
						$tmp = $arr[$a];
						$arr[$a] = $arr[$b];
						$arr[$b] = $tmp;
						return $arr;
					}
					if ($DATA->indexPage == 2)
						$navArr = exSub($navArr, 0, 1);
					if ($DATA->indexPage == 3)
						$navArr = exSub($navArr, 0, 2);
					if ($DATA->indexPage == 4)
						$navArr = exSub($navArr, 0, 3);
					for ($i = 0; $i < count($navArr); $i++) {
						if ($navArr[$i][0] == "VPS主机") 
							$class = "class=\"option active\"";
						else $class = "class=\"option\"";
						if ($i == 0) {
							echo "<a href=\"{$DATA->webRoot}\" {$class}>{$navArr[$i][0]}</a>";
							continue;
						}
						echo "<a href=\"{$navArr[$i][1]}\" {$class}>{$navArr[$i][0]}</a>";
					}
				?>
				<a href="<?php echo $DATA->webRoot?>users/sign.html" class="option sign">登录</a>
			</div>
		</div>
		<div id="imgAd" class="hidden"></div>
		<div id="textAd" class="hidden">
			<div class="box"></div>
		</div>
		<div id="content">
		<div id="contentLeft">
			<div id="search">
				<div id="input">
					<input type="text" />
					<button>搜索</button>
					<span>高级搜索</span>
				</div>
				<div id="query">
					<div class="option">
						<i>公司所在地：</i>
						<select class="adress">
							<option value=1>北京</option>
							<option value=2>上海</option>
							<option value=3>广东</option>
							<option value=4>福建</option>
							<option value=5>浙江</option>
							<option value=6>山东</option>
							<option value=7>山西</option>
							<option value=8>辽宁</option>
							<option value=9>湖北</option>
							<option value=10>河北</option>
							<option value=11>重庆</option>
							<option value=12>陕西</option>
							<option value=13>河南</option>
							<option value=14>四川</option>
							<option value=15>湖南</option>
							<option value=16>江西</option>
							<option value=17>天津</option>
							<option value=18>江苏</option>
							<option value=19>广西</option>
							<option value=20>安徽</option>
							<option value=21>吉林</option>
							<option value=22>黑龙江</option>
							<option value=23>海南</option>
							<option value=24>贵州</option>
							<option value=25>云南</option>
							<option value=26>甘肃</option>
							<option value=27>青海</option>
							<option value=28>内蒙古</option>
							<option value=29>西藏</option>
							<option value=30>宁夏</option>
							<option value=31>新疆</option>
							<option value=32>香港</option>
							<option value=33>澳门</option>
							<option value=34>台湾</option>
							<option value=35>日本</option>
							<option value=36>美国</option>
							<option value=37>韩国</option>
							<option value=38>欧洲</option>
							<option value=39>印度</option>
							<option value=40>泰国</option>
							<option value=41>缅甸</option>
							<option value=42>老挝</option>
							<option value=43>越南</option>
							<option value=44>新加坡</option>
							<option value=45>柬埔寨</option>
							<option value=46>俄罗斯</option>
							<option value=47>其他国家</option>
						</select>
					</div>
					<div class="option">
						<i>机房所在地：</i>
						<select class="room">
							<option value=1>北京</option>
							<option value=2>上海</option>
							<option value=3>广东</option>
							<option value=4>福建</option>
							<option value=5>浙江</option>
							<option value=6>山东</option>
							<option value=7>山西</option>
							<option value=8>辽宁</option>
							<option value=9>湖北</option>
							<option value=10>河北</option>
							<option value=11>重庆</option>
							<option value=12>陕西</option>
							<option value=13>河南</option>
							<option value=14>四川</option>
							<option value=15>湖南</option>
							<option value=16>江西</option>
							<option value=17>天津</option>
							<option value=18>江苏</option>
							<option value=19>广西</option>
							<option value=20>安徽</option>
							<option value=21>吉林</option>
							<option value=22>黑龙江</option>
							<option value=23>海南</option>
							<option value=24>贵州</option>
							<option value=25>云南</option>
							<option value=26>甘肃</option>
							<option value=27>青海</option>
							<option value=28>内蒙古</option>
							<option value=29>西藏</option>
							<option value=30>宁夏</option>
							<option value=31>新疆</option>
							<option value=32>香港</option>
							<option value=33>澳门</option>
							<option value=34>台湾</option>
							<option value=35>日本</option>
							<option value=36>美国</option>
							<option value=37>韩国</option>
							<option value=38>欧洲</option>
							<option value=39>印度</option>
							<option value=40>泰国</option>
							<option value=41>缅甸</option>
							<option value=42>老挝</option>
							<option value=43>越南</option>
							<option value=44>新加坡</option>
							<option value=45>柬埔寨</option>
							<option value=46>俄罗斯</option>
							<option value=47>其他国家</option>
						</select>
					</div>
					<div class="option">
						<i>服务器线路：</i>
						<select class="line">
							<option value=1>中国联通</option>
							<option value=2>中国电信</option>
							<option value=3>中国移动</option>
							<option value=4>港台线路</option>
							<option value=5>双线主机</option>
							<option value=6>海外主机</option>
							<option value=7>其他线路</option>
						</select>
					</div>
					<div class="option">
						<i>服务器类别：</i>
						<select class="class">
							<option value=1>国外服务器</option>
							<option value=2>国内服务器</option>
							<option value=3>国内VPS</option>
							<option value=4>国外VPS</option>
							<option value=5>国外虚拟主机</option>
							<option value=6>国内虚拟主机</option>
						</select>
					</div>
					<div class="option">
						<i>服务器类型：</i>
						<select class="type">
							<option value=1>DDOS高防服务器</option>
							<option value=2>抗投诉服务器</option>
							<option value=3>站群服务器</option>
							<option value=4>不限流量服务器</option>
							<option value=5>不限内容服务器</option>
						</select>
					</div>
					<div class="option">
						<i>VPS类型：</i>
						<select class="vpsClass">
							<option value=1>国内VPS</option>
							<option value=2>国外VPS</option>
							<option value=3>DDOS高防VPS</option>
							<option value=4>不限流量VPS</option>
							<option value=5>windows VPS</option>
							<option value=5>VPS云/云服务器</option>
						</select>
					</div>
					<div class="option">
						<i>排序规则：</i>
						<select class="sort">
							<option value="0">默认</option>
							<option value="1">总浏览量</option>
							<option value="2">点评数量</option>
							<option value="3">主机速度</option>
							<option value="4">服务质量</option>
							<option value="5">安全性</option>
							<option value="6">高防性</option>
						</select>
						<select class="sortRule">
							<option value="1">降序(从大到小)</option>
							<option value="2">升序(从小到大)</option>
						</select>
					</div>
				</div>
			</div>
			<div id="result">
				<div class="text">搜索结果</div>
			<?php
				$sql = "SELECT id,name,coms FROM vps ORDER BY RAND() LIMIT 50";
				$res = $mysql -> query($sql);
				$rows = [];
				while ($row = $res->fetch_array())
					$rows[] = $row;
				$length = count($rows);
				for ($i = 0; $i < $length; $i++) {
					$id = urldecode($rows[$i][0]);
					$name = urldecode($rows[$i][1]);
					$coms = urldecode($rows[$i][2]);
					echo
				"<div class=\"option\" pId=\"{$id}\">
					<div class=\"name\"><a target=\"_blank\" href=\"{$DATA->webRoot}{$DATA->vpsDir}/{$id}.html\">{$name}</a></div>
					<div class=\"score\">
						<div class=\"fast\">0</div>
						<div class=\"priceRatio\">0</div>
						<div class=\"service\">0</div>
						<div class=\"security\">0</div>
						<div class=\"highSafety\">0</div>
					</div>
					<div class=\"latestCom\"></div>
					<div class=\"comNum\">{$coms}</div>
				</div>\r\n\t\t\t\t";
				}
			?>
				<div class="pageNav">
					<div class="dataTotal">0</div>
					<div class="pageGo"><</div>
					<ul class="pageBar"></ul>
					<div class="pageBack">></div>
					<div class="pageTotal">0</div>
				</div>
			</div>
		</div>
		<div id="contentRight">
			<div id="lately">
				<div class="text">最近收录</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="fast">
				<div class="text">主机速度排行</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="priceRatio">
				<div class="text">性价比排行</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="service">
				<div class="text">客户服务质量</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="security">
				<div class="text">安全性排行</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="highSafety">
				<div class="text">高防性排行</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="popularity">
				<div class="text">人气排行</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="info">
				<div class="text">VPS资讯<span class="more">更多>></span></div>
				<ul class="list"></ul>
			</div>
			<div id="com">
				<div class="text">更多点评<span class="more">更多>>></span></div>
				<ul class="list">
				<?php
					$sql = "SELECT title,content FROM vps_com ORDER BY RAND() LIMIT 10";
					$res = $mysql -> query($sql);
					while ($row = $res->fetch_array()) {
						$title = urldecode($row[0]);
						$content = urldecode($row[1]);
						echo "<li><div>{$title}</div><div>{$content}</div></li>";
					}
				?>
				</ul>
			</div>
		</div>
		</div>
		<div id="bottom">
			<div class="copyright"><?php echo $DATA->vpsCopyright?></div>
		</div>
		<script src="<?php echo $cssJsPos?>script/base.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontBase.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontVpsIndex.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontAds.js"></script>
	</body>
</html>