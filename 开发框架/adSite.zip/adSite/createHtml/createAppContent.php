<?php
if (!isset($DATA)) die("数据错误！生成失败！");

$DATA = (object)$DATA;

$cssJsPos = "../";

$id = $DATA->id;

?>
<!doctype html>
<html>
	<?php
		$sql = "SELECT name,class,ad_type,settle,query,pro_type,price,content,contact FROM app WHERE id={$id}";
		$res = $mysql -> query($sql);
		$row = $res->fetch_array();
		$name = urldecode($row[0]);
		$_class = urldecode($row[1]);
		$adType = urldecode($row[2]);
		$settle = urldecode($row[3]);
		$query = urldecode($row[4]);
		$proType = urldecode($row[5]);
		$price = urldecode($row[6]);
		$content = urldecode($row[7]);
		$contact = urldecode($row[8]);
	?>
	<head>
		<title><?php echo "{$name} - {$DATA->appTitle}"?></title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontBase.css" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontContent.css" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontApp.css" />
		<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
		<script>
			var cssJsPos = "<?php echo $cssJsPos?>";
			var webRoot = "<?php echo $DATA->webRoot?>";
			var DIR = "<?php echo $DATA->appDir?>";
			var ID = "<?php echo $id?>";
			var TYPE = "app";
		</script>
	</head>
	<body>
		<div id="top">
			<div class="logo"></div>
		</div>
		<div id="nav">
			<div class="box">
			<?php
				$navArr = [
						["广告联盟", $DATA->webRoot.$DATA->adDir],
						["SEO服务", $DATA->webRoot.$DATA->seoDir],
						["APP推广", $DATA->webRoot.$DATA->appDir],
						["VPS主机", $DATA->webRoot.$DATA->vpsDir]
					];
					function exSub($arr, $a, $b) {
						$tmp = $arr[$a];
						$arr[$a] = $arr[$b];
						$arr[$b] = $tmp;
						return $arr;
					}
					if ($DATA->indexPage == 2)
						$navArr = exSub($navArr, 0, 1);
					if ($DATA->indexPage == 3)
						$navArr = exSub($navArr, 0, 2);
					if ($DATA->indexPage == 4)
						$navArr = exSub($navArr, 0, 3);
					for ($i = 0; $i < count($navArr); $i++) {
						if ($navArr[$i][0] == "APP推广") 
							$class = "class=\"option active\"";
						else $class = "class=\"option\"";
						if ($i == 0) {
							echo "<a href=\"{$DATA->webRoot}\" {$class}>{$navArr[$i][0]}</a>";
							continue;
						}
						echo "<a href=\"{$navArr[$i][1]}\" {$class}>{$navArr[$i][0]}</a>";
					}
				?>
				<a href="<?php echo $DATA->webRoot?>users/sign.html" class="option sign">登录</a>
			</div>
		</div>
		<div id="imgAd" class="hidden"></div>
		<div id="textAd" class="hidden">
			<div class="box"></div>
		</div>
		<div id="content">
		<div id="contentLeft">
			<div id="data">
				<div class="text">APP推广信息</div>
				<div class="detailed">
					<?php
					$_class = mapping($_class, [
						1=>"不限",
						2=>"安卓",
						3=>"苹果",
						4=>"PC",
					]);
					$adType = mapping($adType, [
						1=>"不限",
						2=>"cpa",
						3=>"cps",
						4=>"cpm",
						5=>"换量",
						6=>"分销代理",
					]);
					$settle = mapping($settle, [
						1=>"不限",
						2=>"日结",
						3=>"月结",
						4=>"季度结",
						5=>"预付",
					]);
					$query = mapping($query, [
						1=>"不限",
						2=>"后台",
						3=>"截图",
					]);
					$proType = mapping($proType, [
						1=>"不限",
						2=>"IT/互联网",
						3=>"游戏",
						4=>"金融服务",
						5=>"视频/直播",
						6=>"棋牌",
						7=>"影视/动漫",
						8=>"亲子/母婴",
						9=>"教育/培训",
						10=>"汽车",
						11=>"化妆品/美容美体",
						12=>"旅游",
						13=>"婚庆",
						14=>"房产",
						15=>"餐饮",
						16=>"快消/食品饮料",
						17=>"办公用品/生活用品",
						18=>"家居建材",
						19=>"家政服务",
						20=>"娱乐/休闲",
						21=>"媒体",
						22=>"广告/公关/展览",
						23=>"医药/医疗/健康/保健",
						24=>"投融资",
						25=>"智能产业",
						26=>"服装/服饰",
						27=>"家电/数码/手机",
						28=>"企业服务",
						29=>"通讯",
						30=>"能源/制造",
						31=>"其他",
					]);
					$price .= "元";
					$contact = mapping($contact, [
						1=>"QQ",
						2=>"微信",
						3=>"手机",
					]);
					echo 
					"<div class=\"name\">{$name}</div>
						<div class=\"class\">{$_class}</div>
						<div class=\"adType\">{$adType}</div>
						<div class=\"settle\">{$settle}</div>
						<div class=\"query\">{$query}</div>
						<div class=\"proType\">{$proType}</div>
						<div class=\"price\">{$price}</div>
						<div class=\"content\">{$content}</div>
						<div class=\"contact\">{$contact}</div>";
					function mapping($a, $rule) {
						if (isset($rule[$a]))
							return $rule[$a];
						else return $a;
					}
					?>
					<div class="share">
						<div class="bshare-custom icon-medium"><a title="分享到微信" class="bshare-weixin"></a><a title="分享到QQ好友" class="bshare-qqim"></a><a title="分享到新浪微博" class="bshare-sinaminiblog"></a><a title="分享到人人网" class="bshare-renren"></a><a title="分享到QQ空间" class="bshare-qzone"></a><a title="分享到百度搜藏" class="bshare-baiducang"></a><a title="更多平台" class="bshare-more bshare-more-icon more-style-addthis"></a><span class="BSHARE_COUNT bshare-share-count">0</span></div><script type="text/javascript" charset="utf-8" src="https://static.bshare.cn/b/buttonLite.js#style=-1&amp;uuid=&amp;pophcol=1&amp;lang=zh"></script><script type="text/javascript" charset="utf-8" src="https://static.bshare.cn/b/bshareC0.js"></script>
					</div>				
				</div>
				<div class="histogram">
					<div class="frame">
						<span></span>
						<span></span>
						<span></span>
						<span></span>
					</div>
					<div class="column">
						<span><i>0</i></span>
						<span><i>0</i></span>
						<span><i>0</i></span>
						<span><i>0</i></span>
					</div>
					<div class="parameter">
						<span>结算速度</span>
						<span>信誉度</span>
						<span>代码丰富度</span>
						<span>服务质量</span>
					</div>
				</div>
			</div>
			<div id="middenAd"></div>
			<div id="com">
				<div class="text">网友点评</div>
				<?php
					$sql = "SELECT title,content,nickname,time,area,pId,credit,timely,service,code_rich FROM app_com WHERE is_pass=1 ORDER BY RAND() LIMIT 20";
					$res = $mysql -> query($sql);
					$rows = [];
					while ($row = $res->fetch_array())
						$rows[] = $row;
					$length = count($rows);
					for ($i = 0; $i < $length; $i++) {
						$object = urldecode($rows[$i][0]);
						$des = urldecode($rows[$i][1]);
						$user = urldecode($rows[$i][2]);
						$time = urldecode($rows[$i][3]);
						$area = urldecode($rows[$i][4]);
						$pId = urldecode($rows[$i][5]);
						$credit = urldecode($rows[$i][6]);
						$timely = urldecode($rows[$i][7]);
						$service = urldecode($rows[$i][8]);
						$codeRich = urldecode($rows[$i][9]);
						echo 	
				"<div class=\"option\" pId=\"{$pId}\">
					<div class=\"object\"><a target=\"_blank\" href=\"{$DATA->webRoot}{$DATA->appDir}/{$pId}.html\">{$object}</a></div>
					<div class=\"des\" title=\"{$des}\">{$des}</div>
					<div class=\"user\">{$user}</div>
					<div class=\"time\">{$time}</div>
					<div class=\"area\">{$area}</div>
					<div class=\"score\">
						<div class=\"timely\">{$timely}</div>
						<div class=\"credit\">{$credit}</div>
						<div class=\"codeRich\">{$codeRich}</div>
						<div class=\"service\">{$service}</div>
					</div>
					<div class=\"me\">我也要点评>></div>
				</div>\r\n\t\t\t\t";
					}
				?>
				<div class="pageNav">
					<div class="dataTotal">0</div>
					<div class="pageGo"><</div>
					<ul class="pageBar"></ul>
					<div class="pageBack">></div>
					<div class="pageTotal">0</div>
				</div>
			</div>
			<div id="writeCom">
				<div class="text">我要点评<span class="red">（您对这个APP推广有什么想说的吗，期待您的宝贵意见！谢谢！）</span></div>
				<form action="../opaData/submitAppCom.php" method="get">
					<input type="hidden" name="time" />
					<input type="hidden" name="ip" />
					<input type="hidden" name="pId" value="<?php echo $id?>" />
					<label class="timely star">
						<span>结算速度评分：</span>
						<ul>
							<li num=1></li>
							<li num=2></li>
							<li num=3></li>
							<li num=4></li>
							<li num=5></li>
						</ul>
						<span></span>
					</label>
					<label class="credit star">
						<span>服务商信誉评分：</span>
						<ul>
							<li num=1></li>
							<li num=2></li>
							<li num=3></li>
							<li num=4></li>
							<li num=5></li>
						</ul>
						<span></span>
					</label>
					<label class="codeRich star">
						<span>代码丰富度评分：</span>
						<ul>
							<li num=1></li>
							<li num=2></li>
							<li num=3></li>
							<li num=4></li>
							<li num=5></li>
						</ul>
						<span></span>
					</label>
					<label class="service star">
						<span>服务质量评分：</span>
						<ul>
							<li num=1></li>
							<li num=2></li>
							<li num=3></li>
							<li num=4></li>
							<li num=5></li>
						</ul>
						<span></span>
					</label>
					<label>
						<span>昵称：</span><input name="nickname" value="匿名" type="text" />
					</label>
					<label>
						<span>点评：</span><input name="title" disabled=disabled type="text" />
					</label>
					<label>
						<span>内容：</span><textarea name="content"></textarea>
					</label>
					<label>
						<span>验证码：</span><input name="captcha" type="text" />
					</label>
					<input type="submit" />
					<div class="captcha"><img src="../images/captcha.php" /></div>
					<div class="updateC">看不清，点一点</div>
					<div class="mind">恶意评论和灌水经本站查明后管理员会将其删除，请网友注意评论者IP，以防被骗。</div>
				</form>
			</div>
		</div>
		<div id="contentRight">
			<div id="suggest">
				<div class="text">推荐APP推广<span class=red>（顺序不分先后）</span></div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="rand">
				<div class="text">APP推广随机排序</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="info">
				<div class="text">APP推广资讯<span class="more">更多>></span></div>
				<ul class="list"></ul>
			</div>
		</div>
		</div>
		<div id="bottom">
			<div class="copyright"><?php echo $DATA->appCopyright?></div>
		</div>
		<script src="https://pv.sohu.com/cityjson?ie=utf-8"></script>
		<script src="<?php echo $cssJsPos?>script/base.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontForm.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontBase.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontAdContent.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontAds.js"></script>
	</body>
</html>