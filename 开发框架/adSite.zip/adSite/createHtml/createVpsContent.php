<?php
if (!isset($DATA)) die("数据错误！生成失败！");

$DATA = (object)$DATA;

$cssJsPos = "../";

$id = $DATA->id;

?>
<!doctype html>
<html>
	<?php
		$sql = "SELECT name,url,adress,room,line,class,type,vps_class,recommend FROM vps WHERE id={$id}";
		$res = $mysql -> query($sql);
		$row = $res->fetch_array();
		$name = urldecode($row[0]);
		$url = urldecode($row[1]);
		$adress = urldecode($row[2]);
		$room = urldecode($row[3]);
		$line = urldecode($row[4]);
		$_class = urldecode($row[5]);
		$type = urldecode($row[6]);
		$vpsClass = urldecode($row[7]);
		$recommend = urldecode($row[8]);
	?>
	<head>
		<title><?php echo "{$name} - {$DATA->vpsTitle}"?></title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontBase.css" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontContent.css" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontVps.css" />
		<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
		<script>
			var cssJsPos = "<?php echo $cssJsPos?>";
			var webRoot = "<?php echo $DATA->webRoot?>";
			var DIR = "<?php echo $DATA->vpsDir?>";
			var ID = "<?php echo $id?>";
			var TYPE = "vps";
		</script>
	</head>
	<body>
		<div id="top">
			<div class="logo"></div>
		</div>
		<div id="nav">
			<div class="box">
			<?php
				$navArr = [
						["广告联盟", $DATA->webRoot.$DATA->adDir],
						["SEO服务", $DATA->webRoot.$DATA->seoDir],
						["APP推广", $DATA->webRoot.$DATA->appDir],
						["VPS主机", $DATA->webRoot.$DATA->vpsDir]
					];
					function exSub($arr, $a, $b) {
						$tmp = $arr[$a];
						$arr[$a] = $arr[$b];
						$arr[$b] = $tmp;
						return $arr;
					}
					if ($DATA->indexPage == 2)
						$navArr = exSub($navArr, 0, 1);
					if ($DATA->indexPage == 3)
						$navArr = exSub($navArr, 0, 2);
					if ($DATA->indexPage == 4)
						$navArr = exSub($navArr, 0, 3);
					for ($i = 0; $i < count($navArr); $i++) {
						if ($navArr[$i][0] == "VPS主机") 
							$class = "class=\"option active\"";
						else $class = "class=\"option\"";
						if ($i == 0) {
							echo "<a href=\"{$DATA->webRoot}\" {$class}>{$navArr[$i][0]}</a>";
							continue;
						}
						echo "<a href=\"{$navArr[$i][1]}\" {$class}>{$navArr[$i][0]}</a>";
					}
				?>
				<a href="<?php echo $DATA->webRoot?>users/sign.html" class="option sign">登录</a>
			</div>
		</div>
		<div id="imgAd" class="hidden"></div>
		<div id="textAd" class="hidden">
			<div class="box"></div>
		</div>
		<div id="content">
		<div id="contentLeft">
			<div id="data">
				<div class="text">VPS主机信息</div>
				<div class="detailed">
					<?php
					$tmpArr = [
						1=>"北京",
						2=>"上海",
						3=>"广东",
						4=>"福建",
						5=>"浙江",
						6=>"山东",
						7=>"山西",
						8=>"辽宁",
						9=>"湖北",
						10=>"河北",
						11=>"重庆",
						12=>"陕西",
						13=>"河南",
						14=>"四川",
						15=>"湖南",
						16=>"江西",
						17=>"天津",
						18=>"江苏",
						19=>"广西",
						20=>"安徽",
						21=>"吉林",
						22=>"黑龙江",
						23=>"海南",
						24=>"贵州",
						25=>"云南",
						26=>"甘肃",
						27=>"青海",
						28=>"内蒙古",
						29=>"西藏",
						30=>"宁夏",
						31=>"新疆",
						32=>"香港",
						33=>"澳门",
						34=>"台湾",
						35=>"日本",
						36=>"美国",
						37=>"韩国",
						38=>"欧洲",
						39=>"印度",
						40=>"泰国",
						41=>"缅甸",
						42=>"老挝",
						43=>"越南",
						44=>"新加坡",
						45=>"柬埔寨",
						46=>"俄罗斯",
						47=>"其他国家",
					];
					$adress = mapping($adress, $tmpArr);
					$room = mapping($room, $tmpArr);
					$line = mapping($line, [
						1=>"中国联通",
						2=>"中国电信",
						3=>"中国移动",
						4=>"港台线路",
						5=>"双线主机",
						6=>"海外主机",
						7=>"其他线路",	
					]);
					$_class = mapping($_class, [
						1=>"国外服务器",
						2=>"国内服务器",
						3=>"国内VPS",
						4=>"国外VPS",
						5=>"国外虚拟主机",
						6=>"国内虚拟主机",	
					]);
					$type = mapping($type, [
						1=>"DDOS高防服务器",
						2=>"抗投诉服务器",
						3=>"站群服务器",
						4=>"不限流量服务器",
						5=>"不限内容服务器",
					]);
					$vpsClass = mapping($vpsClass, [
						1=>"国内VPS",
						2=>"国外VPS",
						3=>"DDOS高防VPS",
						4=>"不限流量VPS",
						5=>"windows VPS",
						6=>"VPS云/云服务器",
					]);
					echo 
					"<div class=\"name\">{$name}</div>
						<div class=\"url\"><a target=\"_blank\" href=\"{$url}\">{$url}</a></div>
						<div class=\"adress\">{$adress}</div>
						<div class=\"room\">{$room}</div>
						<div class=\"line\">{$line}</div>
						<div class=\"class\">{$_class}</div>
						<div class=\"type\">{$type}</div>
						<div class=\"vpsClass\">{$vpsClass}</div>";
					function mapping($a, $rule) {
						if (isset($rule[$a]))
							return $rule[$a];
						else return $a;
					}
					?>
					<div class="share">
						<div class="bshare-custom icon-medium"><a title="分享到微信" class="bshare-weixin"></a><a title="分享到QQ好友" class="bshare-qqim"></a><a title="分享到新浪微博" class="bshare-sinaminiblog"></a><a title="分享到人人网" class="bshare-renren"></a><a title="分享到QQ空间" class="bshare-qzone"></a><a title="分享到百度搜藏" class="bshare-baiducang"></a><a title="更多平台" class="bshare-more bshare-more-icon more-style-addthis"></a><span class="BSHARE_COUNT bshare-share-count">0</span></div><script type="text/javascript" charset="utf-8" src="https://static.bshare.cn/b/buttonLite.js#style=-1&amp;uuid=&amp;pophcol=1&amp;lang=zh"></script><script type="text/javascript" charset="utf-8" src="https://static.bshare.cn/b/bshareC0.js"></script>
					</div>				
				</div>
				<div class="histogram">
					<div class="frame">
						<span></span>
						<span></span>
						<span></span>
						<span></span>
					</div>
					<div class="column">
						<span><i>0</i></span>
						<span><i>0</i></span>
						<span><i>0</i></span>
						<span><i>0</i></span>
						<span><i>0</i></span>
					</div>
					<div class="parameter">
						<span>主机速度</span>
						<span>性价比</span>
						<span>服务质量</span>
						<span>安全性</span>
						<span>高防性</span>
					</div>
				</div>
			</div>
			<div id="middenAd"></div>
			<div id="com">
				<div class="text">网友点评</div>
				<?php
					$sql = "SELECT title,content,nickname,time,area,pId,fast,price_ratio,service,security,high_safety FROM vps_com WHERE is_pass=1 ORDER BY RAND() LIMIT 20";
					$res = $mysql -> query($sql);
					$rows = [];
					while ($row = $res->fetch_array())
						$rows[] = $row;
					$length = count($rows);
					for ($i = 0; $i < $length; $i++) {
						$object = urldecode($rows[$i][0]);
						$des = urldecode($rows[$i][1]);
						$user = urldecode($rows[$i][2]);
						$time = urldecode($rows[$i][3]);
						$area = urldecode($rows[$i][4]);
						$pId = urldecode($rows[$i][5]);
						$fast = urldecode($rows[$i][6]);
						$priceRatio = urldecode($rows[$i][7]);
						$service = urldecode($rows[$i][8]);
						$security = urldecode($rows[$i][9]);
						$highSafety = urldecode($rows[$i][10]);
						echo 	
				"<div class=\"option\" pId=\"{$pId}\">
					<div class=\"object\"><a target=\"_blank\" href=\"{$DATA->webRoot}{$DATA->vpsDir}/{$pId}.html\">{$object}</a></div>
					<div class=\"des\" title=\"{$des}\">{$des}</div>
					<div class=\"user\">{$user}</div>
					<div class=\"time\">{$time}</div>
					<div class=\"area\">{$area}</div>
					<div class=\"score\">
						<div class=\"fast\">{$fast}</div>
						<div class=\"priceRatio\">{$priceRatio}</div>
						<div class=\"service\">{$service}</div>
						<div class=\"security\">{$security}</div>
						<div class=\"highSafety\">{$highSafety}</div>
					</div>
					<div class=\"me\">我也要点评>></div>
				</div>\r\n\t\t\t\t";
					}
				?>
				<div class="pageNav">
					<div class="dataTotal">0</div>
					<div class="pageGo"><</div>
					<ul class="pageBar"></ul>
					<div class="pageBack">></div>
					<div class="pageTotal">0</div>
				</div>
			</div>
			<div id="writeCom">
				<div class="text">我要点评<span class="red">（您对这个VPS主机有什么想说的吗，期待您的宝贵意见！谢谢！）</span></div>
				<form action="../opaData/submitVpsCom.php" method="get">
					<input type="hidden" name="time" />
					<input type="hidden" name="ip" />
					<input type="hidden" name="pId" value="<?php echo $id?>" />
					<label class="fast star">
						<span>主机速度评分：</span>
						<ul>
							<li num=1></li>
							<li num=2></li>
							<li num=3></li>
							<li num=4></li>
							<li num=5></li>
						</ul>
						<span></span>
					</label>
					<label class="priceRatio star">
						<span>性价比评分：</span>
						<ul>
							<li num=1></li>
							<li num=2></li>
							<li num=3></li>
							<li num=4></li>
							<li num=5></li>
						</ul>
						<span></span>
					</label>
					<label class="service star">
						<span>服务质量评分：</span>
						<ul>
							<li num=1></li>
							<li num=2></li>
							<li num=3></li>
							<li num=4></li>
							<li num=5></li>
						</ul>
						<span></span>
					</label>
					<label class="security star">
						<span>安全性评分：</span>
						<ul>
							<li num=1></li>
							<li num=2></li>
							<li num=3></li>
							<li num=4></li>
							<li num=5></li>
						</ul>
						<span></span>
					</label>
					<label class="highSafety star">
						<span>高防性评分：</span>
						<ul>
							<li num=1></li>
							<li num=2></li>
							<li num=3></li>
							<li num=4></li>
							<li num=5></li>
						</ul>
						<span></span>
					</label>
					<label>
						<span>昵称：</span><input name="nickname" value="匿名" type="text" />
					</label>
					<label>
						<span>点评：</span><input name="title" disabled=disabled type="text" />
					</label>
					<label>
						<span>内容：</span><textarea name="content"></textarea>
					</label>
					<label>
						<span>验证码：</span><input name="captcha" type="text" />
					</label>
					<input type="submit" />
					<div class="captcha"><img src="../images/captcha.php" /></div>
					<div class="updateC">看不清，点一点</div>
					<div class="mind">恶意评论和灌水经本站查明后管理员会将其删除，请网友注意评论者IP，以防被骗。</div>
				</form>
			</div>
		</div>
		<div id="contentRight">
			<div id="suggest">
				<div class="text">推荐VPS主机<span class=red>（顺序不分先后）</span></div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="rand">
				<div class="text">VPS主机随机排序</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="info">
				<div class="text">VPS主机资讯<span class="more">更多>></span></div>
				<ul class="list"></ul>
			</div>
		</div>
		</div>
		<div id="bottom">
			<div class="copyright"><?php echo $DATA->vpsCopyright?></div>
		</div>
		<script src="https://pv.sohu.com/cityjson?ie=utf-8"></script>
		<script src="<?php echo $cssJsPos?>script/base.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontForm.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontBase.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontVpsContent.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontAds.js"></script>
	</body>
</html>