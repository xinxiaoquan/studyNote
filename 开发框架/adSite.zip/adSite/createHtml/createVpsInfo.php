<?php
if (!isset($DATA)) die("数据错误！生成失败！");

include_once "../opaData/handle.php";

$DATA = file_get_contents("../json/webconfig.json");
$DATA = urldecode($DATA);
$DATA = json_decode($DATA);

$DATA = (object)$DATA;

$cssJsPos = "../";

?>
<!doctype html>
<html>
	<head>
		<title>VPS资讯 - <?php echo $DATA->vpsTitle?></title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontBase.css" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontInfo.css" />
		<script>
			var cssJsPos = "../";
			var webRoot = "<?php echo $DATA->webRoot?>";
			var DIR = "<?php echo $DATA->vpsDir?>";
			var TYPE = "vps";
		</script>
	</head>
	<body>
		<div id="top">
			<div class="logo"></div>
		</div>
		<div id="nav">
			<div class="box">
				<?php
					$navArr = [
						["广告联盟", $DATA->webRoot.$DATA->adDir],
						["SEO服务", $DATA->webRoot.$DATA->seoDir],
						["APP推广", $DATA->webRoot.$DATA->appDir],
						["VPS主机", $DATA->webRoot.$DATA->vpsDir]
					];
					function exSub($arr, $a, $b) {
						$tmp = $arr[$a];
						$arr[$a] = $arr[$b];
						$arr[$b] = $tmp;
						return $arr;
					}
					if ($DATA->indexPage == 2)
						$navArr = exSub($navArr, 0, 1);
					if ($DATA->indexPage == 3)
						$navArr = exSub($navArr, 0, 2);
					if ($DATA->indexPage == 4)
						$navArr = exSub($navArr, 0, 3);
					for ($i = 0; $i < count($navArr); $i++) {
						if ($navArr[$i][0] == "VPS主机") 
							$class = "class=\"option active\"";
						else $class = "class=\"option\"";
						if ($i == 0) {
							echo "<a href=\"{$DATA->webRoot}\" {$class}>{$navArr[$i][0]}</a>";
							continue;
						}
						echo "<a href=\"{$navArr[$i][1]}\" {$class}>{$navArr[$i][0]}</a>";
					}
				?>
				<a href="<?php echo $DATA->webRoot?>users/sign.html" class="option sign">登录</a>
			</div>
		</div>
		<div id="imgAd" class="hidden"></div>
		<div id="textAd" class="hidden">
			<div class="box"></div>
		</div>
		<div id="content">
		<div id="contentLeft">
			<div id="showInfo">
				<div class="text">VPS资讯</div>
				<?php
					$sql = "SELECT title,time,content FROM vps_info ORDER BY RAND() LIMIT 50";
					$res = $mysql -> query($sql);
					$rows = $res -> fetch_all();
					for ($i = 0; $i < count($rows); $i++) {
						$title = urldecode($rows[$i][0]);
						$time = urldecode($rows[$i][1]);
						$content = urldecode($rows[$i][2]);
						echo
					"<div class=\"option\">
						<div class=\"title\">{$title}</div>
						<div class=\"time\">{$time}</div>
						<div class=\"des\">{$content}</div>
					</div>";
					}
				?>
				<div class="pageNav">
					<div class="dataTotal">0</div>
					<div class="pageGo"><</div>
					<ul class="pageBar"></ul>
					<div class="pageBack">></div>
					<div class="pageTotal">0</div>
				</div>
			</div>
			<div id="middenAd"></div>
		</div>
		<div id="contentRight">
			<div id="suggest">
				<div class="text">推荐VPS主机<span class=red>（顺序不分先后）</span></div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="rand">
				<div class="text">VPS主机随机排序</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="info">
				<div class="text">VPS资讯<span class="more">更多>></span></div>
				<ul class="list"></ul>
			</div>
		</div>
		</div>
		<div id="bottom">
			<div class="copyright"><?php echo $DATA->vpsCopyright?></div>
		</div>
		<script src="<?php echo $cssJsPos?>script/base.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontBase.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontVpsInfo.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontAds.js"></script>
	</body>
</html>








































