<?php
if (!isset($DATA)) die("数据错误！生成失败！");

$DATA = (object)$DATA;

$cssJsPos = "../";

?>
<!doctype html>
<html>
	<head>
		<title>APP推广提交 - <?php echo $DATA->appTitle?></title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontBase.css" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontSubmit.css" />
		<script>
			var webRoot = "<?php echo $DATA->webRoot?>";
			var cssJsPos = "../";
			var DIR = "<?php echo $DATA->appDir?>";
			var TYPE = "app";
		</script>
	</head>
	<body>
		<div id="top">
			<div class="logo"></div>
		</div>
		<div id="nav">
			<div class="box">
				<?php
					$navArr = [
						["广告联盟", $DATA->webRoot.$DATA->adDir],
						["SEO服务", $DATA->webRoot.$DATA->seoDir],
						["APP推广", $DATA->webRoot.$DATA->appDir],
						["VPS主机", $DATA->webRoot.$DATA->vpsDir]
					];
					function exSub($arr, $a, $b) {
						$tmp = $arr[$a];
						$arr[$a] = $arr[$b];
						$arr[$b] = $tmp;
						return $arr;
					}
					if ($DATA->indexPage == 2)
						$navArr = exSub($navArr, 0, 1);
					if ($DATA->indexPage == 3)
						$navArr = exSub($navArr, 0, 2);
					if ($DATA->indexPage == 4)
						$navArr = exSub($navArr, 0, 3);
					for ($i = 0; $i < count($navArr); $i++) {
						if ($i == 0) {
							echo "<a href=\"{$DATA->webRoot}\" class=\"option\">{$navArr[$i][0]}</a>";
							continue;
						}
						echo "<a href=\"{$navArr[$i][1]}\" class=\"option\">{$navArr[$i][0]}</a>";
					}
				?>
				<a href="<?php echo $DATA->webRoot?>users/sign.html" class="option active sign">登录</a>
			</div>
		</div>
		<div id="imgAd" class="hidden"></div>
		<div id="textAd" class="hidden">
			<div class="box"></div>
		</div>
		<div id="content">
		<div id="contentLeft">
			<form action="../opaData/frontAddApp.php" method="post" />
				<p>APP名称</p>
				<input type="text" name="appName" placeholder="输入APP名称" />
				<p>平台类型</p>
				<select name="appClass">
					<option value=1>不限</option>
					<option value=2>安卓</option>
					<option value=3>苹果</option>
					<option value=4>PC</option>
				</select>
				<p>广告类型</p>
				<select name="appAdType">
					<option value=1>不限</option>
					<option value=2>cpa</option>
					<option value=3>cps</option>
					<option value=4>cpm</option>
					<option value=5>换量</option>
					<option value=6>分销代理</option>
				</select>
				<p>结算方式</p>
				<select name="appSettle">
					<option value=1>不限</option>
					<option value=2>日结</option>
					<option value=3>月结</option>
					<option value=4>季度结</option>
					<option value=5>预付</option>
				</select>
				<p>收入查询</p>
				<select name="appQuery">
					<option value=1>不限</option>
					<option value=2>后台</option>
					<option value=3>截图</option>
				</select>
				<p>产品类型</p>
				<select name="appProType">
					<option value=1>不限</option>
					<option value=2>IT/互联网</option>
					<option value=3>游戏</option>
					<option value=4>金融服务</option>
					<option value=5>视频/直播</option>
					<option value=6>棋牌</option>
					<option value=7>影视/动漫</option>
					<option value=8>亲子/母婴</option>
					<option value=9>教育/培训</option>
					<option value=10>汽车</option>
					<option value=11>化妆品/美容美体</option>
					<option value=12>旅游</option>
					<option value=13>婚庆</option>
					<option value=14>房产</option>
					<option value=15>餐饮</option>
					<option value=16>快消/食品饮料</option>
					<option value=17>办公用品/生活用品</option>
					<option value=18>家居建材</option>
					<option value=19>家政服务</option>
					<option value=20>娱乐/休闲</option>
					<option value=21>媒体</option>
					<option value=22>广告/公关/展览</option>
					<option value=23>医药/医疗/健康/保健</option>
					<option value=24>投融资</option>
					<option value=25>智能产业</option>
					<option value=26>服装/服饰</option>
					<option value=27>家电/数码/手机</option>
					<option value=28>企业服务</option>
					<option value=29>通讯</option>
					<option value=30>能源/制造</option>
					<option value=31>其他</option>
				</select>
				<p>单价</p>
				<input type="text" name="appPrice" placeholder="输入单价" />
				<p>内容</p>
				<textarea name="appContent" placeholder="输入内容"></textarea>
				<p>联系方式</p>
				<select name="appContact">
					<option value=1>QQ</option>
					<option value=2>微信</option>
					<option value=3>手机</option>
				</select>
				<div class="captcha">
					<p>输入验证码</p>
					<input name="captcha" type="text" placeholder="输入验证码" />
					<img src="../images/captcha.php" />
				</div>
				<input type="submit" />
				<input type="reset" />
			</form>
		</div>
		<div id="contentRight">
			<div id="suggest">
				<div class="text">推荐APP推广<span class=red>（顺序不分先后）</span></div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="rand">
				<div class="text">APP推广随机排序</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="info">
				<div class="text">APP推广资讯<span class="more">更多>></span></div>
				<ul class="list"></ul>
			</div>
		</div>
		</div>
		<div id="bottom">
			<div class="copyright"><?php echo $DATA->appCopyright?></div>
		</div>
		<script src="<?php echo $cssJsPos?>script/base.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontBase.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontForm.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontAppSubmit.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontAds.js"></script>
	</body>
</html>








































