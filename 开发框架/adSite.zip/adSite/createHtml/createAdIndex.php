<?php
if (!isset($DATA)) die("数据错误！生成失败！");

$DATA = (object)$DATA;

if ($DATA->indexPage != 1) {
	$cssJsPos = "../";
} else {
	$cssJsPos = "";
}

?>
<!doctype html>
<html>
	<head>
		<title><?php echo $DATA->adTitle?></title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontBase.css" />
		<link rel="stylesheet" href="<?php echo $cssJsPos?>style/frontIndex.css" />
		<script>
			var cssJsPos = "<?php echo $cssJsPos?>";
			var webRoot = "<?php echo $DATA->webRoot?>";
			var DIR = "<?php echo $DATA->adDir?>";
			var TYPE = "ad";
		</script>
	</head>
	<body>
		<div id="top">
			<div class="logo"></div>
		</div>
		<div id="nav">
			<div class="box">
				<?php
					$navArr = [
						["广告联盟", $DATA->webRoot.$DATA->adDir],
						["SEO服务", $DATA->webRoot.$DATA->seoDir],
						["APP推广", $DATA->webRoot.$DATA->appDir],
						["VPS主机", $DATA->webRoot.$DATA->vpsDir]
					];
					function exSub($arr, $a, $b) {
						$tmp = $arr[$a];
						$arr[$a] = $arr[$b];
						$arr[$b] = $tmp;
						return $arr;
					}
					if ($DATA->indexPage == 2)
						$navArr = exSub($navArr, 0, 1);
					if ($DATA->indexPage == 3)
						$navArr = exSub($navArr, 0, 2);
					if ($DATA->indexPage == 4)
						$navArr = exSub($navArr, 0, 3);
					for ($i = 0; $i < count($navArr); $i++) {
						if ($navArr[$i][0] == "广告联盟") 
							$class = "class=\"option active\"";
						else $class = "class=\"option\"";
						if ($i == 0) {
							echo "<a href=\"{$DATA->webRoot}\" {$class}>{$navArr[$i][0]}</a>";
							continue;
						}
						echo "<a href=\"{$navArr[$i][1]}\" {$class}>{$navArr[$i][0]}</a>";
					}
				?>
				<a href="<?php echo $DATA->webRoot?>users/sign.html" class="option sign">登录</a>
			</div>
		</div>
		<div id="imgAd" class="hidden"></div>
		<div id="textAd" class="hidden">
			<div class="box"></div>
		</div>
		<div id="content">
		<div id="contentLeft">
			<div id="search">
				<div id="input">
					<input type="text" />
					<button>搜索</button>
					<span>高级搜索</span>
				</div>
				<div id="query">
					<div class="option">
						<i>支付周期：</i>
						<select class="payCycle">
							<option value="全部">全部</option>
							<option value="1">日付</option>
							<option value="2">周付</option>
							<option value="3">月付</option>
							<option value="4">季付</option>
						</select>
					</div>
					<div class="option">
						<i>起付金额：</i>
						<select class="startPay">
							<option value="全部">全部</option>
							<option value="1">1元起付</option>
							<option value="10">10元起付</option>
							<option value="20">20元起付</option>
							<option value="30">30元起付</option>
							<option value="50">50元起付</option>
							<option value="100">100元起付</option>
						</select>
					</div>
					<div class="option checkboxs">
						<i>广告类型：</i>
						<label>全部 <input value="全部" type="checkbox" class="type" /></label>
						<label>CPC(点击)<input value="CPC(点击)" type="checkbox" class="type" /></label>
						<label>CPM(展示)<input value="CPM(展示)" type="checkbox" class="type" /></label>
						<label>CPS(分成)<input value="CPS(分成)" type="checkbox" class="type" /></label>
						<label>CPA(引导)<input value="CPA(引导)" type="checkbox" class="type" /></label>
						<label>CPV(媒体)<input value="CPV(媒体)" type="checkbox" class="type" /></label>
						<label>CPT(时长)<input value="CPT(时长)" type="checkbox" class="type" /></label>
						<label>CPL(有效注册)<input value="CPL(有效注册)" type="checkbox" class="type" /></label>
						<label>其他 <input value="其他" type="checkbox" class="type" /></label>
					</div>
					<div class="option">
						<i>平台展示：</i>
						<select class="display">
							<option value="1">PC(电脑)</option>
							<option value="2">IOS(苹果)</option>
							<option value="3">android(安卓)</option>
						</select>
					</div>
					<div class="option">
						<i>排序规则：</i>
						<select class="sort">
							<option value="0">默认</option>
							<option value="1">总浏览量</option>
							<option value="2">点评数量</option>
							<option value="3">结算速度</option>
							<option value="4">联盟信誉</option>
							<option value="5">代码丰富</option>
							<option value="6">服务质量</option>
						</select>
						<select class="sortRule">
							<option value="1">降序(从大到小)</option>
							<option value="2">升序(从小到大)</option>
						</select>
					</div>
				</div>
			</div>
			<div id="result">
				<div class="text">搜索结果</div>
			<?php
				$sql = "SELECT id,name,coms FROM ad ORDER BY RAND() LIMIT 50";
				$res = $mysql -> query($sql);
				$rows = [];
				while ($row = $res->fetch_array())
					$rows[] = $row;
				$length = count($rows);
				for ($i = 0; $i < $length; $i++) {
					$id = urldecode($rows[$i][0]);
					$name = urldecode($rows[$i][1]);
					$coms = urldecode($rows[$i][2]);
					echo
				"<div class=\"option\" pId=\"{$id}\">
					<div class=\"name\"><a target=\"_blank\" href=\"{$DATA->webRoot}{$DATA->adDir}/{$id}.html\">{$name}</a></div>
					<div class=\"score\">
						<div class=\"credit\">0</div>
						<div class=\"timely\">0</div>
						<div class=\"service\">0</div>
						<div class=\"codeRich\">0</div>
					</div>
					<div class=\"latestCom\"></div>
					<div class=\"comNum\">{$coms}</div>
				</div>\r\n\t\t\t\t";
				}
			?>
				<div class="pageNav">
					<div class="dataTotal">0</div>
					<div class="pageGo"><</div>
					<ul class="pageBar"></ul>
					<div class="pageBack">></div>
					<div class="pageTotal">0</div>
				</div>
			</div>
		</div>
		<div id="contentRight">
			<div id="lately">
				<div class="text">最近收录</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="timely">
				<div class="text">结账及时性排行</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="credit">
				<div class="text">信誉度排行</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="service">
				<div class="text">客户服务质量</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="codeRich">
				<div class="text">代码丰富度</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="popularity">
				<div class="text">人气排行</div>
				<ul class="rankinGList"></ul>
			</div>
			<div id="info">
				<div class="text">联盟资讯<span class="more">更多>></span></div>
				<ul class="list"></ul>
			</div>
			<div id="com">
				<div class="text">更多点评<span class="more">更多>>></span></div>
				<ul class="list">
				<?php
					$sql = "SELECT title,content FROM ad_com ORDER BY RAND() LIMIT 10";
					$res = $mysql -> query($sql);
					while ($row = $res->fetch_array()) {
						$title = urldecode($row[0]);
						$content = urldecode($row[1]);
						echo "<li><div>{$title}</div><div>{$content}</div></li>";
					}
				?>
				</ul>
			</div>
		</div>
		</div>
		<div id="bottom">
			<div class="copyright"><?php echo $DATA->adCopyright?></div>
		</div>
		<script src="<?php echo $cssJsPos?>script/base.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontBase.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontAdIndex.js"></script>
		<script src="<?php echo $cssJsPos?>script/frontAds.js"></script>
	</body>
</html>