<?php
$user = @$_POST["user"];
$pwd = @$_POST["pwd"];
$captcha = @$_POST["captcha"];

function goBack($info) {
	echo "<script>alert('{$info}');if(document.referrer) location.href=document.referrer;</script>";
	exit;
}

if (!$user || !$pwd || !$captcha)
	goBack("数据不全！");

session_start();
if (strtolower($captcha) != strtolower($_SESSION["captcha"]))
	goBack("验证码错误！");

/*
用户信息
admin 权限最高
edit 可以发布文章
target 可以设置链接跳转
*/
$admin = [
	"admin"=>"admin",
];
$edit = [];

if (isset($admin[$user]) && $pwd == $admin[$user]) {
	header("location:operation.php");
	$_SESSION["admin"] = true;
} else if (isset($edit[$user]) && $pwd == $edit[$user]) {
	header("location:operation.php");
	$_SESSION["edit"] = true;
} else goBack("登录失败！用户名或密码错误！");


















































