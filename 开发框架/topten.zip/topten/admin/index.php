<?php
session_start();
if (isset($_SESSION["admin"])) {
	header("location:operation.php");
	exit;
}
?>
<!doctype html>
<html>
	<head>
		<title>排行榜后台管理系统</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="../style/base.css" />
		<link rel="stylesheet" href="../style/form.css" />
		<meta name="viewport" content="user-scalable=no" />
	</head>
	<body>
		<form action="sign.php" method="post">
			<input autofocus=true autocomplete="off" name="user" type="text" placeholder="输入用户名" />
			<input autocomplete="off" name="pwd" type="password" placeholder="输入密码" />
			<input autocomplete="off" name="captcha" type="text" placeholder="输入验证码" />
			<img class="captcha" src="captcha.php" />
			<input type="submit" />
			<input type="reset" />
		</form>
		<script src="../script/form.js"></script>
	</body>
</html>