<?php
session_start();
if (!isset($_SESSION["admin"]) && !isset($_SESSION["edit"]))
	die("没有权限提交！");

$time = @$_POST["time"];
$title = @$_POST["title"];
$content = @$_POST["content"];
$RTitle = @$_POST["RTitle"];
$RTitle = (array)$RTitle;
$RContent = @$_POST["RContent"];
$RContent = (array)$RContent;
$RLink = @$_POST["RLink"];
$RLink = (array)$RLink;
$RPic = @$_FILES["RPic"];
$RPic = (array)$RPic;

if (!$RPic || count($RPic["name"]) != count($RTitle)) {
	echo "文章生成失败！上传文件为空！";
	goBack();
}

//获取列表信息
if (!file_exists("../list.json"))
	file_put_contents("../list.json", "[]");
$list = file_get_contents("../list.json");
$list = json_decode($list);
$list = (array)$list;
$list[] = $title;
$no = count($list);

//处理图片
$tmp = $RPic["tmp_name"];
$type = $RPic["type"];
$length = count($tmp);
for ($i = 0; $i < $length; $i++) {
	if (!getSuffix($type[$i])) {
		echo "文章生成失败！上传的文件 <b style='color:red'>{$RPic['name'][$i]}</b> 不是图片！";
		goBack();
	}
	if (filesize($tmp[$i]) >= 1024*1024) {
		echo "文章生成失败！上传的文件 <b style='color:red'>{$RPic['name'][$i]}</b> 大于1MB！";
		goBack();
	}
}
$PICS = [];
include "zoomPic.class.php";
for ($i = 0; $i < $length; $i++) {
	$file = ($i+1).getSuffix($type[$i]);
	move_uploaded_file($tmp[$i], "../{$no}/{$file}");
	$z = new zoomPic("../{$no}/{$file}");
	$z -> replace();
	$PICS[] = $file;
}
file_put_contents("../{$no}/pic.json", json_encode($PICS));
//获取后缀名的函数
function getSuffix($str) {
	if (strpos($str, "jpeg") !== false)
		return ".jpg";
	if (strpos($str, "png") !== false)
		return ".png";
	if (strpos($str, "gif") !== false)
		return ".gif";
	return null;
}

//更新列表
file_put_contents("../list.json", json_encode($list));
@mkdir("../{$no}");
file_put_contents("../{$no}/data.json", json_encode($_POST));

//生成文章
$header = file_get_contents("../header.html");
$header = str_replace("{{title}}", $title."十大品牌排行榜", $header);
$footer = file_get_contents("../footer.html");
$middle = "";
$middle .= "<h1>{$title}十大品牌排行榜</h1>";
$middle .= "<time>{$time}</time>";
$middle .= "<h2>{$content}</h2>";
$length = count($RTitle);
for ($i = 0; $i < $length; $i++) {
	$middle .= "<h3>{$RTitle[$i]}</h3>";
	$middle .= "<p>{$RContent[$i]}</p>";
	$middle .= "<img src=\"{$PICS[$i]}\" />";
	$linkCode = $RLink[$i];
	$linkCode = json_decode($linkCode);
	$middle .= "<a shopId=\"{$linkCode[0]}\" href=\"{$linkCode[1]}\">{$linkCode[2]}</a>";
}
file_put_contents("../{$no}/index.html", $header.$middle.$footer);

echo "文件生成成功！点击下面查看：";
echo "<br/><br/><a target=\"_blank\" href=\"../{$no}\">{$title}</a>";
goBack();

//返回上级代码
function goBack() {
	echo "<br/><br/><a href=\"#\" onclick=\"history.go(-1)\">返回上级</a>";
	exit;
}





































