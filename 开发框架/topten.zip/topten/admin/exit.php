<?php
session_start();
unset($_SESSION["admin"]);
unset($_SESSION["edit"]);
unset($_SESSION["target"]);
header("location:../");