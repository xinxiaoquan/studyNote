<?php
session_start();
if (!isset($_SESSION["admin"]) && !isset($_SESSION["edit"]) && !isset($_SESSION["target"]))
	header("location:../");
if (isset($_SESSION["admin"]))
	$ADMIN = true;
if (isset($_SESSION["edit"]))
	$EDIT = true;
if (isset($_SESSION["target"]))
	$TARGET = true;
?>
<!doctype html>
<html>
	<head>
		<title>排行榜操作界面</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="../style/base.css" />
		<link rel="stylesheet" href="../style/operation.css" />
		<meta name="viewport" content="user-scalable=no" />
	</head>
	<body>
		<p>您可操作的功能</p>
		<ul>
			<?php
				echo "<li><a href=\"../index.php\">查看所有文章</a></li>";
				$add = "<li><a href=\"add.html\">添加文章</a></li>";
				$edit = "<li><a href=\"../index.php\">编辑文章</a></li>";
				if (isset($ADMIN))
					echo $add.$edit;
				if (isset($EDIT))
					echo $add;
				echo "<li><a href=\"exit.php\">退出</a></li>";
			?>
		</ul>
	</body>
</html>

































