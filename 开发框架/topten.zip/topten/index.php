<!doctype html>
<html>
<head>
	<title>全部的产品排行榜</title>
	<meta charset="utf-8" />
	<link rel="stylesheet" href="style/base.css" />
	<link rel="stylesheet" href="style/index.css" />
</head>
<body>
<?php
$isEdit = false;
session_start();
if (isset($_SESSION["admin"]) || isset($_SESSION["edit"]))
	echo "<div><a href=\"admin/operation.php\">操作界面 [#]</a></div>";
if (isset($_SESSION["admin"]) || isset($_SESSION["edit"]))
	$isEdit = true;

$list = @file_get_contents("list.json");
if (!$list) exit;
$list = json_decode($list);
$length = count($list);
for ($i = 0; $i < $length; $i++) {
	$sub = $i+1;
	if ($isEdit)
		$edit = "<a class=\"fun\" target=\"_blank\" href=\"admin/modify.php?id={$sub}\">编辑</a>";
	else $edit = "";
	echo "<div sub=\"{$sub}\"><a target=\"_blank\" href=\"{$sub}\">{$list[$i]} [{$sub}]</a>{$edit}</div>";
}
?>
</body>
</html>





































