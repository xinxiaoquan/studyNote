//追加品牌按钮
(function() {
	var insertR = document.querySelector("button.insertR");
	if (insertR) {
		insertR.addEventListener("click", function(e) {
			var ranking = document.querySelector("div.ranking:last-of-type");
			if (!ranking) {
				ranking = document.createElement("div");
				ranking.className = "ranking";
				ranking.innerHTML = `<input autocomplete="off" name="RTitle[]" class="rankingTitle" type="text" placeholder="第N位排名标题" />
				<textarea autocomplete="off" name="RContent[]" class="rankingContent" placeholder="第N位排名内容"></textarea>
				<input autocomplete="off" name="RPic[]" type="file" accept=".jpg,.jpeg,.png,.gif"/>
				<button>点击提交品牌图片</button>
				<span class="alert pic" null>未上传图片</span>
				<input autocomplete="off" name="RLink[]" class="rankingLink" type="text" placeholder="第N位排名链接代码" />
				<span class="alert">获取代码：请在淘宝店或天猫店按F12调出审查元素，在console中输入<br/><b>[shop_config.userId, "https://"+location.host, decodeURIComponent(shop_config.user_nick)]</b><br/>然后复制返回结果到此框即可</span>
				<div class="close">X</div>`;
				RNumber(ranking, 1);
				initialize(ranking);
				var submit = document.querySelector("input[type=submit]");
				insertR.parentElement.insertBefore(ranking, submit);
				e.preventDefault();
				return;
			}
			var mark = ranking.nextElementSibling;
			var num = ranking.getAttribute("num");
			num = Number(num)+1;
			ranking = ranking.cloneNode(true);
			insertR.parentElement.insertBefore(ranking, mark);
			RNumber(ranking, num);
			initialize(ranking);
			e.preventDefault();
			return;
			
			function initialize(RS) {
				var title = RS.querySelector(".rankingTitle");
				title.value = "";
				var content = RS.querySelector(".rankingContent");
				content.value = "";
				var link = RS.querySelector(".rankingLink");
				link.value = "";
				var fileBtn = RS.querySelector("input[type=file]");
				fileBtn.value = "";
				fileEvent(fileBtn);
				var _alert = fileBtn.nextElementSibling.nextElementSibling;
				_alert.setAttribute("null", true);
				_alert.innerHTML = "未上传图片";
				var close = RS.querySelector("div.close");
				close.addEventListener("click", function() {
					this.parentElement.parentElement.removeChild(this.parentElement);
					var elems = document.querySelectorAll("div.ranking");
					for (var i = 0; i < elems.length; i++)
						RNumber(elems[i], i+1);
				});
				return RS;
			}
		});
		
		insertR.click();
	}
})();

//第N位排名
function RNumber(RS, num) {
	RS.setAttribute("num", num);
	var title = RS.querySelector(".rankingTitle");
	var content = RS.querySelector(".rankingContent");
	var link = RS.querySelector(".rankingLink");
	title.setAttribute("placeholder", "第"+num+"位排名标题");
	content.setAttribute("placeholder", "第"+num+"位排名内容");
	link.setAttribute("placeholder", "第"+num+"位排名链接代码");
}

//提交文件按钮绑定事件
function fileEvent(fileBtn) {
	var btn = fileBtn.nextElementSibling;
	var _alert = btn.nextElementSibling;
	btn.addEventListener("click", function(e) {
		fileBtn.click();
		e.preventDefault();
	});
	fileBtn.addEventListener("change", function(e) {
		_alert.innerHTML = e.target.value;
		_alert.removeAttribute("null");
	});
}
































