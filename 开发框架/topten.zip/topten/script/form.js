//验证码点击更新
function updateCaptcha() {
	var captcha = document.querySelector("img.captcha");
	if (captcha)
	captcha.addEventListener("click", function() {
		this.src = this.src;
	});
}
updateCaptcha();

//各种文本框的验证
(function() {
	var submit = document.querySelector("[type=submit]");
	if (submit) {
		submit.addEventListener("click", function(e) {
			var user = document.querySelector("[name=user]");
			if (user && user.value == "") {
				alert("用户名不能为空！");
				e.preventDefault();
				return;
			}
			
			var pwd = document.querySelector("[name=pwd]");
			if (pwd && pwd.value == "") {
				alert("密码不能为空！");
				e.preventDefault();
				return;
			}
			
			var captcha = document.querySelector("[name=captcha]");
			if (captcha && captcha.value == "") {
				alert("验证码不能为空！");
				e.preventDefault();
				return;
			}
			
			var title = document.querySelector("[name=title]");
			if (title && title.value == "") {
				alert("文章标题不能为空！");
				e.preventDefault();
				return;
			}
			if (title.value) title.value = trim(title.value);
			
			var content = document.querySelector("[name=content]");
			if (content && content.value == "") {
				alert("文章内容不能为空！");
				e.preventDefault();
				return;
			}
			if (content.value) content.value = trim(content.value);
			
			var RTitle = document.querySelectorAll("[name='RTitle[]']");
			if (RTitle)
			for (var i = 0; i < RTitle.length; i++) {
				if (RTitle[i].value == "") {
					alert("排行榜标题(第"+(i+1)+"个)不能为空！");
					e.preventDefault();
					return;
				}
				if (RTitle[i].value) RTitle[i].value = trim(RTitle[i].value);
			}
			
			var RContent = document.querySelectorAll("[name='RContent[]']");
			if (RContent)
			for (var i = 0; i < RContent.length; i++) {
				if (RContent[i].value == "") {
					alert("排行榜内容(第"+(i+1)+"个)不能为空！");
					e.preventDefault();
					return;
				}
				if (RContent[i].value) RContent[i].value = trim(RContent[i].value);
			}
			
			var RLink = document.querySelectorAll("[name='RLink[]']");
			if (RLink)
			for (var i = 0; i < RLink.length; i++) {
				if (RLink[i].value == "") {
					alert("排行榜链接(第"+(i+1)+"个)不能为空！");
					e.preventDefault();
					return;
				}
				if (RLink[i].value) RLink[i].value = trim(RLink[i].value);
			}

			var _alertPic = document.querySelectorAll(".alert.pic");
			if (_alertPic)
			for (var i = 0; i < _alertPic.length; i++) {
				if (_alertPic[i].getAttribute("null")) {
					alert("你未提交图片(第"+(i+1)+"个)！");
					e.preventDefault();
					return;
				}
			}
			
			var time = document.querySelector("[name=time]");
			if (time)
			time.value = new Date().getTime();
		
		});
	}
})();

//去出文本两边的空格
function trim($str) {
	return $str.replace(/^\s*|\s*$/g, "");
}








































