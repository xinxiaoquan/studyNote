(function() {
	var url = location.href;
	var agent = navigator.userAgent;
	agent = agent.toLowerCase();
	if (agent.indexOf("android") != -1 ||
			agent.indexOf("ios") != -1 ||
			agent.indexOf("wp") != -1 ||
			agent.indexOf("iphone") != -1)
			document.head.innerHTML += "<link href=\"../style/wp.css\" rel=\"stylesheet\" />";
	
	totop.onclick = function() {
		(function smoothscroll(){
				var currentScroll = document.documentElement.scrollTop || document.body.scrollTop;
				if (currentScroll > 0) {
						 window.requestAnimationFrame(smoothscroll);
						 window.scrollTo (0,currentScroll - (currentScroll/5));
				}
		})();
		return false;
	}
})();

//更新时间的格式
(function() {
	var time = document.querySelector("time");
	var stamp = time.innerHTML;
	var date = new Date(Number(stamp));
	var year = date.getFullYear();
	var month = addZero(date.getMonth()+1);
	var day = addZero(date.getDate());
	var hour = addZero(date.getHours());
	var minutes = addZero(date.getMinutes());
	var seconds = addZero(date.getSeconds());
	time.innerHTML = `${year}-${month}-${day} ${hour}:${minutes}:${seconds}`;
	
	function addZero(num) {
		num = Number(num);
		if (num < 10) return "0"+num;
		else return num;
	}
})();

/*
获取店铺相关信息的json，进入店铺，在控制台中写入：
[shop_config.userId, "https://"+location.host, decodeURIComponent(shop_config.user_nick)]
*/